use Operations;

GO

	
 -- we will change the order in management studio

ALTER TABLE Seg_Files_Transport_Audit
	ADD transport_name varchar(20),
		download_time_ss	smallint,
		source_file_pattern_searched	varchar(50)

;


