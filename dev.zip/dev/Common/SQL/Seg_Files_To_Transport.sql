use Operations

;

GO

IF OBJECT_ID('Seg_Files_To_Transport') IS NOT NULL
	DROP TABLE Seg_Files_To_Transport

GO

CREATE TABLE Seg_Files_To_Transport
(
transport_name		varchar(20)	NOT NULL,
action			varchar(10)	NOT NULL,
vendor_key		varchar(20)	NOT NULL,
source_path		varchar(255)	NOT NULL,
source_file_pattern		varchar(50)	NOT NULL,
destination_path		varchar(255)	NOT NULL,
destination_file_pattern		varchar(50)	NOT NULL default '',
is_active		bit not null default 1,
db_insert_time		datetime 	not null default getdate(),
comments		varchar(255),
PRIMARY KEY (transport_name,vendor_key,action,source_path,source_file_pattern),
FOREIGN KEY (vendor_key) REFERENCES Vendor_Credentials(vendor_key) ,
CHECK (action in ('Incoming','Outgoing','Copy'))
)


GO


GRANT ALL ON Seg_Files_To_Transport TO PUBLIC;

GO


