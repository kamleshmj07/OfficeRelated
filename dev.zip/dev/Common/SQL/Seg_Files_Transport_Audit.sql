use Operations;


IF OBJECT_ID('Seg_Files_Transported') is not null
	DROP table Seg_Files_Transported
;

GO
IF OBJECT_ID('Seg_Files_Transport_Audit') is not null
	DROP table Seg_Files_Transport_Audit
;

GO

CREATE TABLE Seg_Files_Transport_Audit
(vendor_key		varchar(20)	not null,
action			varchar(10)	not null,
source_filename		varchar(305)	not null,
destination_path 	varchar(305)	not null,
source_bytes	integer		not null,
source_modtime	datetime	not null,
post_processed	bit	not null default 0,
db_insert_time	datetime	not null default getdate(),
comments	varchar(200)	,
PRIMARY KEY (vendor_key, action, source_filename, source_modtime,db_insert_time),
CHECK (action in ('Incoming','Outgoing','Copy'))
)
go

CREATE INDEX sefitra_01_idx on Seg_Files_Transport_Audit(db_insert_time)
;
go

GRANT ALL on Seg_Files_Transport_Audit to PUBLIC
;

GO

