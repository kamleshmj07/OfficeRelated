use Operations

GO

IF OBJECT_ID('Vendor_Credentials') IS NOT NULL
	DROP TABLE Vendor_Credentials

;

GO

CREATE TABLE Vendor_Credentials
(vendor_key	varchar(20)	NOT NULL,
connection_type	varchar(20)	NOT NULL,
server_address	varchar(255)	NOT NULL,
username	varchar(50)	,
password	varchar(max)	,
port		smallint,
db_update_time	datetime 	NOT NULL default getdate(),
is_active	bit		NOT NULL default 1 ,
comments	varchar(255),
PRIMARY KEY (vendor_key)
)

GO

CREATE TRIGGER trigger_vendor_cred01
ON Vendor_Credentials
AFTER UPDATE 
AS
BEGIN
	UPDATE Vendor_Credentials
	SET db_update_time=getdate()
	FROM Inserted 
	WHERE Vendor_Credentials.vendor_key = Inserted.vendor_key
END

;

GO

-- create a trigger to ensure DELETES are logical!

CREATE TRIGGER trigger_vendor_cred_delete
ON
Vendor_Credentials
INSTEAD OF DELETE
AS
BEGIN
UPDATE  Vendor_Credentials
set is_active=0,
db_update_time=getdate()
FROM deleted
WHERE Vendor_Credentials.vendor_key=deleted.vendor_key
END

;

GO


-- Add data

INSERT INTO Vendor_Credentials 
(vendor_key,connection_type,server_address,username,password,comments)
VALUES
('SEI_OPS','SFTP','mfd.ftp.seic.com','IMS_SELECT_EQUITY','XTBOLluI4YUfvE','SEI Ops Production')

;

INSERT INTO Vendor_Credentials
(vendor_key,connection_type,server_address,username,password,comments)
VALUES
('FASCET','FTP','ftp.fascet.com','ftp_selectbalance','li988Q43','Fascet Baby. Not FACTSET...but the third party consulting firm/developer')
;

GO
INSERT INTO Vendor_Credentials
(vendor_key,connection_type,server_address,username,password,comments,port)
VALUES
('DEALCLOUD','FTPS','54.86.78.12','APHFTP','zSMK7g', 'Contains Data for the private equity guys.',990)
;

GO



GRANT ALL on Vendor_Credentials to PUBLIC;


