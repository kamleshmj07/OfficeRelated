 May 25, 2018

We are in introducing site-packages here. Basically, these will be specific
libraries our code needs to run, which may interfere with any standard
library on the machine.

To use a specific version:

https://stackoverflow.com/questions/6445167/force-python-to-use-an-older-version-of-module-than-what-i-have-installed-now 

From there, remember to put the site-package lib in the Common Repo in your
PYTHONPATH.

Spacibo.

NOTE - for pgp encryption to work correctly you must have both the morgan stanley  private key
(found in \\fsdev\f1\qa\TradeODS\conf) and the common private key (found in C:\workspace\Common\python\lib\SEG\utils\test)

Register them in kleopatra and then run all unit tests to verify that you have the proper dependencies

