import logging
import os

from SEG.Axys.RunAxysReport import RunAxysReport

logger = logging.getLogger(__name__)
 
class HolidayCheck():
    def __init__(self):
        self.axys_dir = 'F:\Axys3\\'
        
    def is_holiday(self):
        
        log_file = self.axys_dir + 'logs\holiday1.log'
        
        if(os.path.isfile(log_file)):
            os.remove(log_file)
        
        axys_holiday_check = RunAxysReport(self.axys_dir, macro='holiday1', portfolio='+@active')
        axys_holiday_check.start_report(no_output=True)
        
        if(os.path.isfile(log_file)):
            return True
        return False
        