import logging
import subprocess
import os
import glob
import psutil

from SEG.utils.SEGUtils import get_app_log_dir
from SEG.utils.Archive import auto_archive

logger = logging.getLogger(__name__)

class RunAxysReport():
    """A class to run Axys Report"""
    def __init__(self,axys_dir,**report_args):
        for arg in report_args:
            setattr(self, arg, report_args[arg])
            
        self.axys_dir = axys_dir
         
    def start_report(self, no_output=False): 
        """Runs the report according to the class attributes"""
        if not hasattr(self,'macro') or not self.macro:
            raise Exception("Must define a macro to run a report")
        
        args = "-u -m" + self.macro
        
        if not no_output:
            if (not hasattr(self,'out_filename') or not self.out_filename):
                raise Exception("Must define an out_filename to run a report")
            args = args + ' "-t' + self.out_filename + '"'

            self._clean_lock_files(self.out_filename)

        #Setup Command line arguments
        if hasattr(self,'portfolio') and self.portfolio:        
            args += ' "-p' + self.portfolio + '"'
        if hasattr(self,'start_date') and self.start_date:        
            if hasattr(self,'end_date') and self.end_date:
                args += ' "-b' + self.start_date + ' ' + self.end_date + '"' 
            else:       
                args += ' -b' + self.start_date
        if hasattr(self,'out_format') and self.out_format:        
            args += " -v" + self.out_format
            
        if hasattr(self,'extra_axys_params') and self.extra_axys_params:        
            args += ' "' + self.extra_axys_params + '"'
            
        
        #Run report        
        report_command = '%s\\rep32.exe %s' % (self.axys_dir, args) 
        logger.info("Running: " + report_command)
        pipe = subprocess.Popen('F:\\Axys3\\rep32.exe ' + args,shell=True)
        proc_pid = pipe.pid
        parent = psutil.Process(proc_pid)
        children_set = set([child.pid for child in parent.children(recursive=True)])
        while pipe.poll() is None:
            try:
                children_set = children_set.union(set([child.pid for child in parent.children(recursive=True)]))
            except psutil.Error:
                pass    
        pipe.wait()
        for child_pid in children_set:
            try:
                child_proc = psutil.Process(child_pid)
                child_proc.terminate()
                logger.info(str(child_proc.name) + " left running by Axys.  Process terminated.")
            except psutil.Error:
                pass
        return_code = pipe.returncode
        
        #This code has been removed because you can't rely on Axys return code 
        #if return_code > 1: 
        #    raise Exception("Axys gave return code greater than 1.  Return Code: " + str(return_code))
        if not no_output: 
            error_file = os.path.splitext(self.out_filename)[0] + '.err'
            if os.path.isfile(error_file): 
                with open(error_file, "r") as log_file:
                    log_file_str = log_file.read()
                logger.info("Axys Log: \n" + log_file_str)
                auto_archive(error_file)
            
            if not os.path.isfile(self.out_filename):
                raise Exception("Axys failed to create output file: %s" % self.out_filename)
            auto_archive(self.out_filename)
            
    def _clean_lock_files(self, clean_file):
        file_no_ext = os.path.splitext(clean_file)[0]
        for file in glob.glob(file_no_ext + ".*!"):
            os.remove(file)
        for file in glob.glob(file_no_ext + ".*$"):
            os.remove(file)
            
            
            
            
            
            