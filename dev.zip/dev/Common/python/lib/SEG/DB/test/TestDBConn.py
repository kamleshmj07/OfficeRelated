'''
Created on May 13, 2019

Test DBConn module. More for backtesting bcp routine, but use it for all.

@author: spatel
'''
import unittest
import logging
from SEG.DB.DBConn import DBConn as db_util # animal we're testing
import os # we need this because we will drive the unit test based on server config.
import tempfile
import shutil
import json

def get_dbs(json_file):
    with open(json_file) as json_file:
        data = json.load(json_file)
        databases = list(data.keys())
    return databases

class TestDBConn(unittest.TestCase):

    con = None
    directory = None
    
    
    @classmethod
    def setUpClass(self):
        logging.basicConfig(format='%(asctime)s|%(module)s|%(levelname)s|%(lineno)d|%(message)s',
                            level="DEBUG")
        log = logging.getLogger(__name__)
        log.debug("Testing Connection %s", os.environ.get("PYODBC_SERVER") )
        self.con = db_util().get_connection(conn_name=os.environ.get("PYODBC_SERVER"))
        
        self.directory = tempfile.mkdtemp()
        
    @classmethod  
    def tearDownClass(self):
        db_util().close_connection(os.environ.get("PYODBC_SERVER"))
        # clean up directory, including files.
        shutil.rmtree(self.directory)
    
    def testAllocConnection(self):
        self.assertTrue((self.con is not None), "Was there a connection allocated?")
    
    
    def testResOrderRow(self):
        values = db_util().return_ordered_resultset(self.con, "SELECT 'hello' as value")
        self.assertTrue(values[0]["value"] == "hello", "Right value?")
        
    
    # The reason why the unit test was written
    # different sql servers react differently with BCP. let's see what happens here.
    
    def testBCPInOut(self):
        log = logging.getLogger(__name__)
        sql = """
                CREATE TABLE tempdb..unit_test
                (gvkey    varchar(6) not null, iid varchar(3) not null, datadate date not null,
                company    varchar(50), currency varchar(3), volume    float,
                closing_price    float, shares_outstanding float,
                country_code     varchar(3), ticker varchar(5),
                description    varchar(100),cusip varchar(30),isin varchar(30), sedol varchar(10)
                )
                
                """
        curse = self.con.cursor()
        curse.execute("use tempdb")
        drop_sql  = """     IF OBJECT_ID('tempdb..unit_test') is not null drop table tempdb..unit_test"""
        log.info("...executing drop table")
        curse.execute(drop_sql)
        curse.commit()
        log.info("...executing create table")
        curse.execute(sql)
        curse.commit()
        
        # bcp  data in
        filename =  os.path.join(os.path.dirname(__file__), "sample_data.txt")
        log.debug("Testing - bcp data in")
        db_util().bcp_dataset(conn_name=os.environ.get("PYODBC_SERVER") ,
                           filename = filename, 
                           table_name="tempdb..unit_test",
                           column_delimiter="|", row_delimiter="|\\n")
        
        # should have bcp'ed 18 rows.
        
        row_ct = "select count(*) as ct from tempdb..unit_test "
        x = db_util().return_ordered_resultset(connection=self.con, sql=row_ct)
        self.assertTrue(x[0]["ct"] == 18, "Did the right data get bcp-ed in.")
        
        # ok...bcp out.
        bcp_file = os.path.join(self.directory,"bcp_out.txt")
        
        db_util().bcp_dataset(conn_name=os.environ.get("PYODBC_SERVER"),
                           filename = bcp_file, 
                           table_name= "tempdb..unit_test",
                           column_delimiter="|", row_delimiter="|\\n",
                           in_or_out="out")
        
        # check lines.
        f = open(bcp_file)
        count = len(f.readlines())
        f.close()
        self.assertTrue(count == 18, "Did the right data get bcp-ed out.")
        
        # we're done! drop temp
        curse.execute(drop_sql)
        curse.commit()

# -------------------------------------
class TestAllConnections(unittest.TestCase):

    json_file = os.environ.get("SQL_SERVER_CONFIG")
    all_db_conns = get_dbs(json_file)


    def test_all_connections_json_in_env(self):

        failures = []
        for server in self.all_db_conns:

            try:
                db_conn = db_util().get_connection(conn_name=server,
                                                  conn_info_file=self.json_file)

            except Exception as error:
                failures.append(server)
                print('Failed to connect with error: {}'.format(error))
        self.assertEqual(len(failures),0), 'there were failed connections for the following connection names: {}'.format(
            ', '.join(failures))

    def test_all_connections_ini(self):
        pass
        """

            No need for INI as we move forward...??? - Jan 2020
        sql_file = os.environ.get("SQL_SERVER_INI")
        failures = []
        for server in self.all_db_conns:

            try:
                db_conn = db_util().get_connection(conn_name=server,
                                                  conn_info_file=sql_file)
            except Exception as error:
                failures.append(server)
                print('Failed to connect with error: {}'.format(error))
        self.assertEqual(len(failures),0), 'there were failed connections for the following connection names: {}'.format(
            ', '.join(failures))
     """
if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()