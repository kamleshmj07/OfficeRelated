import pyodbc
import logging
import os
from collections import OrderedDict  # added July 2015
import subprocess # added August 2015

import SEG.utils.PGpy as Pg
import SEG.utils.SEGUtils as util
import pandas as pd

try:
    import configparser
except ImportError:
    import configparser as ConfigParser

class DBConn(object):
    _iInstance = {}

    class Singleton:
        def __init__(self,conn_name, conn_info_file):

            if conn_info_file.endswith('ini'):

                config = configparser.ConfigParser()
                config.read(conn_info_file)

                if not config.has_section(conn_name):
                    raise Exception("Could not find section " + conn_name + " in " + conn_info_file)
                if config.get(conn_name, "DRIVER"):
                    driver = config.get(conn_name, "DRIVER")
                else:
                    driver = os.environ.get("SQL_DRIVER")
                server = config.get(conn_name,"SERVER")
                database = config.get(conn_name,"DATABASE")
                uid = config.get(conn_name, "UID")
                pwd = config.get(conn_name, "PWD")

            elif conn_info_file.endswith('json'):
                connection_data = util.json_parser(conn_name, conn_info_file)
                database = connection_data['DATABASE']
                server = connection_data['SERVER']
                if connection_data['DRIVER']:
                    driver = connection_data['DRIVER']
                else:
                    driver = os.environ.get("SQL_DRIVER")
                uid = connection_data['UID']
                pwd_tmp = connection_data['PWD']
                pwd = Pg.decrypt_string(encrypted_string=pwd_tmp, private_key_path=os.environ.get("PGP_PRIVKEY"))

            else:
                raise Exception('Unsupported config type passed in.  Only ini and json config are currently supported')

            self.database = database
            self.server = server
            self.driver = driver

            # conn_string = ""
            # do_trusted= False
            # try:
            #     config.get(conn_name,"TRUSTED")
            #     do_trusted=True
            # except Exception:
            #     pass

            # trusted in lc :(
            # if (do_trusted):
            #     conn_string = "DRIVER=" + driver + ";SERVER=" + server + ";DATABASE=" + database + ";Trusted_Connection=yes;"
            #     self.pwd = "Trusted Connection"


            conn_string = "DRIVER=" + driver + ";SERVER=" + server + ";DATABASE=" + database + ";UID=" + uid + ";PWD=" + pwd
            self.pwd = pwd
            self.connection = pyodbc.connect(conn_string)
            # self.connection.setdecoding(pyodbc.SQL_CHAR, encoding='latin1', to=str)
            # Note below is for higher version of pyodbc, but causes issues :(
            # self.connection.setencoding(unicode, encoding='utf-8')
            # self.connection.setencoding(str, encoding='utf-8')
            # Below added by SP. August 2015

            results = DBConn().return_single_row(connection=self.connection, sql="select system_user as uid")

            self.uid = results["uid"]
  
       
            
    def __init__(self):
        pass
    # ---------------------------------------------------------------------------
        
    def get_connection(self, conn_name=None, conn_info_file=None):
        if not conn_info_file:
            conn_info_file = os.environ.get('SQL_SERVER_CONFIG')
        if not conn_name:
            conn_name = os.environ.get('PYODBC_SERVER')
        if not conn_name in DBConn._iInstance:
            DBConn._iInstance[conn_name] = DBConn.Singleton(conn_name, conn_info_file)
        self._EventHandler_instance = DBConn._iInstance[conn_name]           
        return DBConn._iInstance[conn_name].connection
    
    # ---- If we're running this in a python "virtual instance", the close_connection should be used with the pool
    
    def close_connection(self,conn_name):
        log = logging.getLogger(__name__) 
        # check to see if connection is open
        if (conn_name in DBConn._iInstance):
            try:
                # close connection
                DBConn._iInstance[conn_name].connection.close()
                
            except Exception as e:
                log.warn("Attempted to close connection %s. Failed with %s.", conn_name, str(e))
                log.warn("...Continuing.")
                
            DBConn._iInstance.pop(conn_name)
        else:
            log.warn("%s connection does not exist in the Connection Pool!", conn_name)
    # --------------------August 2015 below....getters had to be done ----------------
    def get_user_id(self, conn_name=None):
        conn_name = util.get_db_conn_name(conn_name)
        return DBConn._iInstance[conn_name].uid
    def get_password(self,conn_name):
        conn_name = util.get_db_conn_name(conn_name)
        return DBConn._iInstance[conn_name].pwd
    def get_server(self,conn_name):
        conn_name = util.get_db_conn_name(conn_name)
        return DBConn._iInstance[conn_name].server
    def get_driver(self,conn_name):
        conn_name = util.get_db_conn_name(conn_name)
        return DBConn._iInstance[conn_name].driver
    # ------------------------------------------------------------------------------
    def bcp_dataset (self, conn_name, filename, table_name, 
                     column_delimiter=None, 
                     row_delimiter=None,
                     first_line=None ,in_or_out="in"):
        """
        We are making an assumption. That whatever connection was previously established, well...using
        those parameters we will be bcp-ing there also.i.e. same server.
        """
        
        log = logging.getLogger(__name__) 
        command = "bcp "
        log.info("Yo...about to bcp file %s to table %s. Constructing bcp command.", filename,table_name)
        command +=  table_name + " " + in_or_out + "  \""+ filename + "\"  -c -S " + self.get_server(conn_name)
        command +=  "  -U " + self.get_user_id(conn_name) + " -P " + self.get_password(conn_name)
        if (first_line is not None):
            command+= " -F " + first_line
        if (column_delimiter is not None):
            command+= "  -t \"" + column_delimiter + "\""
        if  (row_delimiter is not None):
            command+= " -r \"" + row_delimiter + "\""
        log.info("About to do system call: %s" , command)
        
        
        proc = subprocess.Popen(command, stdout=subprocess.PIPE,
                                stderr= subprocess.STDOUT,bufsize=0)

        (poutput, perror) = proc.communicate()

        if (proc.returncode is not None):
            log.debug("The return code is %d", proc.returncode)

        if (poutput.lower().find(b"error") > 0):
            log.warn("Possible Error! %s", poutput)
            log.warn("Double checking regex")
            if (b"Warning: BCP import with a format file will convert empty strings" in poutput):
                log.info("...looks like warning message. We will continue")
            else:
                raise NameError("BCP Failure!")
        else:
            log.info("Output Received: %s", poutput)
        
        if (proc.returncode is not None ) and (proc.returncode != 0):
            log.fatal("%s = error", perror)
            log.fatal("WHOA! Load on table name %s failed. We will raise-error!. See output above", table_name)
            raise NameError("BCP Failure!")
       
        log.info("...we believe things went well. Onward!")
    
    # -------------------------------------------------------------
    
    def return_ordered_resultset(self,connection, sql):
        """ Execute a SQL - preferrably something with result set, and return in an
         Ordered Dictionary.
        """
        log = logging.getLogger(__name__)
        log.debug("...getting cursor")
        cur = connection.cursor()
        log.debug("...executing sql: %s", sql)
        cur.execute(sql)
        columns =  [i[0] for i in cur.description]
        log.debug("Columns = %s", str(columns))

        results = []

        for row in cur.fetchall():
            results.append(OrderedDict(list(zip(columns, row))))

        cur.close()

        return results
    
    # frigging useless. Need to review if used - SP May 2018
    def return_single_row(self,connection, sql):
        full_result_set = self.return_ordered_resultset(connection, sql)
        if len(full_result_set) > 0:
            return full_result_set[0]
        else:
            return {}

    def return_dataframe(self, connection, sql):
        df = pd.read_sql_query(sql, connection)
        return df
            
        
        