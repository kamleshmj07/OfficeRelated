from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import mimetypes
import smtplib
import getpass
import os


class SEGMail:

    """Mail class for SEG applications"""
    def __init__(self, **email_args):
        self.subject = ""
        self.to_addresses = []
        self.cc_addresses = []
        self.email_from = "AxysAuto@selectequity.com"
        self.smtp = "mx.selectequity.com"
        for arg in email_args:
            setattr(self, arg, email_args[arg])

        self.message = MIMEMultipart()
        self.message_body = ''
        self.is_body_html = False
        self.attachments = []

    def send_message(self):
        """Sends the email message"""
        if self.is_body_html:
            self.message.attach(MIMEText(self.message_body, 'html'))
        else:
            self.message.attach(MIMEText(self.message_body, 'plain'))

        for attachment in self.attachments:
            self.message.attach(attachment)
        
        self.message['Subject'] = self.subject
        self.message['From'] = self.email_from
        self.message['To'] = ', '.join(self.to_addresses) 
        self.message['CC'] = ', '.join(self.cc_addresses) 
        
        sender = smtplib.SMTP(self.smtp)
        sender.sendmail(self.email_from, self.to_addresses + self.cc_addresses,
                        self.message.as_string())
        
    def insert_attachment(self, filename):
        """Adds attachment to email message."""
        maintype, subtype = mimetypes.guess_type(filename)
        attachment = MIMEBase(maintype, subtype)
        attachment.set_payload(open(filename, 'rb').read())
        attachment.add_header('Content-Disposition', 'attachment',
                              filename=os.path.basename(filename))
        encoders.encode_base64(attachment)
        self.attachments.append(attachment)


def main():
    m = SEGMail()
    m.to_addresses = [getpass.getuser() + "@selectequity.com"]
    m.send_message()


if __name__ == "__main__":
    main()
    print("email(s) sent")
