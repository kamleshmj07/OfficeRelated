# Email Tests

This directory contains some testing units for the SEGMail module.

## Files
* `Email/`
    * `test/`
        * `__init__.py`
        * `README.md`
        * `TestSendEmail.py`
    * `__init__.py`
    * `SEGMail.py`
    
## `TestSendEmail`

* Asserts that default values have been properly set
* Uses a mock smtp server to check that emails are, indeed, sent
    * Mock sent to `<username>@selectequity.com` - no email is actually sent out
    * Detected email address can be changed by modifying `get_tester_email()`
* Checks that the number of attachments is logical
* Tests for different capabilities, such as attaching, cc'ing, etc.
    * Uses temp files to test with
