# to run python coverage reports on this module:
# $ python -m coverage run TestSendEmail.py
# $ python -m coverage report SEGMail.py
#   a cmd line report will be printed out
# $ python -m coverage html
#   the html report will be found in htmlcov/index.html

import SEG.Email.SEGMail as seg_email
import SEG.utils.FileZipper as zipper
from mock import patch
import unittest
import tempfile
import getpass
import zipfile
import os


class TestSendEmail(unittest.TestCase):

    @classmethod
    def setup_email(cls):
        """ Initialize. """
        x = seg_email.SEGMail()
        x.to_addresses = [cls.get_tester_email()]
        cls.to_delete = []
        return x

    @classmethod
    def tear_down(cls, files_to_delete, dirs_to_delete=None):
        """ takes in a dir of file paths (and optionally a dir of
        dir paths) and deletes them """
        for f in files_to_delete:
            os.remove(f)
        if dirs_to_delete is not None:
            for d in dirs_to_delete:
                for root, dirs, files in os.walk(d, topdown=False):
                    for name in files:
                        os.remove(os.path.join(root, name))
                    for name in dirs:
                        os.rmdir(os.path.join(root, name))

    @classmethod
    def get_tester_email(cls):
        """ Return current user's email for testing purposes. """
        username = getpass.getuser()
        #username = 'logsgravitas' #This line is kept for testing email
        return username + "@selectequity.com"

    @classmethod
    def create_file(cls, d=tempfile.gettempdir(), contents=None):
        """ Creates tempfile, w/ optional contents to write. """
        if d is not None:
            d = os.path.join(tempfile.gettempdir(), d)
        d = os.path.normpath(d)
        f = tempfile.NamedTemporaryFile(dir=d, delete=False)
        if contents:
            f.write(contents.encode())
        return f.name

    def test_init_state(self):
        """ Tests that the default values of email instance are correct. """
        x = self.setup_email()

        # test that default sender is correct
        self.assertEqual(x.email_from.lower(), "axysauto@selectequity.com",
                          "default sender axysauto@selectequity.com")

        # test that default server is correct
        self.assertEqual(x.smtp.lower(), "mx.selectequity.com",
                          "default server mx.selectequity.com")

        self.assertFalse(x.is_body_html, "default email body not in html")

        self.assertEqual(x.to_addresses, [self.get_tester_email()])
        self.assertEqual(x.cc_addresses, [])
        self.assertEqual(x.subject, "")

    def test_send_email(self):
        """ Check with mock server that emails are sent out. """
        with patch("smtplib.SMTP") as mock_smtp:
            x = self.setup_email()
            x.subject = "This is the subject line"
            x.send_message()

            instance = mock_smtp.return_value

            # make sure that mail has been sent out
            self.assertTrue(instance.sendmail.called)

            # make sure mail sent out exactly 1 time
            self.assertEqual(instance.sendmail.call_count, 1)

    def test_attachments_attached(self):
        """ Check that number of attachments is correct. """
        x = self.setup_email()

        to_attach = self.create_file(contents="hello!")
        x.insert_attachment(to_attach)
        self.assertEqual(len(x.attachments), 1)

        one = self.create_file(contents="uno")
        two = self.create_file(contents="dos")
        three = self.create_file(contents="tres")

        for i in [one, two, three]:
            x.insert_attachment(i)
        self.assertEqual(len(x.attachments), 4)

        self.tear_down([one, two, three, to_attach])

    def test_send_empty_email(self):
        """ Sends an empty email. """
        x = self.setup_email()
        x.send_message()

    def test_send_empty_email_with_cc(self):
        """ Sends and cc's an empty email. """
        x = self.setup_email()
        x.cc_addresses = [self.get_tester_email()]
        x.subject = "This email cc's someone"
        x.send_message()

    def test_send_email_with_subject_line(self):
        """ Sends an email with a nonempty subject line. """
        x = self.setup_email()
        x.subject = "This is a subject line"
        x.send_message()

    def test_send_email_with_contents(self):
        """ Sends an email with text in the message body. """
        x = self.setup_email()
        x.subject = "This email has content"
        x.message_body = "Message Contents"
        x.send_message()

    def test_send_email_with_html_contents(self):
        """ Sends an email containing html. """
        x = self.setup_email()
        x.subject = "This email contains html"
        x.is_body_html = True
        x.message_body = "<b><i> Bold, Italicized Message Contents </i></b>"
        x.send_message()

    def test_send_email_with_attachment(self):
        """ Sends an email with a text attachment. """
        x = self.setup_email()
        x.subject = "This email has an attachment"
        x.message_body = "Message Contents"
        f = self.create_file(contents="Hi! Make sure this file isn't corrupted in the process")
        x.insert_attachment(f)
        x.send_message()
        self.tear_down([f])

    def test_send_email_with_mult_attachments(self):
        """ Sends an email with multiple text attachments. """
        x = self.setup_email()
        x.subject = "This email has multiple attachments"
        x.message_body = "Message Contents"
        one = self.create_file(contents="wow, first file")
        two = self.create_file(contents="wow, second file")
        for i in [one, two]:
            x.insert_attachment(i)
        x.send_message()
        self.tear_down([one, two])

    def test_send_email_with_zip_dir_attachment(self):
        """ Sends an email with a zip folder containing multiple files. """
        x = self.setup_email()
        x.subject = "This email has a zip attachment with many files"
        x.message_body = "Message Contents"
        dir = tempfile.mkdtemp()
        one = self.create_file(dir, "wow, first file")
        two = self.create_file(dir, "wow, second file")
        zipf = zipfile.ZipFile(dir+".zip", 'w', zipfile.ZIP_DEFLATED)
        _, zipped_file = zipper.zipdir(path=dir, ziph=zipf, pattern="*.*", foldername=dir+".zip")
        x.send_message()
        zipf.close()
        self.tear_down([one, two, zipped_file], [dir])

    def test_send_email_with_zip_file_attachment(self):
        """ Sends an email with a zipped file attachment. """
        x = self.setup_email()
        x.subject = "This email has a zipped file"
        x.message_body = "Message Contents"
        f = self.create_file(contents="hello there")
        zipped_file = zipper.zip_files([f], f)
        x.insert_attachment(zipped_file)
        x.send_message()
        self.tear_down([f, zipped_file])


if __name__ == "__main__":
    unittest.main()
