

"""
    FileServices will be broken down into two classes:
        1.) AzureStorageObj - an encapsulated object built over the Azure File Storage Sytem
        2.) DiskStorageObj - good old windows/linux hard drives using the os module to determine things.
    
    https://azure-storage.readthedocs.io/ref/azure.storage.file.fileservice.html  for reference
        on Azure

    BE AWARE! The main is meant to move files from the local filesystem to the azure share.
    Once the files/directories move, it cannot be undone! The idea is this little ditty of a script
    will be moving //fsdev/f1 files locally to an Azure file system. While this can easily
    be done by the SMB protocol manually, with some adjustments, we are doing it programatically
    via the REST API for Azure.
    
"""


import logging
import logging.config
import os
import shutil
from datetime import datetime as dtt
import datetime
from pathlib import Path
import time
import psutil
import glob
from azure.storage.file import ContentSettings, FileService, models

import sys # used by main
import argparse # used by main

class AzureStorageObj(object):
    """
    
    """

    def __init__(self, azure_account_name, azure_account_key):
        self.account_name = azure_account_name
        self.account_key = azure_account_key
        log:logging = logging.getLogger(__name__)
        log.debug("...connecting to azure.")
        file_service = FileService(account_name=azure_account_name, 
                                   account_key=azure_account_key)
        log.debug("...connected to azure under azure resource %s. ",azure_account_name )
        self.file_service =  file_service
        log.debug("....getting shares on the storage.")
        self.__get_shares()
        log.debug("...shares retrieved.")
     
     
    def __get_shares(self):
        # Do not include snapshots taken. Snapshots are backups.
        # We will deal with snapshots differently.
        shares = list(self.file_service.list_shares(include_snapshots=False))
        self.shares = {}
        for dr in shares :
            # azure.storage.file.models.Share is the object we're storing!
            self.shares[dr.name]= dr


    """
    Get a list of share names for the resource we are connected to!
    
    Returns:
        list of string -- um...yeah. share names :)
    """         
    def get_share_names(self):
        return self.shares.keys()



    """
    Before you can place a file, a directory must exist. Create method to allow
    for "nested directory structure" to be created, with SMB properties!

    NOTE - we expect the paths to be consistent with the os delimiter. In other
    words, if you use backward slash, use it throughout. You will not be able to mix
    and match "/" and "\"

    The "dir_path" will rely on the os delimiter.
    
    Returns:
        True. Fails if directory can't created.
    """
    def create_nested_directory(self,dir_path,share_name,
                                sep = os.path.sep,
                                original_dir_path=None, inherit_smb=False):
        log = logging.getLogger(__name__)
      
        log.debug("Path Seperator:%s", sep)
        splitme = dir_path.split(sep)
        current = ""
        for checkme in splitme:
            if len(splitme) > 1:
                current += checkme + sep
            else:
                current = dir_path

            log.debug("Checking for directory %s on Azure", current)
            if (not self.file_service.exists(share_name=share_name, directory_name=current)):
                
                # we have been asked to propogate smb properties to azure.
                if (inherit_smb and original_dir_path is not None):
                    dir = original_dir_path 
                    log.debug("Check SMB properties for %s" , dir)
                    ctime = dtt.fromtimestamp(os.path.getctime(dir), datetime.timezone.utc)
                    mtime = dtt.fromtimestamp(os.path.getctime(dir), datetime.timezone.utc)
                    smb = models.SMBProperties(creation_time=ctime.strftime('%Y-%m-%dT%H:%M:%S.%f0Z'),
                    last_write_time=mtime.strftime('%Y-%m-%dT%H:%M:%S.%f0Z'))
                    self.file_service.create_directory(share_name=share_name, directory_name=current,smb_properties=smb)
                else:
                    self.file_service.create_directory(share_name=share_name, directory_name=current)
        # precaution. share has been modified on time.
        # self.__get_shares() - does not modify share properties.
        return True
                    

    def check_if_share_exists(self, share_name):
        # can use exists...it is more expensive? Assume it is as you are making a rest call.
        
        if (share_name in self.shares):
                return True
        else:
                return False      
    
    # Unless specified, we will create 1 TB limit per share
    def create_share(self, share_name, quota=1000, metadata=None):
        log = logging.getLogger(__name__)
        try:
            self.file_service.create_share(share_name, metadata=metadata, quota=quota, fail_on_exist=True)
            self.__get_shares()
        except Exception as e:
            log.fatal("Unable to create file share:%s. Remember - no special characters!!",str(e))
            return e
            
    # delete a share
    def delete_share(self, share_name):
        log = logging.getLogger(__name__)
        try:
            log.info("...about to delete share %s ", share_name)
            self.file_service.delete_share(share_name,  fail_not_exist=True)
            self.__get_shares()
        except Exception as e:
            log.fatal("Unable to delete file share:%s !!",str(e))
            return e
    
    """ In Gigabytes
        Note - this is Azure's "rough" estimate. And I mean rough. They may be doing an upper.
        If we want to make the process better, we will need to implement this logic in
        python:
            https://stackoverflow.com/questions/44876642/how-to-get-or-calculate-size-of-azure-file-share-or-service
    
    """
    def get_share_space_used_gb (self, share_name):
        log = logging.getLogger(__name__)       
        log.debug("Using Azure rough estimate for share %s .", share_name)
        return self.file_service.get_share_stats(share_name)

            
    """ In Gigabytes """   
    def get_share_quota_gb(self, share_name):  
        return self.shares[share_name].properties.quota
    
    def get_share_last_modified(self,share_name):
        return self.shares[share_name].properties.last_modified
    
    def set_share_quota_gb(self,share_name,quota):
        self.file_service.set_share_properties(share_name, quota)
        # after this is done, reload the data.
        time.sleep(2) # um...just in case. Cloud can have a lag.
        self.__get_shares()
    

    def __get_azure_directory_smb_struct(self,share_name,path):
        dirprop = self.file_service.get_directory_properties(share_name=share_name, directory_name=path)
        create =  dirprop.properties.smb_properties.creation_time
        mod  = dirprop.properties.smb_properties.last_write_time
        age = dtt.now() - create
        # NOTE NOTE NOTE ....do we do file here? hmmm....
        struct = {"days_aged":  age.days, "directory_name" : path,
                                "create_date": create,
                                "last_touched":  mod,
                                "files" : None
                            }
        return struct
    
    """
        Replicate data structure of the same method for DiskStorageObject.

        So: Object[directory_name]
            Object[directory_name][component] where component can be:
                     
        age_of_dir = How old is the directory, in days
        files = will include a list of files, underneath that sub_dir_level, including full paths
        create_date = when was it created
        last_touched = when was the directory last touched
     
        if we're dealing with the base directory, the key will be "."

        Note : If SMB properties exist, we will use that, otherwise use Azure property.

    """
    def get_base_directory_info(self,share_name, path):
        log = logging.getLogger(__name__)  
        log.warning(" Note - this has not been properly implemented!")
        log.warning(" It will give information on the path level, and not recursively!")
        log.warning("...be forewarned. Recursion will eventually be implemented.")
         # Also note https://stackoverflow.com/questions/44862969/azure-file-storage-fetch-all-files-recursively-in-a-single-request
        ds = {}
        listme = list(self.file_service.list_directories_and_files(share_name=share_name, directory_name=path))
        log.debug("data retrieved. %d elements", len(listme))
        filesinroot = []
        # walk thru.
        for item in listme:
            log.debug("Checking out %s", item.name)
            if (isinstance(item, models.Directory)):
                log.debug("%s is a directory. ", item.name)
                # get age_of_dir, create_date, last_touched, based on Directory properties.
                # step 1 ...trust smb over cloud.
                # But Note: https://stackoverflow.com/questions/54408738/how-to-use-get-file-properties-rest-api-for-azure-files-storage-using-python
               
                fullpath = path+"/"+item.name
                log.debug("Requesting properties on %s", fullpath)
                ds[item.name] =  self.__get_azure_directory_smb_struct(share_name, fullpath)
            else:
                # assume file.
                fullpath = path+"/"+item.name
                filesinroot.append(fullpath)
        # append filesinroot back to base.
        log.info("...calling azure on path :%s", path)
        ds["."] =  self.__get_azure_directory_smb_struct(share_name, path)
        ds["."]["files"] = filesinroot
        ds["."]["directory_name"] =  "." # be consistent how we deal with local disk
        return ds

    
    """

    TODO TODO
     required when we monitor space usage on azure.
    Returns:
        int  -- in GB!
    """
            
    def get_directory_size_gb(self, share_name, path):
        pass

    """
        We will use this method to move data to Azure. The way this method will work:
        
        1.) Check if the share_name exists. 
        2.) If the share does not exist, fail. 
        3.) If "directory_on_azure" is not passed, we will use the directory on the local file level.
        3a.) If "directory_on_azure" was passed, make sure it exists on the share.
        3b.) If "prefix_to_strip" exists, strip out this value from local file level directory to recreate on azure.

        4.) it directory_on_azure or the other one does not exist, create it.
        5.) Copy Files. Ensure all files are copied. 
        6.) Returns list of files, and true if it deleted. False if there were issues.
        
        Note:
            local_file = list of filenames
            share_name = share on azure

    """
    def copy_local_files(self, share_name,
                        local_files,
                        directory_on_azure=None,  
                        prefix_to_strip=""):

        log = logging.getLogger(__name__)
        return_me = {}
        if (not self.check_if_share_exists(share_name)):
            log.fatal("Share Name %s does not exist. Create it first. Failing.", share_name)
            sys.exit(-1)
        log.info("We have %d files to copy!", len(local_files))
        file_processed  = 0
        log.debug("Directory on Azure:%s. Checking existence.", directory_on_azure)
        
        if (directory_on_azure is not None):
             if (not self.file_service.exists(share_name=share_name, directory_name=directory_on_azure)):
                log.info("Directory %s does not exists on Azure. Creating it.", directory_on_azure)
                self.create_nested_directory(share_name=share_name, dir_path=directory_on_azure)
                log.debug(" Directory %s on share %s created!", directory_on_azure, share_name )

        for fname in local_files:
            log.debug("Processing file path %s.", fname)

            dir_path = os.path.dirname(fname)
            dir_path = dir_path.replace(prefix_to_strip,"")
            # log.debug("Directory on Azure:%s. Checking existence.", directory_on_azure)
            if (directory_on_azure is not None):
                # log.info("I am here -log.--%s--, --%s--", dir_path, directory_on_azure)
                if (dir_path != ''):   # i.e. local dir if blank
                    dir_path = os.path.join(directory_on_azure,dir_path)
                else:
                    dir_path = directory_on_azure
                # log.info("I am here -log.%s", dir_path)
            else:
                log.warning("Azure Directory not passed. Base dir of the file will be directory")
                log.warning("...Azure may reject due to naming conventions!")
              
            # check if directory exist
            log.debug("Checking on path %s", dir_path)
            if (not self.file_service.exists(share_name=share_name, directory_name=dir_path)):
                log.info("Directory %s does not exists on Azure. Creating it.", dir_path)

                self.create_nested_directory(share_name=share_name, dir_path=dir_path,
                inherit_smb=True, original_dir_path=os.path.dirname(fname))

            # Create SMBProperties first.
            ctime = dtt.fromtimestamp(os.path.getctime(fname), datetime.timezone.utc)
            mtime = dtt.fromtimestamp(os.path.getmtime(fname), datetime.timezone.utc)
            smb = models.SMBProperties(creation_time=ctime.strftime('%Y-%m-%dT%H:%M:%S.%f0Z'),
                                       last_write_time=mtime.strftime('%Y-%m-%dT%H:%M:%S.%f0Z')
                                       )
            metadata = {"comments": "Original location:" + fname}
            try:
                self.file_service.create_file_from_path(share_name=share_name, 
                                        local_file_path = fname,
                                        directory_name=dir_path, 
                                        smb_properties=smb, metadata=metadata,
                                        file_name=os.path.basename(fname))
                return_me[fname]=True
                file_processed+=1
            except Exception as e:
                log.error("Error uploading to azure:%s. We will continue.", str(e))
                log.error("Local filename=%s", fname)
                return_me[fname]=False
        log.info("%d files processed out of %d", file_processed, len(local_files))
        return return_me
            
# ------------------------------------------------------------------------------
    
    """ WARNING - if you start manipulating the share object, the state of the file service object
        here may no longer reflect the actual properties of the share
    """
    def get_share_obj(self, share_name):
        return self.shares[share_name]


# =============End of Azure Object ================================================================

class DiskStorageObject(object):
    """ Will use OS module to get basic directory system requirements
    """

    def __init__(self, path=None):
        if (path is None):
            return
        self.disk_object = psutil.disk_usage(path)
        self.path_given = path
    
    def get_object_level_share(self):
        return self.path_given
    def get_share_quota_gb(self):
        return float(self.disk_object.total)/1073741824
    def get_share_space_used_gb (self):
        return float(self.disk_object.used)/1073741824
    
    def get_percent_used(self):
        return self.disk_object.percent
    

    """ In Gigabytes"""
    def get_directory_size_gb(self,path):
        # kudos to stackexchange.
        # https://stackoverflow.com/questions/1392413/calculating-a-directorys-size-using-python
        root_directory = Path(path)
        x = sum(f.stat().st_size for f in root_directory.glob('**/*') if f.is_file() )
        return  (x/1048576)/1024 # Bytes to megabytes to GB :)
   

    """
    This method will get a hash, where the key is the subdir,  encompassing this type of data structure:
    
     
        age_of_dir = How old is the directory, in days
        files = will include a list of files, underneath that sub_dir_level, including full paths
        create_date = when was it created
        last_touched = when was the directory last touched
     
    if we're dealing with the base directory, the key will be "."
    
    """
    def get_base_directory_info(self, local_path ):
        log = logging.getLogger(__name__)

        ds = {}

        for root, dirs, files in os.walk(local_path, topdown=True):
            if (root == local_path):
                # this happens once. It is here we want to see the directories, and any files
                # on the base level.
                for name in dirs:
                    # get
                    fullpath = os.path.join(root,name)
                    # below is a hint on ctime. Python 3 thing.
                    ctime: datetime = dtt.strptime(time.ctime(os.path.getctime(fullpath)),"%a %b %d %H:%M:%S %Y")
                    diff  = dtt.now() -  ctime
                    struct = {"days_aged":  diff.days, "directory_name" : fullpath,
                                "create_date": ctime,
                                "last_touched":  dtt.strptime(time.ctime(os.path.getmtime(fullpath)),"%a %b %d %H:%M:%S %Y"),
                                "files" : []
                            }
                    ds[name] = struct
                f = []
                for name in files:
                    fullpath  = os.path.join(root, name)
                    f.append(fullpath)
                if (len(f) > 0):
                    ctime: datetime = dtt.strptime(time.ctime(os.path.getctime(root)), "%a %b %d %H:%M:%S %Y")
                    diff = dtt.now() - ctime
                    ds["."] = {"days_aged":  diff.days, "directory_name" :".",
                                "create_date": ctime,
                                "last_touched":  dtt.strptime(time.ctime(os.path.getmtime(root)),
                                "%a %b %d %H:%M:%S %Y"),
                                "files" : f
                            }
            else:
                #  "normal case" -
                if (len(files) > 0):
                    # we only care about the files
                    f = []
                    for name in files:
                        fullpath = os.path.join(root,name)
                        f.append(fullpath)
                    #ok ...we need to store our keys
                    log.debug("Root = %s. Number of files %d", root, len(files))
                    for what_struct in ds.keys():
                        log.debug("What Struct : %s", what_struct)
                        if (what_struct in root):
                            log.debug("Going through %s", what_struct)
                            # we found where to store shit
                            struct = ds[what_struct]
                            struct["files"]+=f
                            ds[what_struct] = struct

        return ds

# ----- main ----------------------
if __name__ == '__main__':
    # Let main, be main. no need for main()
    arg_parser=argparse.ArgumentParser()
    # azure account key and name need to be setup.
    # will be environment variable based.
    arg_parser.add_argument("--azure-resource",help="resource + tenant",
                            default = os.environ.get("AZURE_RESOURCE"))
    
    arg_parser.add_argument("--azure-key",
                            help="key will go with the resource!", 
                            default = os.environ.get("AZURE_KEY") )
    
    # the main here will be situated to moving one location (theory - on locale)
    # to the azure storage.
    
    arg_parser.add_argument("--local-source",
                            help="Source directory where the subdirs will be copied and deleted from. This can be globbed!", 
                            required = True )
    
    arg_parser.add_argument("--azure-share",
                            help="Share locale on Azure! If it does not exist, create it.", 
                            required = True )
    
    arg_parser.add_argument("--from-age", type=int,
                            help="Only move subdirs aged a certain # of days. If nothing passed, move all.", 
                            default = None )
    
    arg_parser.add_argument("--to-age", type=int,
                            help="Max Age! if you want move files up to 1 year old, put 365 here or something!", 
                            default = None )

    arg_parser.add_argument("--prefix-to-strip",
                            help="Prefix to strip from from local source directory, before replicating directory on azure.", 
                            default = None )
    
    arg_parser.add_argument("--azure-directory",
                            help="Directory on Azure which we will copy files to. prefix-to-strip will be ignored.", 
                            default=None
                            )

    arg_parser.add_argument("--delete-local", action="store_true" ,
                            help="pass --delete-local if you want to delete local file after copy to azure."
                            )


    options = arg_parser.parse_args()
    logging.config.fileConfig(os.environ.get("PY_LOG_CONFIG"),
                              defaults={'filename_append': options.azure_resource,
                                        'run_id': options.azure_share})

    log = logging.getLogger(__name__)
    log.debug ("Checking age range. ")
    if (options.to_age is not None) or (options.from_age is not None):
        if (options.from_age is None):
            log.fatal("Can't have a to-age, and from_age is not defined.")
            log.fatal(" from-age and to-age must be a range.")
            sys.exit(1)

        if ( (options.to_age is not None)  and (options.from_age >= options.to_age) ):
            log.fatal("To age is less than from age. %d > %d. Can't have that!",options.from_age, options.to_age)
            sys.exit(-1)

    # ranges checked.

    log.info("Scanning local source %s", options.local_source)
    items_found = glob.glob(options.local_source)
    if (len(items_found) == 0):
        log.warning("No directories with %s were globbed! Exiting!", options.local_source)
        sys.exit(0)

    log.info("Results yielded:%d", len(items_found))
    # at this point, create connection to azure, then create share if required.
    log.debug("Azure Account=%s", options.azure_resource)
    log.debug("Azure key=%s", options.azure_key)
    az_con = AzureStorageObj(azure_account_name = options.azure_resource,
                             azure_account_key =  options.azure_key)
    
    log.debug("Check if share %s exists on the az resource.", options.azure_share)
    if (not az_con.check_if_share_exists(options.azure_share)):
        metadata = {}
        metadata["glob_pattern"] = options.local_source
    
        if (options.from_age is not None):
            metadata["comments"] = "Age range " + str(options.from_age) + " days "
        if (options.to_age is not None):
            metadata["comments"]+= " to " + str(options.to_age) + " days "
        az_con.create_share(share_name=options.azure_share,metadata=metadata)
        log.info("Azure share %s created on resource %s", options.azure_share, options.azure_resource)

    bad_files = 0
    files_proc = 0
    for fitem in items_found:
        log.debug("File path to process : %s .", fitem)
        # get our object!
        ldisk  = DiskStorageObject().get_base_directory_info(local_path=fitem)
        
        # we need to traverse through the keys bro.
        # check the age. Do the needful
        
        for k in ldisk.keys():
            this_run_good=True
            aged = ldisk[k]["days_aged"]
            log.debug("Processing sub dir %s. Age: %d",k, aged)
            if  ( (    (options.from_age is None) and (options.to_age is None)) or
                    (options.from_age <= aged) and (aged <= (options.to_age or 1e9))):
                log.info("Days Aged :%d. Moving %s to Azure. ", aged, k)
                retcall  = az_con.copy_local_files( share_name =  options.azure_share,
                        local_files =  ldisk[k]["files"],
                        directory_on_azure=options.azure_directory,  
                        prefix_to_strip=options.prefix_to_strip)
                
                
               
                for f in ldisk[k]["files"]:
                    if (retcall[f]):
                        files_proc+=1
                        if (options.delete_local):
                            log.info("Deleting file %s as delete local flag is on.", f)
                            os.remove(f)

                    elif (not retcall[f]):
                        log.warn("We will not delete %s. Azure Copy Failed",f)
                        bad_files +=1
                        this_run_good=False
                
                
                if (this_run_good and options.delete_local):
                    log.info("Looks like files were deleted. Clean up and prune dir %s",
                                ldisk[k]["directory_name"])
                    shutil.rmtree(ldisk[k]["directory_name"])
    
    log.info("%d files were sent to Azure. %d files failed on the upload (or possible delete)!", files_proc, bad_files)
    if (bad_files > 0):
        log.fatal("...failing as not all files were moved!")
        sys.exit(-2)
    else:
        log.info("....done.")