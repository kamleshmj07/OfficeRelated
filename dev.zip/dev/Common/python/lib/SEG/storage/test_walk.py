
import os
for root, dirs, files in os.walk("//fsdev/f1/qa/ETL/archive"):
   print("Root -> ", root, "dirs->", dirs, "files->", files)
   for name in files:
      print(os.path.join(root, name))
   for name in dirs:
      print(os.path.join(root, name))