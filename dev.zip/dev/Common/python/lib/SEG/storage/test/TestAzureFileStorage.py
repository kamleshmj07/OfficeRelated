import unittest
import logging
import os
from SEG.storage.StorageObjects import AzureStorageObj
from datetime import datetime as dtt
import glob

class TestAzureFileStorage(unittest.TestCase):
    log = None

    @classmethod
    def setUpClass(cls):
        logging.basicConfig(format='%(asctime)s|%(module)s|%(funcName)s|%(levelname)s|%(lineno)d|%(message)s',
                            level="INFO")
        # We want to play with a share . To avoid bumping into legit shares..
        # let's call "test_YYYYMMDD_HHMM". we will create it, and then on teardown, delete the share.
        # set up azure key and account here also!
        cls.log = logging.getLogger(__name__)
        account_name = "segazfile1dev"
        account_key = "Nup7QSjk4+bfh6TIeNqZ8SumUpnt6E7ttldVHn5jsiXln249oe8sUyEoMjEyVh2YG1sgg2XwbV3c62MIW1fkOQ=="
        # Connect bro
        cls.az = AzureStorageObj(azure_account_name=account_name, azure_account_key=account_key)
        # ok. now... create the share.
        cls.share_name  = dtt.now().strftime("%Y%m%d")
        cls.log.debug("About to create share name = %s", cls.share_name)
        cls.az.create_share(cls.share_name)
       
    @classmethod
    def tearDownClass(cls):
        cls.az.delete_share(cls.share_name)
        return super().tearDownClass()


    def testIfShareExists(self):
        self.assertEqual(True,
        self.az.check_if_share_exists(share_name=self.share_name),
        "Does share name exists? Should be TRUE!")    
    
    def testSharesDoesNotExists(self):
        self.assertEqual(False,
        self.az.check_if_share_exists(share_name="DudeDontExist"),
        "Does share name exists? Should be False!")    
    
    def testShareQuota(self):
        self.assertEqual(1000,
        self.az.get_share_quota_gb(share_name=self.share_name)     ,
        "Does the new share = 1000 gb?" )

        # change the quota

        self.az.set_share_quota_gb(share_name=self.share_name, quota=2000)
    
        self.assertEqual(2000,
        self.az.get_share_quota_gb(share_name=self.share_name) ,
        "Does the new share = 2000 gb?" )
    
    def testSpaceUsed(self):
        self.assertLessEqual(0,self.az.get_share_space_used_gb(share_name=self.share_name))

    def testNestedDirectory(self):
      
        x = self.az.create_nested_directory(dir_path="seg/was/here", 
        share_name=self.share_name, sep="/")

        self.assertTrue(x, "Was nested remote directory created?")

        # get smb properties

        props = self.az.get_base_directory_info(share_name=self.share_name, path="seg/was")
        # does the base exist there? :)
        self.assertTrue("." in props, "Does Base Directory in Azure exist?")
        #  does here exist?
        self.assertTrue("here" in props, "Is the nested directory there?")

        # create_date = last_touched

        self.assertEqual(props["here"]["create_date"], props["here"]["last_touched"],"Does createtime=lasttouched")

    def testCopyLocalFiles2AZ(self):

        # we want to change cwd to here
        cwd=os.path.dirname(os.path.realpath(__file__))
        self.log.info("Changing cwd to %s", cwd)
        os.chdir(cwd)
        # this_dir = "//fsdev/f1/qa37/Common/lib/SEG/utils/test" #os.path.dirname(os.path.realpath(__file__))
        globfiles = glob.glob("Test*.py") # Will this always work?
        self.log.debug("Files are %s", globfiles)
        """
        self.az.copy_local_files( share_name = self.share_name,
                        directory_on_azure="filecopy",
                        local_files= globfiles)
        """
        # load to the share level.
        self.az.copy_local_files( share_name = self.share_name,
                        local_files= globfiles)
        # there should be 3 right now. Check.

        generator_az = self.az.file_service.list_directories_and_files(self.share_name)
        ct =  0 
        for file_or_dir in generator_az:
            self.log.debug("File Acked on share:", file_or_dir)
            ct+=1
        self.assertEqual(2,ct,"Do we have 2 Python or any files on Azure?")
    
    def testLastModified (self):
        # should be less than 60 seconds!!
        age = dtt.utcnow() -  self.az.get_share_last_modified(share_name=self.share_name).replace(tzinfo=None)
        self.assertLessEqual(age.seconds, 300, "Share should be less than 5 minutes")
        

if __name__ == '__main__':
    unittest.main()
