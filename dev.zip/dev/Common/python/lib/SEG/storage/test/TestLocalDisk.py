import unittest
import logging
import os
from SEG.storage.StorageObjects import DiskStorageObject

class TestLocalDisk(unittest.TestCase):
    log = None

    @classmethod
    def setUpClass(cls):
        logging.basicConfig(format='%(asctime)s|%(module)s|%(funcName)s|%(levelname)s|%(lineno)d|%(message)s',
                            level="INFO")
        cls.base_dir =  r"//seg.local/root/scans/temp"

    def testDirSizeMethod(self):
        log = logging.getLogger(__name__)
        log.debug("..testing dir size method. CWD:%s", self.base_dir)

        x:float =  DiskStorageObject().get_directory_size_gb(path=self.base_dir)
        log.debug("Storage size in gb : %.3f", x)
        self.assertGreaterEqual(x,1,"Is Scans temp gt 1 gb")
    
    def testLocalDiskStruct(self):
        log = logging.getLogger(__name__)
        log.debug("I am here!")
        ds = DiskStorageObject().get_base_directory_info(local_path=self.base_dir )
        log.debug("ds:%s", str(ds))
        self.assertGreaterEqual(ds["jblouin"]["days_aged"], 350, "Is Jimmy Blouin tempdir more than a year old.")
        self.assertGreaterEqual(len(ds["Oscar"]["files"]),10,"Does Oscars temp on scans have more than 10 files?")

    def testShareSpace(self):
        log = logging.getLogger(__name__)
        ds =  DiskStorageObject(self.base_dir)
        x = ds.get_share_quota_gb()
        log.info("Share %s = %d GB disk", self.base_dir, x )
        self.assertGreaterEqual(x, 190, "Is scans bigger than 190gb")
        
if __name__ == '__main__':
    unittest.main()
