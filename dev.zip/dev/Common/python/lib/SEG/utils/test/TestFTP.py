'''
Created on Aug 19, 2015

@author: spatel
'''
import unittest
import SEG.utils.FTP as seg_ftp
import os
import tempfile
from datetime import datetime as dtt
import shutil
import logging

class TestFTP(unittest.TestCase):

    directory = None
    ftp_server = None
    ftp_passwd = None
    ftp_remotedir = None
    ftp_pattern = None
    
    sftp_server = None
    sftp_passwd = None
    sftp_remotedir = None
    sftp_pattern = None
    
    sftp_oneshot = None
    excel_file = None
    excel_fullpath = None
    
    local_filename = None
    now  = None
    
    @classmethod
    def setUpClass(self):
        # setup locations to download stuff, so we can clean up afterwards
        
        logging.basicConfig(format='%(asctime)s|%(module)s|%(levelname)s|%(lineno)d|%(message)s', 
                            level="DEBUG")
        
        now = dtt.now().strftime("%Y%m%d_%H%M")
        self.directory = tempfile.mkdtemp(suffix=now)
        
        self.ftp_server = "ftp.selectequity.com"
        self.ftp_uid = "bbid_test"
        self.ftp_passwd = "seg123!"
        self.ftp_remotedir = "report_unit_test"
        self.ftp_fpattern = "*.xml"
        
        self.sftp_server = "ftp.selectequity.com"
        self.sftp_uid = "seg_test"
        self.sftp_passwd =  "seg_test"
        self.sftp_remotedir = "test_subdir"
        self.sftp_fpattern = "*txt"
        
        self.sftp_oneshot = "_int_short.lm.bburpt.20150730-84627T-4.xml"
        self.excel_file= "attalus_select_trades.xls"
        self.excel_fullpath = os.path.join(os.path.dirname(__file__),self.excel_file)
        # TODO TODO TODO - ensure remote server has the needed data. 8/21/2015
        
        # Do put stuff - create a file
        self.local_filename= os.path.join(self.directory,"UPLOAD_TEST_" + now +".txt")
        self.now = now
        fh = open(self.local_filename,"w")
        fh.write("This is a test of our UPLOAD stuff")
        fh.close()
        
    @classmethod  
    def tearDownClass(self):
        # Delete all the stuff from our tempdir
        shutil.rmtree(self.directory)
        # TODO TODO TODO - delete remote crap we ftp'ed/sfp'ed

    def testFTP(self):
        '''
        Here are we are testing...
        1.) FTP Connection
        2.) Do get back our files
        3.) Do we get back our size.
        
        ...i didn't bother with a test on the timestamp - we can add that eventually on the setup
        '''
        
        ftp = seg_ftp.FTP(server=self.ftp_server, username=self.ftp_uid, 
                          password=self.ftp_passwd, method_type="FTP")
        
        # ensure it is not None.
        self.assertIsNotNone(ftp, "Is there a FTP Connection?")
        # Step 2 - get files. There should be at least 2...unless somebody deleted it...
        # print "Remote DIR :" , self.ftp_remotedir
        files = ftp.get_timestamps_and_size(file_pattern=self.ftp_fpattern, 
                                            server_directory=self.ftp_remotedir)
        # print files
        
        self.assertEqual(len(files), 2, "Are there 2 xml files on our server?")
        # just download 1 file
        my_file = self.ftp_remotedir + "/" + self.sftp_oneshot
        # print "LOOKING FOR " + my_file + "\n"
        
        self.assertIn(my_file, files, "Is my xml there?")
        
        ftp.get_file(server_location=my_file, local_location=self.directory)
        
        # did we get it?
    
        self.assertTrue(os.path.exists(os.path.join(self.directory,self.sftp_oneshot)), "Did we download the file?")
        
        # check if the sizes on remote and local are the same?
        
        self.assertEqual(files[my_file]["byte_size"] , 
                         os.path.getsize(os.path.join(self.directory,self.sftp_oneshot)),
                         "Is the file size remotely the same as locally?")
        
        x = ftp.put_file(local_location=self.local_filename)
        self.assertEqual(x,34,"Is the Upload FIle Size kosher?")
            
        # print "Done in testFTP \n"
        bytes_up = ftp.put_file(local_location=self.local_filename, server_location="data/"+os.path.basename(self.local_filename))
        self.assertEqual(bytes_up, 34, "Did we upload the right thing -- 2?")
        
        
        # Upload Excel File.
        to_file = self.now + "_" + self.excel_file
        bytes_up_excel= ftp.put_file(local_location=self.excel_fullpath,
                                     server_location=self.ftp_remotedir+"/"+to_file)
        self.assertEqual(bytes_up_excel, 5632, "Did excel load up properly?")
        
        # Download that excel file!
        byte_down_excel = ftp.get_file(server_location=self.ftp_remotedir+"/"+to_file, 
                                       local_location=self.directory)
        
        self.assertEqual(byte_down_excel, 5632, "Did excel download up properly?")
        
        
        # Dec 2015 - disconnect and reconnect
        ftp.keep_alive()
        ftp.connection.close()
        ftp.keep_alive()
        
        # Nov 2015 - delete file added! And it's nice to cleanup
        
        ftp.delete_file((self.ftp_remotedir+"/"+to_file), "Incoming")
        ftp.delete_file(os.path.basename(self.local_filename),"Incoming")
        ftp.delete_file("data/"+os.path.basename(self.local_filename),"Incoming")
        
    # ------------------------------
    def testSFTP(self):
        sftp = seg_ftp.FTP(server=self.sftp_server, username=self.sftp_uid, 
                          password=self.sftp_passwd, method_type="SFTP")
        
        self.assertIsNotNone(sftp, "Is there a SFTP Connection?")
        
        
        files = sftp.get_timestamps_and_size(file_pattern=self.sftp_oneshot)

        
        self.assertEqual(len(files), 1, "XML")
        # print "OBEJCT: " , files 
        # print "\n"
        
        self.assertEqual(files[self.sftp_oneshot]["byte_size"],2605,"Is my XML the right size?")
        
        # Note - depending on location/cygwin vs windows...we may get GMT vs EST. Be aware.
        # Nov 2 2015 - lets comment this out. The whole thing behind timestamp is server time, client ftp lib , etc.
        # We will simply need to be careful on the logic dealing with mod time for files!!
        # print "The value is " , files[self.sftp_oneshot]["timestamp"]
        # self.assertEquals(files[self.sftp_oneshot]["timestamp"],"2015-07-30 10:40:36","Is the tstamp what we want")
        # download to dog.
        
        downloadme = os.path.join(self.directory,"DOG.xml")
        sftp.get_file(self.sftp_oneshot, downloadme)
        self.assertTrue(os.path.exists(downloadme),"SFTP = Did we download something")
        bytes_up = sftp.put_file(local_location=self.local_filename)
        self.assertEqual(bytes_up, 34, "SFTP - Did we upload the right thing?")
        
        #download to the subdir
        bytes_up = sftp.put_file(local_location=self.local_filename,server_location=("test_subdir/" + os.path.basename(self.local_filename)))
        
        self.assertEqual(bytes_up, 34, "SFTP -Did we upload the right thing -- 2?")
        
        # upload excel
        to_file = "sftp_" + self.now + "_" + self.excel_file
        bytes_up_excel= sftp.put_file(local_location=self.excel_fullpath,
                                     server_location="test_subdir/"+to_file)
        self.assertEqual(bytes_up_excel, 5632, "SFTP -Did excel load up properly?")
        
        # download that file to temp
        bytes_down_excel = sftp.get_file("test_subdir/"+to_file, os.path.join(self.directory,"test.xls"))
        self.assertEqual(bytes_down_excel, 5632, "SFTP = Did excel DOWNLOAD  properly?")
        
        # do sftp put but no confirm
        to_file = "sftp_" + self.now + "_" + self.excel_file
        bytes_up_excel= sftp.put_file(local_location=self.excel_fullpath,
                                     server_location="test_subdir/"+to_file,
                                     do_sizecheck_failure=False)
        self.assertEqual(bytes_up_excel, -1, "SFTP - No Size Check on Put")
        
        # Dec 2015 - disconnect and reconnect
        sftp.keep_alive()
        sftp.connection.close()
        sftp.keep_alive()
        
        # Nov 2015  - clean
        
        sftp.delete_file("test_subdir/"+to_file, "Incoming")
        sftp.delete_file(os.path.basename(self.local_filename),"Incoming")
        sftp.delete_file("test_subdir/"+os.path.basename(self.local_filename),"Incoming")
        
        
        
if __name__ == "__main__":
    unittest.main()