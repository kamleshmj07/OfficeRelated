import unittest
import SEG.utils.PGpy as PGpy
import os
import logging 

import tempfile

log = logging.getLogger(__name__)

class TestPGPMethods(unittest.TestCase):
    
    @classmethod
    def setUpClass(self):
        logging.basicConfig(format='%(asctime)s|%(module)s|%(levelname)s|%(lineno)d|%(message)s', 
                            level="DEBUG")
        self.public_key_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'potatopub.key')
        self.private_key_path =  os.path.join(os.path.dirname(os.path.realpath(__file__)),'potatopriv.key')
        
        self.encrypted_file  = os.path.join(os.path.dirname(os.path.realpath(__file__)),'encrypted_test_file.csv.pgp')
        # self.decrypted_file = os.path.join(os.path.dirname(os.path.realpath(__file__)),'encrypted_test_file.csv')
        self.decrypted_file = os.path.join(tempfile.mkdtemp(),'encrypted_test_file.csv')
        self.string = ('Test that first and second are not equal. If the values do compare equal,'
                       'the test will fail.')


    @classmethod   
    def tearDownClass(self):
        if (os.path.isfile(self.decrypted_file)):
            os.remove(self.decrypted_file)
            pass
            
            
    def test_encrypt_string(self):
        self.assertIsNotNone(PGpy.encrypt_string(self.string, self.public_key_path), "Encrypt String returns value.")
       

    def test_decrypt_string(self):
        encrypted_string = PGpy.encrypt_string(self.string, self.public_key_path)
        # print "The encrypted string is " , encrypted_string
        x = PGpy.decrypt_string(encrypted_string, self.private_key_path)
        # print "The value is ", x
        self.assertEqual(x, self.string, "Does Decryption work?")

    def test_gpg_decryption(self):
        x = PGpy.decrypt_file(filename = self.encrypted_file, 
                              to_filename = self.decrypted_file )
        
        self.assertEqual(x, self.decrypted_file, "Did we create the decrypted file?")
        self.assertIs(os.path.isfile(self.decrypted_file), True, msg = " Does test file exist")
        
        
if __name__ == '__main__':
    unittest.main()
