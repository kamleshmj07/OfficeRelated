import unittest
from SEG.utils.ADObject import ADObject
import logging

class TestADQuery(unittest.TestCase):

    @classmethod
    def setUpClass(self):
        logging.basicConfig(format='%(asctime)s|%(module)s|%(levelname)s|%(lineno)d|%(message)s',
                            level="DEBUG")

        self.test_username = "Tony Shergill"
        self.test_email = "tshergill@selectequity.com"
        self.test_username2 = "Kamal Shah"
        self.test_email2 = "kshah@selectequity.com"
        self.test_group = "SEGIT"
        self.false_group = "Research"
        self.test_DN = 'CN=SEGIT,OU=Distribution,OU=Groups,DC=SEG,DC=local'
        self.ADObject = ADObject()
        log = logging.getLogger(__name__)
        log.info("...set up complete for LDAP Unit Test!")

    def test_get_user_name(self):
        logging.info("Checking if function returns %s for user idtshergill" % self.test_username)
        self.assertEqual(self.ADObject.get_user_name('Tshergill'), self.test_username)

    def test_email_address(self):
        logging.info("Checking if function returns %s for user id tshergill" % self.test_email)
        self.assertEqual(self.ADObject.get_email_address('Tshergill'), self.test_email)

    def test_get_groups(self):
        logging.info("Asserting that group %s is %s\'s groups" % (self.test_DN, self.test_username))
        groups = self.ADObject.get_groups('Tshergill')
        result = False
        for group in groups:
            if group == self.test_DN:
                result = True
        self.assertTrue(result)        

    def test_is_group_member(self):
        logging.info("Asserting that %s is in group %s" % (self.test_username, self.test_group))
        self.assertTrue(self.ADObject.is_group_member('Tshergill', self.test_group))
        logging.info("Asserting that %s is not in group %s"% (self.test_username, self.false_group))
        self.assertFalse(self.ADObject.is_group_member('Tshergill', self.false_group))
    
    def test_group_members(self):
        results = self.ADObject.get_group_members("SEGIT")
        found_user = False
        found_user2 = False
        for user_info in results:
            name, email = user_info
            if name == self.test_username and email + "@selectequity.com" == self.test_email:
                found_user = True
            if name == self.test_username2 and email + "@selectequity.com" == self.test_email2:
                found_user2 = True
        logging.info("Asserting that user %s with email %s is in group SEGIT" % (self.test_username, self.test_email))
        self.assertTrue(found_user)
        logging.info("Asserting that user %s with email %s is in group SEGIT" % (self.test_username2, self.test_email2))
        self.assertTrue(found_user2)

    def test_group_members2(self):
        test_name = "Christine Weldon"
        test_email = "cweldon@selectequity.com"
        results = self.ADObject.get_group_members("office")
        found_user = False
        for user_info in results:
            name, email = user_info
            # print("Testing office", name, email)
            if name == test_name and email + "@selectequity.com" == test_email:
                found_user = True
        logging.info("Asserting that user %s with email %s is in group office" % (test_name, test_email))
        self.assertTrue(found_user)

    def test_get_all_persons(self):
        results = self.ADObject.get_all_persons()

        found_user = False
        found_user2 = False
        for name in results:
            if name == self.test_username:
                found_user = True
            if name == self.test_username2:
                found_user2 = True
        logging.info("Asserting that user %s is in SEG main directory" % (self.test_username))
        self.assertTrue(found_user)
        logging.info("Asserting that user %s is in SEG main directory" % (self.test_username2))
        self.assertTrue(found_user2)

    def test_get_all_groups(self):
        results = self.ADObject.get_all_groups(distribution_group=False)

        group1 = "SEGIT"
        logging.info("Asserting that group %s is in SEG group directory" % (group1))
        self.assertTrue(group1 in results)

        group2 = "SEG App Dev"
        logging.info("Asserting that group %s is in SEG group directory" % (group2))
        self.assertTrue(group2 in results)

        group3 = "XXXXXX"
        logging.info("Asserting that group %s is not in SEG group directory" % (group3))
        self.assertFalse(group3 in results)

        group4 = "office"
        logging.info("Asserting that group %s is in SEG group directory" % (group4))
        self.assertTrue(group4 in results)

        logging.info("Asserting that number of groups %d is in SEG group directory > 200" % len(results))
        self.assertTrue(len(results) > 200)
        ## We have 301 Distribution groups and around 650 Distribution + Securities groups as of Oct 2019

    def test_get_all_distribution_groups(self):
        results = self.ADObject.get_all_groups(distribution_group=True)

        group1 = "SEGIT"
        logging.info("Asserting that group %s is in SEG Distribution group directory" % (group1))
        self.assertTrue(group1 in results)

        group2 = "SEG App Dev"
        logging.info("Asserting that group %s is in SEG Distribution group directory" % (group2))
        self.assertTrue(group2 in results)

        group3 = "XXXXXX"
        logging.info("Asserting that group %s is not in SEG Distribution group directory" % (group3))
        self.assertFalse(group3 in results)

        group4 = "office"
        logging.info("Asserting that group %s is not in SEG Distribution group directory" % (group4))
        self.assertFalse(group4 in results)

        logging.info("Asserting that number of groups %d is in SEG group directory > 200" % len(results))
        self.assertTrue(len(results) > 200)
        ## We have 301 Distribution groups and around 650 Distribution + Securities groups as of Oct 2019

    def test_get_groups2(self):
        logging.info("Asserting that group %s is %s\'s groups" % ("office", ("Christine Weldon " + "cweldon")))
        groups = self.ADObject.get_groups('cweldon')
        result = False
        for group in groups:
            ## print(group)
            if group.startswith("CN=office,"):
                result = True
        self.assertTrue(result)

    def test_user_info(self):
        user_id = 'tshergill'
        attribute1 = "sn"
        attribute2 = 'givenName'

        logging.info("Asserting that %s last name is %s" % ('tshergill', "Shergill"))
        self.assertEqual(self.ADObject.get_user_info(user_id, attribute1), "Shergill")

        logging.info("Asserting that %s first name is %s" % ('tshergill', "Tony"))
        self.assertEqual(self.ADObject.get_user_info(user_id, attribute2), "Tony")

    def test_job_id(self):
 
        groups = self.ADObject.get_groups('jobsvcprod1')
        result = False
        for group in groups:
            #print(group)
            if group.find("CN=grpjobsvcprod1"):
                result = True
        self.assertTrue(result, "Does the bot exist in its group?")

        # does this thing have an email?
       
    def test_job_id_no_email(self):
        self.assertTrue((self.ADObject.get_email_address('jobsvcprod1')==""), "Blank email for job")

if __name__ == '__main__':
    unittest.main()
