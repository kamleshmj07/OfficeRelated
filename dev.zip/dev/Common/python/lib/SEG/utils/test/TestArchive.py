'''
Feb 2020

@author: spatel
'''
import unittest
import SEG.utils.Archive as arch

import logging
import os
import datetime
from SEG.storage.StorageObjects import AzureStorageObj, DiskStorageObject
from SEG.utils.SEGUtils import get_app_archive_dir, get_app_root_dir

import shutil

class TestArchive(unittest.TestCase):


    @classmethod
    def setUpClass(cls):
        # setup locations to download stuff, so we can clean up afterwards
        
        logging.basicConfig(format='%(asctime)s|%(module)s|%(levelname)s|%(lineno)d|%(message)s', 
                            level="INFO")
        cls.logger = logging.getLogger()
        cls.archive_subdir = "unittest"
        cls.datepad = datetime.datetime.now().strftime("%Y%m%d")


    @classmethod  
    def tearDownClass(cls):
        pass

    def testArchiveCloud(self):
        '''
            We will take the local "unit_test.cnf" and archive to the cloud!
        '''
        # set env variable for Azure to the dev cloud storage we know of
        # and want to putz with.
        # TODO TODO TODO - clean up as diskstorage and azurestorage needs to be cleaned up.
        cwd = os.path.dirname(os.path.realpath(__file__))
        os.chdir(cwd)
        fname = "unit_test.cnf"
        os.environ["AZURE_RESOURCE"] = "segazfile1dev"
        os.environ["AZURE_KEY"] =  "Nup7QSjk4+bfh6TIeNqZ8SumUpnt6E7ttldVHn5jsiXln249oe8sUyEoMjEyVh2YG1sgg2XwbV3c62MIW1fkOQ=="
        arch.auto_archive(filename=fname, archive_subdir=self.archive_subdir)
        # if we're here, something went to the cloud!
        # check for existence!
        az = AzureStorageObj(azure_account_name=os.environ["AZURE_RESOURCE"], 
                             azure_account_key=os.environ["AZURE_KEY"])
        dstruct = az.get_base_directory_info(share_name="seg-app-archives", path = (self.archive_subdir+"/"+self.datepad))
        files = dstruct["."]["files"]
        # there should only be 1 file :)
        self.assertEqual(1,len(files), " Is our uploaded file there? ")

        self.assertTrue("unit_test" in files[0], "Did unit test file get uploaded?")
        
        # do cleanup here  
        # we are assuming things worked. If not....we may have to do a manual cleanup
        # delete_file gets marked for Deletion but will not return value
        az.file_service.delete_file(share_name="seg-app-archives", 
                                    directory_name=(self.archive_subdir+"/"+self.datepad), 
                                    file_name=os.path.basename(files[0]))
        
        st2=az.file_service.delete_directory(share_name="seg-app-archives", 
                                    directory_name=(self.archive_subdir+"/"+self.datepad))
        
        st3=az.file_service.delete_directory(share_name="seg-app-archives", 
                                    directory_name= self.archive_subdir)

        # print ("BROSKIE --" ,st1, st2, st3)
        self.assertTrue(( st2 and st3), "Was Azure Archive cleaned up?")
    # ------------------------------
    def testLocalArchive(self):
       # bro
       # unset any environment variables. 
        if (os.environ.get("AZURE_KEY") is not None):
            del os.environ["AZURE_KEY"]
            cwd = os.path.dirname(os.path.realpath(__file__))
        os.chdir(cwd)
        fname = "unit_test.cnf"
        arch.auto_archive(filename=fname)
        # check if it's there, and then delete it 
        archive_dir = get_app_archive_dir()
        ds = DiskStorageObject().get_base_directory_info(local_path=archive_dir)
        files = ds["."]["files"]

        self.assertEqual(1,len(files), " Is our uploaded file there? ")

        self.assertTrue("unit_test" in files[0], "Did unit test file get uploaded?")
        os.remove(files[0])
        os.rmdir(archive_dir)
        x = os.path.join(get_app_root_dir(), "archive")
        os.rmdir(x)
        
if __name__ == "__main__":
    unittest.main()