'''
Created on October 19, 2015

Unit test for The transporter!! Oh yeah. 

Test SFTP/FTP/CP.  - 3 unit tests over all.

Nov 2015 - delete logic. Only testing on SFTP side for now
Jan 2018 - decided to change setUp to setUpClass. More efficient. Also cleaner code to make objects
            "visible".

@author: spatel
'''
import unittest
from  SEG.utils.SEG_TransportLogic import SEG_TransportLogic
import os
import tempfile
from datetime import datetime as dtt
import shutil
import mock
import logging

class TestSEGTransporter(unittest.TestCase):

    directory = None
    results = None
    db_con = None
    
    @classmethod
    def setUpClass(self):
        # setup locations to download stuff, so we can clean up afterwards
        
        logging.basicConfig(format='%(asctime)s|%(module)s|%(levelname)s|%(lineno)d|%(message)s', 
                            level="DEBUG")
        # setup locations to download stuff, so we can clean up afterwards
        now = dtt.now().strftime("%Y%m%d_%H%M")
        self.directory = tempfile.mkdtemp(suffix=now)
        self.results={}
        
        # Create test for an empty file. Lets generate one, and then we shall upload
        newfile = os.path.join(self.directory,"empty_file.txt")
        open (newfile,'w').close()
        
        # OK...do the below so we do not decrypt during the unit tests.
        if ("PGP_PRIVKEY" in os.environ):
            os.environ.pop("PGP_PRIVKEY")

        self.results["SFTP_TEST"] = []
        result_set = {"transport_name": "SEG_SFTP", "action":"Incoming", "source_path": "test_subdir",
                      "vendor_key":"SEG_SFTP", "delete_source":None,
                      "source_file_pattern": "Yo*txt" , "destination_path":self.directory, "destination_file_pattern":"",
                      "is_active": 1 , "connection_type": "SFTP", "server_address": "ftp.selectequity.com", 
                      "username": "seg_test", "password": "seg_test","port":None}
        self.results["SFTP_TEST"].append(result_set)
        
        result_set = {"transport_name": "SEG_SFTP", "action":"Outgoing", "source_path": os.path.dirname(__file__),
                      "vendor_key":"SEG_SFTP","delete_source":None,
                      "source_file_pattern": "attalus_select_trades.xls" , 
                      "destination_path":"", "destination_file_pattern":"%YYYY%MM%DD_%HOUR_%MIN_%SEC_attalus_select_trades_Sftp.xls",
                      "is_active": 1 , "connection_type": "SFTP", "server_address": "ftp.selectequity.com", 
                      "username": "seg_test", "password": "seg_test", "port":None}

        self.results["SFTP_TEST"].append(result_set)

        # OK - there's a silly possibility of a race condition here where the day turns over.
        # In other words - dont be testing at midnight EST or midnight GMT :)
        result_set = {"transport_name": "SEG_SFTP", "action":"Incoming", "source_path": "",
                      "vendor_key":"SEG_SFTP", "delete_source":1,
                      "source_file_pattern": "%YYYY%MM%DD_*_attalus_select_trades_Sftp.xls" , 
                      "destination_path":self.directory, "destination_file_pattern":"",
                      "is_active": 1 , "connection_type": "SFTP", "server_address": "ftp.selectequity.com", 
                      "username": "seg_test", "password": "seg_test","port":None}
        
        self.results["SFTP_TEST"].append(result_set)

        # Let's do FTP!!
        self.results["FTP_TEST"] = []
        result_set = {"transport_name": "SEG_FTP", "action":"Incoming", "source_path": "report_unit_test",
                      "vendor_key":"SEG_FTP", "delete_source":None,
                      "source_file_pattern": "*xml" , "destination_path":self.directory, "destination_file_pattern":"",
                      "is_active": 1 , "connection_type": "FTP", "server_address": "ftp.selectequity.com", 
                      "username": "bbid_test", "password": "seg123!", "port":None}
        self.results["FTP_TEST"].append(result_set)
        
        result_set = {"transport_name": "SEG_FTP", "action":"Outgoing", "source_path": os.path.dirname(__file__),
                      "vendor_key":"SEG_FTP","delete_source":0,
                      "source_file_pattern": "attalus_select_trades.xls" , 
                      "destination_path":"", "destination_file_pattern":"%YYYY%MM%DD_%HOUR_%MIN_%SEC_attalus_select_trades_FTP.xls",
                      "is_active": 1 , "connection_type": "FTP", "server_address": "ftp.selectequity.com", 
                      "username": "bbid_test", "password": "seg123!", "port":None}
        self.results["FTP_TEST"].append(result_set)
        
        '''
        cLEAN UP IS CAUSING RACE CONDITIONS OF SORT. DOH!
        result_set = {"transport_name": "SEG_FTP", "action":"Incoming", "source_path": "",
                      "vendor_key":"SEG_FTP","delete_source":1,
                      "source_file_pattern": "%YYYY%MM%DD*attalus_select_trades*.xls" , 
                      "destination_path":os.path.join(self.directory,"testftp"), "destination_file_pattern":"",
                      "is_active": 1 , "connection_type": "FTP", "server_address": "ftp.selectequity.com", 
                      "username": "bbid_test", "password": "seg123!", "port":None}
        self.results["FTP_TEST"].append(result_set)
        '''
        # Internal Copy.
        
        self.results["COPY"] = []
        result_set = {"transport_name": "SEG_COPY", "action":"Copy", "source_path": self.directory,
                      "vendor_key":"SEG_COPY", "delete_source":None,
                      "source_file_pattern": "empty_file.txt" , "destination_path":self.directory, 
                      "destination_file_pattern":"COPY_empty_file.txt",
                      "is_active": 1 , "connection_type": "COPY", "server_address": None, 
                      "username": None, "password": None, "port":None}
        
        self.results["COPY"].append(result_set)

        result_set = {"transport_name": "SEG_COPY", "action":"Copy", "source_path": os.path.dirname(__file__),
                      "vendor_key":"SEG_COPY", "delete_source":None,
                      "source_file_pattern": "attalus_select_trades.xls" , "destination_path":self.directory, 
                      "destination_file_pattern":"COPY_attalus_select_trades.xls",
                      "is_active": 1 , "connection_type": "COPY", "server_address": None, 
                      "username": None, "password": None, "port":None}
        
        self.results["COPY"].append(result_set)
        
        self.db_con = mock.Mock()
        self.db_con.cursor = mock.Mock()
        # self.transporter = SEG_TransportLogic(db_con)
        # logging.basicConfig(format='%(asctime)s|%(module)s|%(levelname)s|%(lineno)d|%(message)s', 
                        # level="DEBUG")
        
    @classmethod   
    def tearDownClass(self):
        # Delete all the stuff from our tempdir
        shutil.rmtree(self.directory)
        # TODO TODO TODO - delete remote crap we ftp'ed/sfp'ed
    # -----------------------------------------------------------------------------------

    def testFTP(self):
        '''
        Here are we are testing...
        1.) Did we upload/download the files?
        2.) Sanity Check - test if one of our files is there.
        
        '''
        transporter = SEG_TransportLogic(self.db_con)
        files_moved = transporter.transport_files(results=self.results["FTP_TEST"], do_audit=False,
                                                  name="FTP_TEST"
                                                 )

        # As of 10/19/2015 - should be 3 files
        self.assertEqual(files_moved,3, "FTP - 3 files should have been moved!")
        
        # let's make sure one of our xml files is.
        
        self.assertEqual((os.path.exists(os.path.join(self.directory,"_int_short.lm.bburpt.20150730-82955T-4.xml"))), 
                          True, "FTP  - Is our XML File there?")
        files_deleted = transporter.delete_scheduled_files()
        self.assertGreaterEqual(files_deleted,0,"FTP - we didn't delete squat")
        transporter.validate_connections()  # just test it.
    #  ---------------------------------------------------------------
    
    def testSFTP(self):
        '''
        Here are we are testing...
        1.) Did we upload/download the files?
        2.) Sanity Check - test if one of our files is there.
        
        '''
        transporter = SEG_TransportLogic(self.db_con)
        files_moved = transporter.transport_files(results=self.results["SFTP_TEST"], do_audit=False,
                                                  name="SFTP_TEST")

        # As of 10/19/2015 - should be 3 files
        # self.assertEquals(files_moved,3, "SFTP - 3 files should have been moved!")
        self.assertGreaterEqual(files_moved,3, "SFTP - 3 or more files should have been moved!")
        # let's make sure one of our xml files is.
        
        self.assertEqual((os.path.exists(os.path.join(self.directory,"Yo_This_is_atest.txt"))), True, "SFTP - Is my text file there?")
        
        # 11/19/2015 - Add delete logic
        
        files_deleted = transporter.delete_scheduled_files()
        
        self.assertGreaterEqual(files_deleted,1,"SFTP - did we at least delete one file?")
        transporter.validate_connections()
    # -----------------------------------------------------------------------
    
    def testCOPY(self):
        ''' Only 1 copy... '''
        transporter = SEG_TransportLogic(self.db_con)
        files_moved = transporter.transport_files(results=self.results["COPY"], 
                                                  do_audit=False,
                                                  name="COPY",notransport_empty_file=True)

        # As of 10/19/2015 - should be 3 files
        self.assertEqual(files_moved, 1, "COPY - Just 1 file dude!")
        
        # let's make sure one of our xml files is.
        
        self.assertEqual((os.path.exists(os.path.join(self.directory,"COPY_attalus_select_trades.xls"))), True, "COPY - is my file there?")
        transporter.validate_connections()


if __name__ == "__main__":
    unittest.main()
