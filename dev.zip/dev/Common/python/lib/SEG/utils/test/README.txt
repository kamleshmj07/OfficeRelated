Nov 2018

A little explanation on the gpg keys here.

For the most part, they should not be here. But they are here.

potato*keys - created by young omar. Used internally by the transporter 
and backstop

pgp*key - Created July 2018.

MS-Comet - Create Nov 2018 by MS. A unit test was written where we need it. So Import it!

Public keys have been given to:
1.) Bloomberg - for sending us EMSX Order files - July 2018
2.) Morgan Stanley -- they will encrypt files given to us. - Nov 2018
 


Please continue to add how and to whom the keys are supplied to!!


