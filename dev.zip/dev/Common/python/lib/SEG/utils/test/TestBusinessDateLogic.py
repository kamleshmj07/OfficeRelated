'''

# yes - its cheap. The unit tests here will test some business date logic in
our modules SEGUtils and SEG_TransportLogic

Use CT-SQL4 as our test db.

@author: spatel
'''
import unittest
from  SEG.utils.SEG_TransportLogic import SEG_TransportLogic
from SEG.utils.SEGUtils import get_trade_date, is_market_closed
import os

from datetime import datetime, date

import logging
import pyodbc
import configparser


'''
12/4/2/2015 - 3 items to test
1.) is market closed 2.) get trade date 3.) Return Dates 
'''

class TestBusinessDateLogic(unittest.TestCase):

    connection =  None

      
    @classmethod
    def setUpClass(cls):
       
        conn_name = "UNIT_TEST"
        config = configparser.ConfigParser()
        config.read(os.path.join(os.path.dirname(__file__),"unit_test.cnf"))
    
        if not config.has_section(conn_name):
            raise Exception("Could not find section UNIT TEST in local file!")
        
        driver = config.get(conn_name,"DRIVER")
        server = config.get(conn_name,"SERVER")
        database = config.get(conn_name,"DATABASE")
        uid = config.get(conn_name,"UID")
        pwd = config.get(conn_name,"PWD")
    
        conn_string = "DRIVER=" + driver + ";SERVER=" + server + ";DATABASE=" + database + ";UID=" + uid + ";PWD=" + pwd
        cls.connection = pyodbc.connect(conn_string)
        logging.basicConfig(format='%(asctime)s|%(module)s|%(levelname)s|%(lineno)d|%(message)s', 
                            level=config.get(conn_name,"LOG_LEVEL"))
        
        
    @classmethod
    def tearDownClass(cls):
        cls.connection.close()
    #-----------------------------------------------------------------------------------
    def test_is_market_closed(self):
        
        '''
        12/25/2015 for USD = closed
        12/24/2015 for USD = open
        12/4/2015 for USD = open
        12/25/2015 for global = open!
        11/28/2015 - Weekend
        '''
        
        self.assertEqual(is_market_closed(self.connection, "2015-12-25", "USD"),1, "Is X mas a Holiday in US - Yes!")
        self.assertEqual(is_market_closed(self.connection, "2015-12-24", "USD"),0, "Is X mas eve  a Holiday in US - Nyet!")
        self.assertEqual(is_market_closed(self.connection, "2015-12-4"),0, "12/4/2015 - friday!")
        self.assertEqual(is_market_closed(self.connection, "2015-12-25"),0, "Is X mas Holiday globally - Nyet!")
        self.assertEqual(is_market_closed(self.connection, "2015-11-28"),1, "11/28/2015 - market open? - Nyet!")
    #  ---------------------------------------------------------------
    
    def test_trade_date_calc(self):
        '''
          12/28/2015 - 1 day for USD should yield 12/24/2015
          12/16/2015 - 1 day should be 12/15/2015
          12/16/2015 - 3 days should be 12/11/2015
          12/24/2015 + 1 day for USD should yield 12/28/2015
          
        '''
        # logger = logging.getLogger(__name__)
        x = get_trade_date(self.connection,"2015-12-28",-1,"USD")
        # logger.debug("Trade Date= %s",x)
        
        self.assertEqual(x.strftime("%Y-%m-%d"),"2015-12-24", "12/28/2015 - 1 day = 12/24 in the us!")
        self.assertEqual( get_trade_date(self.connection,"2015-12-16",-1).strftime("%Y-%m-%d"),"2015-12-15", "12/16 - 1 day")
        self.assertEqual( get_trade_date(self.connection,"2015-12-16",-3).strftime("%Y-%m-%d"),"2015-12-11", "12/16 -3 day")
        self.assertEqual( get_trade_date(self.connection,"2015-12-24",1,"USD").strftime("%Y-%m-%d"),"2015-12-28", "12/25+1 bday")
        
    # -----------------------------------------------------------------------
    
    def test_pad_w_dates(self):
        ''' this is a tad tricky! '''
        
        t = SEG_TransportLogic(self.connection)
        # here we go
        test1 = "Samples.csv"
        test2 = "Samples_%YYYY%MM%DD(USD_DATE-1).csv"
        test3 = "Samples_%YYYY%MM%DD(USD_DATE+1).csv"
        test4 = "Samples_%YYYY%MM%DD(DATE-1).csv"
        test5 = "CUR_DATE_%YYYY_%MM_%DD.csv"
      
        x = datetime.now()
        xmas_eve = date(year=2015,month=12,day=24)
        after_xmas = date(year=2015,month=12,day=28)
        
        self.assertEqual(t.replace_seg_symbols(test1),"Samples.csv", " Test 1 for replace symbols")
        self.assertEqual(t.replace_seg_symbols(test5),("CUR_DATE_" +x.strftime("%Y")+"_"+ x.strftime("%m")+"_"+x.strftime("%d")+".csv"), " Test 2 for replace symbols")
        self.assertEqual(t.replace_seg_symbols(test4,after_xmas),"Samples_20151225.csv", " Test 3 for replace symbols")
        self.assertEqual(t.replace_seg_symbols(test2,after_xmas),"Samples_20151224.csv", " Test 4 for replace symbols")
        self.assertEqual(t.replace_seg_symbols(test3,xmas_eve),"Samples_20151228.csv", " Test 5 for replace symbols")
        
        
    
if __name__ == "__main__":
    unittest.main()