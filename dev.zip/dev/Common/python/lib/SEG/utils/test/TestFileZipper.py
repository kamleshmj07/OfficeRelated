'''
Created on Jul 18, 2016

@author: spatel
'''
import SEG.utils.FileZipper as seg_zipper
from datetime import datetime
import tempfile
import unittest
import zipfile
import shutil
import os


class TestFileZipper(unittest.TestCase):

    directory = None
    subdir = None
    zipfile = None
    excel_file = None
    local_filename = None
    now = None

    @classmethod
    def setUpClass(cls):
        # setup locations to download stuff, so we can clean up afterwards
        now = datetime.now().strftime("%Y%m%d_%H%M")
        cls.directory = tempfile.mkdtemp(suffix=now)
        cls.subdir = "excel_dir"
        cls.zipfile = os.path.join(tempfile.gettempdir(), "UNIT_TEST.zip")
        
        cls.excel_file= "attalus_select_trades.xls"
        excel_fullpath = os.path.join(os.path.dirname(__file__), cls.excel_file)
        # copy file our directory
        os.mkdir(os.path.join(cls.directory, cls.subdir))
        shutil.copy(excel_fullpath,os.path.join(cls.directory,cls.subdir))
        
        # Do put stuff - create a file
        cls.local_filename= os.path.join(cls.directory,"ZIP_TEST_" + now +".txt")
        cls.now = now
        fh = open(cls.local_filename,"w")
        fh.write("This is some random file created on " + now)
        fh.close()

    @classmethod
    def tearDownClass(self):
        # Delete all the stuff from our tempdir
        shutil.rmtree(self.directory)

    def testZipPackage(self):
        # here's the deal....let's package our zip file.
        zipf = zipfile.ZipFile(self.zipfile,'w', zipfile.ZIP_DEFLATED)
        seg_zipper.zipdir(path=self.directory, ziph=zipf, pattern="*.*")
        zipf.close()
        
        # we actually want to ensure the zip file has the right contents and layouts!!
        zippy = zipfile.ZipFile(self.zipfile, 'r')
        contents = zippy.namelist()
        self.assertEqual(len(contents), 2, "We should have 2 zipped files")
        # print sorted(contents)
        # print sorted([(os.path.join(self.subdir,self.excel_file)), "ZIP_TEST_"+ self.now +".txt"])
        # ok....what's in our zip file? -- NOTE - I think it should work on Linux and windows ...tested on windows.
        self.assertListEqual(sorted(contents), 
                             sorted([(self.subdir + "/" + self.excel_file), "ZIP_TEST_"+ self.now +".txt"]),
                             "Do our contents match?")

    @classmethod
    def create_file(cls, d=tempfile.gettempdir(), contents=None):
        """ Creates tempfile, w/ optional contents to write. """
        if d is not None:
            d = os.path.join(tempfile.gettempdir(), d)
        d = os.path.normpath(d)
        f = tempfile.NamedTemporaryFile(dir=d, delete=False)
        if contents:
            f.write(contents.encode())
        f.close()
        return f.name

    @classmethod
    def tear_down(cls, files_to_delete, dirs_to_delete=None):
        """ takes in a dir of file paths (and optionally a dir of
        dir paths) and deletes them """
        for f in files_to_delete:
            os.remove(f)
        if dirs_to_delete is not None:
            for d in dirs_to_delete:
                for root, dirs, files in os.walk(d, topdown=False):
                    for name in files:
                        os.remove(os.path.join(root, name))
                    for name in dirs:
                        os.rmdir(os.path.join(root, name))

    @classmethod
    def create_dir(cls, dirpath=None):
        """ Creates dir at given dirpath. """
        if dirpath is not None:
            dir = tempfile.mkdtemp(dir=dirpath)
        else:
            dir = tempfile.mkdtemp()
        return dir

    def testZipOneFile(self):
        """ zip one file on its own """

        f1 = self.create_file(contents="This is really important content")

        foldername = seg_zipper.zip_files([f1], f1)
        zippy = zipfile.ZipFile(foldername, 'r')

        # check that file and folder named correctly
        contents = [os.path.join(tempfile.gettempdir(), x) for x in zippy.namelist()]
        self.assertEqual(contents, [f1])
        self.assertEqual(foldername, f1 + ".zip")
        self.assertEqual(len(contents), 1)

        # check that file content in tact
        f1_content = open(f1, 'r')
        self.assertEqual(f1_content.read(), "This is really important content")
        f1_content.close()
        zippy.close()

        self.tear_down([f1, foldername])

    def testZipMultipleFiles(self):
        """ zip multiple files """

        d = self.create_dir(tempfile.gettempdir())

        f1 = self.create_file(d=d, contents="This is really important content")
        f2 = self.create_file(d=d, contents="Of course, this is even more important content")
        f3 = self.create_file(d=d, contents="You know, they say the third time's a charm")

        foldername = seg_zipper.zip_files([f1, f2, f3], d)
        zippy = zipfile.ZipFile(foldername, 'r')

        # check that files and folder named correctly
        contents = [os.path.join(d, x) for x in zippy.namelist()]
        self.assertEqual(sorted(contents),
                         sorted([f1, f2, f3]))
        self.assertEqual(foldername, d + ".zip")
        self.assertEqual(len(contents), 3)

        # check that files' content in tact
        f1_content = open(f1, 'r')
        self.assertEqual(f1_content.read(), "This is really important content")
        f1_content.close()
        f2_content = open(f2, 'r')
        self.assertEqual(f2_content.read(), "Of course, this is even more important content")
        f2_content.close()
        f3_content = open(f3, 'r')
        self.assertEqual(f3_content.read(), "You know, they say the third time's a charm")
        f3_content.close()

        zippy.close()
        self.tear_down([f1, f2, f3, foldername], [d])


if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
