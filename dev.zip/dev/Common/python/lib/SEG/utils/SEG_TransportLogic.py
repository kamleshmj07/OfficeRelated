'''
Created on Oct 9, 2015

@author: spatel

There are certain criteria we want to implement when downloading files.

1.) Credentials will be stored in DB
2.) We want the ability the audit all files we upload or download
3.) there's a combo of business logic we may want to do.
    Specifically if received the file already, dont download.

October 2018 - passwords will be encrypted..omar style
'''

import logging.config
from SEG.utils.SEGUtils import get_trade_date, get_db_conn_name, get_log_config
from SEG.DB.DBConn import DBConn
from SEG.utils.FTP import FTP as seg_ftp
from datetime import datetime as dtt
from datetime import date
import SEG.utils.PGpy  as pg
import re
import glob2     # unix style search!
import os
import time
import shutil
import argparse
import sys


class SEG_TransportLogic(object):
    def __init__(self, connection, debug=False):
        """ NOTE: Connection should be instantiated outside of this object"""
        self.con = connection
        self.cursor = connection.cursor()

        """ 
        if we have objects to delete, place them here.
        we will delete AFTER the entire set is download.
        after a successful delete, delete the key
        object will be like
         {'vendor_name':[{filename:direction},...]}
        """
        self.objects_to_delete = {}

        # active ftp/sftp/ftps connections. Always a possibility
        # a set of data files can be associated diff vendors.

        self.connection_obj = {}
        self.debug=debug
# -------------------------------------------------------
    def get_timestamps_and_size_FS(self, server_directory, file_pattern):
        log = logging.getLogger(__name__)
        files_to_return = {}
        if (server_directory is not None):
            file_pattern = os.path.join(server_directory, file_pattern)
        log.debug("File Pattern: %s", file_pattern)
        x = glob2.glob(file_pattern)
        for fname in x:
            log.debug("Eval %s", fname)
            struct = {}

            struct['timestamp'] = str(dtt.strptime(time.ctime(
                                                    os.path.getmtime(fname)),
                                                   "%a %b %d %H:%M:%S %Y"))

            struct['byte_size'] = os.path.getsize(fname)
            files_to_return[fname] = struct
        return files_to_return

# -----------------------------------------------    
    #Replace environment variable with actual path
    @classmethod
    def replace_trans_base_path(cls,inputfilename):
        log = logging.getLogger(__name__)
        log.debug("Transporter base path value before change: %s",inputfilename)
        inputfilename = inputfilename.replace('%TRANSPORTERROOTDIR', os.environ.get('TRANSPORTER_ROOT_DIR'))
        log.info("Transporter base path value after change: %s",inputfilename)
        return inputfilename
            
# -----------------------------------------------
    def audit_data(self, vendor_tag, direction, source_name, timestamp,
                   dest_fname, bytes_io, download_time_ss, transport_name,
                   search_pattern):
        log = logging.getLogger(__name__)
        sql = """
        INSERT INTO Operations..Seg_Files_Transport_Audit
        (vendor_key,action,source_filename,destination_path,source_bytes,source_modtime,
        transport_name, download_time_ss, source_file_pattern_searched)
        VALUES
        ('{0}','{1}','{2}','{3}',{4},'{5}','{6}',{7},'{8}')
        """.format(vendor_tag, direction, source_name.replace("'","''"), dest_fname.replace("'","''"), bytes_io,
                   timestamp, transport_name, int(download_time_ss),
                   search_pattern)
        log.debug("SQL to exec : %s", sql)
        self.cursor.execute(sql)
        self.con.commit()
# ---------------------------------------------------------

    def get_ftp_parameters(self, vendor_tag=None):
        """ If tag is none - get everything. Not sure if it will be used
            that way, though."""

        log = logging.getLogger(__name__)
        sql = "SELECT * from Operations..Vendor_Credentials"
        if (vendor_tag is not None):
            sql += " WHERE vendor_key='{0}'".format(vendor_tag)
            log.info("Querying for %s", vendor_tag)

        log.debug("Da sql is %s", sql)
        return DBConn().return_ordered_resultset(connection=self.con, sql=sql)

# ---------------------------------------------------------------------

    def consume_file(self, vendor, source_filename, modtime, action):
        log = logging.getLogger(__name__)
        log.debug("Checking for %s with time %s for vendor %s",
                  source_filename, modtime, vendor)

        sql = """
            SELECT * from Operations..Seg_Files_Transport_Audit
            WHERE vendor_key='{0}'
            and action='{1}'
            AND source_filename ='{2}'
            and source_modtime = '{3}'
        """.format(vendor, action, source_filename.replace("'","''"), modtime)
        log.debug("Da SQL is %s", sql)
        res = self.cursor.execute(sql).fetchall()
        log.debug("Length :%d", len(res))
        if (len(res) > 0):
            return False
        else:
            return True
# ----------------------------------------------------------------------

    def replace_seg_symbols(self, string_value, asof_dt=None):
        """ SEG will have symbols to replace. Think YYYYMMDD or YYYYY-MM-DD ,
        or T-1, or something. Sky is the limit!"""

        log = logging.getLogger(__name__)

        if (asof_dt is None):
            asof_dt = dtt.now()

        match = re.search('\(\w*DATE[-,+]\d+\)', string_value)

        # here's a bad bad assumption. We're going to assume there can only be
        # ONE date calculation. This could be a wrong theory if we're looking
        # for files with a date range in the filename.  If somebody actually
        # wants to do this, you're better doing some wildcard like
        # "Restricted2014*.txt". We'll roll with the current design for now
        #    - SP Dec 4 2015

        if match:
            log.info("we have been asked to do a business date " +
                     "calculation!! %s", str(match.group()))

            nbr = int(re.search("[-,+]\d+", match.group()).group())
            string_value = string_value.replace(match.group(), "")
            ccy = "default"

            x = re.search("\(\w{3}_", match.group())
            if (x is not None):
                # sheer laziness. I forgot how to extract the group values.
                ccy = x.group().replace("(", "").replace("_", "")

            asof_dt = get_trade_date(db_connection=self.con,
                                     date_as_string=(
                                      asof_dt.strftime("%Y-%m-%d %H:%M:%S")
                                     ),
                                     value_to_add=nbr,
                                     ccy_calendar=ccy)

            log.info(" we have a new asof date! %s", str(asof_dt))

        string_value = re.sub("%YYYY", asof_dt.strftime("%Y"), string_value)
        string_value = re.sub("%MM", asof_dt.strftime("%m"), string_value)
        string_value = re.sub("%DD", asof_dt.strftime("%d"), string_value)
        string_value = re.sub("%yy", asof_dt.strftime("%y"), string_value)
        string_value = re.sub("%HOUR", asof_dt.strftime("%H"), string_value)
        string_value = re.sub("%MIN", asof_dt.strftime("%M"), string_value)
        string_value = re.sub("%SEC", asof_dt.strftime("%S"), string_value)
        
        string_value = SEG_TransportLogic.replace_trans_base_path(string_value)
        return string_value

# ---------------------------------------------------------------------------
    def validate_connections(self):
        ''' We have a need to swoop through connections and
            make sure they have not been closed! '''
        log = logging.getLogger(__name__)
        for k, v in self.connection_obj.items():
            log.debug("...checking connection for %s", k)
            v.keep_alive()

# ----------------------------------------------------------------------------
    def get_data_to_transport(self, name):
        sql = """
             SELECT A.*, B.connection_type,B.server_address,
             B.username,B.password, B.port
             FROM Operations..Seg_Files_To_Transport A
                    JOIN Operations..Vendor_Credentials  B
                        on A.vendor_key=B.vendor_key
            WHERE A.transport_name='{0}'
            AND A.is_active=1
            ORDER BY B.server_address """.format(name)
        results = DBConn().return_ordered_resultset(connection=self.con,
                                                    sql=sql)
        return results
# -----------------------------------------------------------------------

    def transport_files(self, name, do_audit=True, asof_date=None,
                        results=None, overwrite=False,
                        do_sizecheck_failure=True,
                        notransport_empty_file=False,
                        prepend_counter=False):
        log = logging.getLogger(__name__)
        log.info("Audit Value= %s", str(do_audit))
        log.debug("Prepend Counter= %s", str(prepend_counter))
        # ok...just grab the info
        if (results is None):
            results = self.get_data_to_transport(name)

        files_transferred = 0
        for getme in results:
            vendor = getme["vendor_key"]
            if (vendor not in list(self.connection_obj.keys())):
                password = getme["password"]
                if (os.environ.get("PGP_PRIVKEY")):
                    log.debug("PGP key has been defined. We will decrypt --%s--", password)
                    password =  pg.decrypt_string(encrypted_string= password, 
                                                  private_key_path=os.environ.get("PGP_PRIVKEY"))
                    # log.debug("Password for %s is --%s--", getme["server_address"], password)
                obj = seg_ftp(server=getme["server_address"],
                              username=getme["username"],
                              password=password,
                              method_type=getme["connection_type"],
                              port=getme["port"], debug=self.debug)
                self.connection_obj[vendor] = obj

            vendor_con = self.connection_obj[vendor]
            source_path = self.replace_seg_symbols(
                                getme["source_path"], asof_date)
            destination_path = self.replace_seg_symbols(
                                getme["destination_path"], asof_date)
            source_file = self.replace_seg_symbols(
                                getme["source_file_pattern"], asof_date)
            destination_file = self.replace_seg_symbols(
                                getme["destination_file_pattern"], asof_date)

            # ok - is it incoming or outgoing?

            list_of_files = {}
            direction = getme["action"]

            if (direction in ("Copy", "Incoming")):
                # does path existS?
                if (os.path.exists(destination_path) == False):
                    log.info("Making destination directory:%s",
                             destination_path)
                    os.makedirs(destination_path)

            log.info("Local Directory: %s, File Patt:%s, Direction : %s",
                     source_path, source_file, direction)
					 
            log.info("destination_path: %s, File Patt:%s, Direction : %s",
                     destination_path, destination_file, direction)

            if (direction in ("Copy", "Outgoing")):
                list_of_files = self.get_timestamps_and_size_FS(
                                    server_directory=source_path,
                                    file_pattern=source_file)

            elif (direction == "Incoming"):
                list_of_files = vendor_con.get_timestamps_and_size(
                                    file_pattern=source_file,
                                    server_directory=source_path)
            else:
                log.fatal("There is no %s direction. Something is wrong!",
                          getme["action"])
                raise ValueError("Unknown Value encountered for action!")

            for fname, f_struct in list_of_files.items():
                log.info("...checking if file %s was processed with tstamp %s",
                         fname, f_struct['timestamp'])

                dest_name = ""
                bytes_transferred = 0
                basename = os.path.basename(fname)
                do_me = True
                
                # Check here if we need to transport emptyt file.
                # Empty option overrides audit.
                if (notransport_empty_file and (f_struct['byte_size'] == 0)):
                    log.warning("...encountered empty file %s.", fname)
                    log.warning("...we have been told to ignore. Skip empty.")
                    do_me = False
                    
                else:
                    if (do_audit):
                        do_me = self.consume_file(vendor=vendor,
                                                  source_filename=fname,
                                                  modtime=f_struct['timestamp'],
                                                  action=getme["action"])

                if (do_me):
                    log.info("File %s needs to be processed! Transferring!",
                             fname)
                    if (destination_file != ""):
                        if (prepend_counter):
                            destination_file = str(files_transferred) +  "_" + destination_file
                            log.debug("Prepending - New file to be %s", destination_file)
                            
                        dest_name = os.path.join(destination_path,
                                                 destination_file)
                    else:
                        if (prepend_counter):
                            basename = str(files_transferred) +  "_" +  basename
                            log.debug("Prepending - New file to be %s", basename)
                            
                        dest_name = os.path.join(destination_path, basename)

                    if (direction in ("Incoming", "Copy")):
                        # I think we want to back up files if they exists
                        # ...precaution
                        if (os.path.isfile(dest_name)):
                            if (overwrite):
                                log.info("...file exists, but over write " +
                                         "exists. Delete file")
                                os.remove(dest_name)
                            else:
                                log.info("File %s already exists. Back it up",
                                         dest_name)

                                os.rename(dest_name, dest_name + "_" +
                                          dtt.now().strftime("%Y%m%d_%H%M%S"))

                        log.info("Placing %s from vendor %s to %s",
                                 fname, vendor, dest_name)

                    start = time.time()  # start timer
                    if (direction == "Incoming"):
                        bytes_transferred = vendor_con.get_file(
                                                server_location=fname,
                                                local_location=dest_name)

                    elif (getme["action"] == "Copy"):
                        shutil.copyfile(fname, dest_name)
                        bytes_transferred = os.path.getsize(dest_name)
                    else:
                        log.info("Outgoing. Uploading from %s to %s for " +
                                 "vendor %s.", fname, dest_name, vendor)
                        bytes_transferred = vendor_con.put_file(
                                            local_location=fname,
                                            server_location=dest_name,
                                            do_sizecheck_failure=(
                                                do_sizecheck_failure))

                    secs_passed = time.time() - start
                    log.debug("...file transferred. Took %d secs .",
                              secs_passed)

                    if ((bytes_transferred != f_struct["byte_size"]) and
                            do_sizecheck_failure):

                        log.fatal("Bytes transferred dont match! " +
                                  "Uh-oh.(transfer) %d != %d (source)",
                                  bytes_transferred,
                                  f_struct["byte_size"])
                        raise ValueError("Bytes transferred dont match. wtf?")
                    else:
                        log.info("Source:%s, Destination:%s , " +
                                 "Bytes Transferred:%s",
                                 fname, dest_name, bytes_transferred)

                        if (getme["delete_source"] == 1):
                            log.info("...we have been asked to delete the " +
                                     "source file %s", fname)
                            log.info("...add it to our dictionary, and rely " +
                                     "on the main program to call deletion")
                            # vendor_con.delete_file(fname,direction)
                            if (vendor not in list(self.objects_to_delete.keys())):
                                self.objects_to_delete[vendor] = []

                            self.objects_to_delete[vendor].append(
                                                    {"filename": fname,
                                                     "direction": direction})

                    self.audit_data(vendor_tag=vendor,
                                    direction=getme["action"],
                                    source_name=fname,
                                    timestamp=f_struct['timestamp'],
                                    dest_fname=dest_name,
                                    bytes_io=bytes_transferred,
                                    download_time_ss=secs_passed,
                                    transport_name=getme["transport_name"],
                                    search_pattern=source_file)
                    # we want the audit to indicate bytes transferred.
                    # if we are given the ignore option & the numbers
                    # don't match, take whatever was passed back.
                    files_transferred += 1
                else:
                    # Alex request for logging.
                    # Nov 2017 - Alex request to make it a debug
                    log.debug("...file %s was already consumed. Skip it", fname)
        
        log.debug("%d files transferred on this run!", files_transferred)
        return files_transferred

    # Delete method.
    # We need this as we want the capability to delete on an entire set.
    # Basically - something that runs OUTSIDE of "main"
    # of the SEG_TransportLogic.py

    def delete_scheduled_files(self):
        log = logging.getLogger(__name__)
        vendors = list(self.objects_to_delete.keys())
        files_deleted = 0
        for vendor in vendors:
            vendor_con = self.connection_obj[vendor]
            files_to_delete = self.objects_to_delete[vendor]
            for obj in files_to_delete:
                log.info("Deleting filename :%s on direction :%s",
                         obj["filename"], obj["direction"])
                vendor_con.delete_file(obj["filename"], obj["direction"])
                files_deleted += 1
            # if we 're here...delete was successful. delete the key
            self.objects_to_delete.pop(vendor, None)
        log.debug("Deleted %d files", files_deleted)
        return files_deleted
    # ------------------------------------------------------------------------------------------------------

if __name__ == "__main__":
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument("--ini_file",help="location of db config json file")
    
    arg_parser.add_argument("--section_name",help="database connection name from json file")
    
    arg_parser.add_argument("--log_config_file",help="Your log config file")
    
    arg_parser.add_argument("--transport_name", required=True,
                            help="What set of files are we moving?")

    arg_parser.add_argument("--asof_date",
                            help="As of Date, if any. " +
                            "Else today.Please use YYYY-MM-DD")

    arg_parser.add_argument("--ignore_audit", action='store_false',
                            help="Dude, ignore audits and grab all data")

    arg_parser.add_argument("--no_backup",
                            help="by default, we backup files on 'incoming' " +
                            " loads. In this case, just overwrite",
                            action='store_true')

    arg_parser.add_argument("--size_check_ignore", action='store_false',
                            help="generally for outgoing files, " +
                            "ignore the file size check to ensure proper" +
                            " byte transfer")
    # Below added April 2016
    arg_parser.add_argument("--no_transport_empty_file", action='store_true',
                            help="use this param to ignore transporting " +
                            " a 0 byte file.")
    
    # Prepend a counter - New Feature. Nov 2017
    arg_parser.add_argument("--prepend-counter", action='store_true',
                            help="Have an internal counter. Prepend it to the destination filename")
    
    # 2018 feature for debug.
    arg_parser.add_argument("--debug", action="store_true",
                             help="put logging and ftp/sftp protocol into debug mode")
    
    options = arg_parser.parse_args()
    
    db_con = DBConn().get_connection(conn_name=options.section_name)
    asof_date = None

    if (options.asof_date is not None):
        # this value needs to be a date :
        values = options.asof_date.split("-")

        asof_date = date(year=int(values[0]),
                         month=int(values[1]),
                         day=int(values[2]))
    if (options.debug):
        logging.config.fileConfig(get_log_config(options.log_config_file),
                              defaults={'filename_append':
                                        options.transport_name,
                                        'level': "DEBUG",
                                        'run_id': get_db_conn_name(options.section_name)})
    else:
        logging.config.fileConfig(get_log_config(options.log_config_file),
                              defaults={'filename_append':
                                        options.transport_name,
                                        'run_id': get_db_conn_name(options.section_name)})
    log = logging.getLogger(__name__)
 
    log.info("DB Connected to %s. Doing transport for name %s",
             get_db_conn_name(options.section_name), options.transport_name)

    seg_transfer = SEG_TransportLogic(db_con, options.debug)
    
    try:
        files_moved = seg_transfer.transport_files(name=options.transport_name,
                                                   do_audit=options.ignore_audit,
                                                   asof_date=asof_date,
                                                   overwrite=options.no_backup,
                                                   do_sizecheck_failure=(
                                                                         options.size_check_ignore),
                                                   notransport_empty_file = options.no_transport_empty_file,
                                                   prepend_counter = options.prepend_counter)
    except Exception as e:
        log.fatal("Who - Fatal Error on transport name %s", options.transport_name)
        log.fatal("ERROR:%s", str(e))
        sys.exit(-2)
        
    log.info("We are transferred %d files for transport name %s",
             files_moved, options.transport_name)

    seg_transfer.delete_scheduled_files()
