from SEG.utils.SEG_TransportLogic import SEG_TransportLogic
from SEG.DB.DBConn import DBConn
from ldap3 import Server, Connection, ALL, ALL_ATTRIBUTES, SUBTREE
import SEG.utils.PGpy as pg
import os
from SEG.utils.SEGUtils import  get_db_conn_name


class ADObject:
    
    def __init__(self,
                 database=None,
                 vendor_key='LdapServer'):
        """Connect to the LDAP server"""
        if database is None:
            self.database = get_db_conn_name()
        else:
            self.database = database
        db_connection = DBConn().get_connection(conn_name=self.database)
        payload = SEG_TransportLogic(connection=db_connection).get_ftp_parameters(vendor_tag=vendor_key)
        if os.environ.get("PGP_PRIVKEY"):
            self.sql_password = pg.decrypt_string(encrypted_string=payload[0]['password'],
                                                  private_key_path=os.environ.get("PGP_PRIVKEY"))
        else:
            raise ValueError("PGP is not defined - SQL credentials will not be decrypted - exiting.")
            
        self.sql_username = payload[0]['username']
        self.sql_server_address = payload[0]['server_address']
        self.server = Server(self.sql_server_address, get_info=ALL)
        self.conn = Connection(self.server,
                               user=self.sql_username,
                               password=self.sql_password,
                               auto_bind=True)

    def get_user_name(self, user_id):
        self.conn.search(search_base='DC=SEG,DC=local',
                         search_filter='(&(objectCategory=person)(objectClass=user) (sAMAccountName=%s))' % user_id,
                         attributes=ALL_ATTRIBUTES)
        return self.conn.entries[0]['cn']
        
    # Get user info - ALL Attributes    
    def get_email_address(self, user_id):
        self.conn.search(search_base='DC=SEG,DC=local',
                         search_filter='(&(objectCategory=person)(objectClass=user) (sAMAccountName=%s))' % user_id,
                         attributes=ALL_ATTRIBUTES)
        # Service Accounts may not have this attribute

        if ("mail" in self.conn.entries[0]):
            return self.conn.entries[0]['mail']
        else:
            return ""

    # Get the groups the current user is in.
    def get_groups(self, user_id):
        self.conn.search(search_base='DC=SEG,DC=local',
                         search_filter='(&(objectCategory=person)(objectClass=user) (sAMAccountName=%s))' % user_id,
                         attributes=ALL_ATTRIBUTES)
        return self.conn.entries[0]['memberof']
    
    def is_group_member(self, user_id, groupname):
        self.conn.search(search_base='DC=SEG,DC=local',
                         search_filter='(&(objectCategory=person)(objectClass=user) (sAMAccountName=%s))' % user_id,
                         attributes=ALL_ATTRIBUTES)
        if len(self.conn.entries) == 1:
            for entry in self.conn.entries:
                for group in entry['memberof']:
                    if str(group.split(',')[0])[3:] == groupname:
                        return True
        return False
        
    def get_user_info(self, user_id, attribute):
        self.conn.search(search_base='DC=SEG,DC=local',
                         search_filter='(&(objectCategory=person)(objectClass=user) (sAMAccountName=%s))' % user_id,
                         attributes=ALL_ATTRIBUTES)

        if (attribute in self.conn.entries[0]):
            return self.conn.entries[0][attribute]    
        else:
            return ""

    # Get all members of a group
    def get_group_members(self, group_name):
        result = []

        ## Get information about Distribution groups
        self.conn.search(
            search_base='DC=SEG,DC=local',
            search_filter='(&(objectClass=user)(memberOf=CN=' + group_name + ',OU=Distribution,OU=Groups,DC=SEG,DC=local))',
            search_scope=SUBTREE,
            attributes=[
                'sAMAccountName'
            ],
            size_limit=0,
        )

        for entry in self.conn.entries:
            name = str(entry.entry_dn).split(',')[0]
            if name.startswith("CN="):
                name = name[3:]
            email = entry.sAMAccountName
            result.append((name, str(email)))

        ##  Get information about Security groups
        self.conn.search(
            ## search_base='OU=Select Equity Group,DC=SEG,DC=local',
            search_base='DC=SEG,DC=local',
            search_filter='(&(objectClass=user)(memberOf=CN=' + group_name + ',OU=Security,OU=Groups,DC=SEG,DC=local))',
            ## search_filter='(&(objectClass=user)(memberOf=CN=' + group_name + ',OU=Groups,DC=SEG,DC=local))',
            search_scope=SUBTREE,
            attributes=[
                'sAMAccountName'
            ],
            size_limit=0,
        )

        for entry in self.conn.entries:
            name = str(entry.entry_dn).split(',')[0]
            if name.startswith("CN="):
                name = name[3:]
            email = entry.sAMAccountName
            result.append((name, str(email)))

        return result

    ## Get all employees of SEG
    def get_all_persons(self, short_form=True):
        self.conn.search('OU=Select Equity Group,DC=SEG,DC=local', '(objectclass=person)',
                         attributes=[
                             'sAMAccountName'
                         ],
                         )
        all_persons_set = set()

        for count, full_entry in enumerate(self.conn.entries):
            one_person = str(full_entry).split(',')[0]
            if one_person.startswith("DN: CN="):
                one_person = one_person[7:]
            if short_form:
                all_persons_set.add(one_person)
            else:
                all_persons_set.add(str(full_entry))
        return all_persons_set

    ## Get list of all groups
    def get_all_groups(self, distribution_group=True):

        if distribution_group:
            self.conn.search('DC=SEG,DC=local',
                             '(&(objectCategory=group)(!(groupType:1.2.840.113556.1.4.803:=2147483648)))', ## All distribution groups
                             attributes=[
                                 'sAMAccountName',
                             ],
                            )
        else:
            self.conn.search('DC=SEG,DC=local',
                             '(objectclass=group)',    ## All groups
                             attributes=[
                                 'sAMAccountName',
                             ],
                            )

        all_groups_set = set()
        for count, full_group in enumerate(self.conn.entries):
            full_group = str(full_group)
            my_group = full_group.split(',')[0]
            if my_group.startswith("DN: CN="):
               my_group = my_group[7:]
            all_groups_set.add(my_group)

        return all_groups_set