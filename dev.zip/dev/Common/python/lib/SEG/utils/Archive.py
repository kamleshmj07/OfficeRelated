import logging
import os
import shutil
import datetime
from SEG.utils.SEGUtils import get_app_archive_dir
from SEG.storage.StorageObjects import AzureStorageObj
import sys
from azure.storage.file import  models

def auto_archive_fs(filename):
    """Automaticlly moves filename to the application archive dir.  Adds timestamp to filesname."""
    archive_dir = get_app_archive_dir()
    if not os.path.exists(archive_dir):
        os.makedirs(archive_dir)
        
    file_basename = os.path.basename(os.path.splitext(filename)[0])
    file_extension = os.path.splitext(filename)[1]
    archive_file = archive_dir + file_basename + '_' + datetime.datetime.now().strftime('%Y%m%d%H%M%S') + file_extension
    
    shutil.copy(filename, archive_file)
        
def auto_archive(filename, share="seg-app-archives", archive_subdir=None):
    """ Move file to Azure!!
        return os.path.abspath(os.path.dirname(sys.argv[0])) + '\..\\' + '\\archive\\' + datetime.now().strftime("%Y%m%d") + '\\'

        What we are doing is creating a share like...
            seg-app-archives
                    --> Directory (i.e the repo)
                        --> date

    """
    logger = logging.getLogger(__name__)
    if ( (os.environ.get("AZURE_KEY") is None) or 
            (os.environ.get("AZURE_RESOURCE") is None)):
        logger.warning("AZURE environment variables are not set. We will revert to old fs archive method")
        auto_archive_fs(filename)
    else:
        logger.debug("...connecting to Azure.")
        az_con = AzureStorageObj(azure_account_name = os.environ.get("AZURE_RESOURCE"),
                             azure_account_key = os.environ.get("AZURE_KEY"))
        logger.debug("Connected to resource %s", os.environ.get("AZURE_RESOURCE") )
        if (not az_con.check_if_share_exists(share)):
            logger.fatal("%s SHARE does not exist on Azure. Failing!", share)
            raise NotImplementedError
        # we're here.
        if (archive_subdir is None):
            # we need to eval. Old days, code existed in bin
            # assume we get back bin, and then subtract 2 from the below index!!
            dname = os.path.abspath(os.path.dirname(sys.argv[0])) 
            array = dname.split(os.path.sep)
            archive_subdir = array[len(array)-2]
        logger.debug("Archive subdir is %s. Appending date subdir", archive_subdir )
        # append date
        archive_subdir =  os.path.join(archive_subdir,datetime.datetime.now().strftime("%Y%m%d"))
        # checking to see if it exists.
        if (not az_con.file_service.exists(share_name=share, directory_name=archive_subdir)):
            logger.debug("Creating archive dir: %s", archive_subdir)
            az_con.create_nested_directory(share_name=share, dir_path=archive_subdir)
            logger.info("Archive Directory %s created", archive_subdir)
        # move file
        file_basename = os.path.basename(os.path.splitext(filename)[0])
        file_extension = os.path.splitext(filename)[1]
        archive_file = file_basename + '_' + datetime.datetime.now().strftime('%Y%m%d%H%M%S') + file_extension
        # Create SMBProperties first.
        ctime = datetime.datetime.fromtimestamp(os.path.getctime(filename), datetime.timezone.utc)
        mtime = datetime.datetime.fromtimestamp(os.path.getmtime(filename), datetime.timezone.utc)
        smb = models.SMBProperties(creation_time=ctime.strftime('%Y-%m-%dT%H:%M:%S.%f0Z'),
                                       last_write_time=mtime.strftime('%Y-%m-%dT%H:%M:%S.%f0Z')
                                       )
        metadata = {"comments": "Original location:" + filename}
        az_con.file_service.create_file_from_path(share_name=share ,
                                        local_file_path = filename,
                                        directory_name=archive_subdir, 
                                        smb_properties=smb, metadata=metadata,
                                        file_name=archive_file)
        logger.debug("%s archived.", filename)



    