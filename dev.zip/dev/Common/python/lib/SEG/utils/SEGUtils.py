import logging
import os
import sys
import time
from datetime import datetime
import json
import glob


logger = logging.getLogger(__name__)


def get_month_end_dates(db_connection, rolling_values = 12, 
                        first_of_month=datetime.now().strftime("%Y-%m-01")):
    ''' We want to get a rolling set of dates representing month end.
        in our positions table :)
    '''
    
    sql = """ SELECT TOP {0} * FROM ClientServices..SEG_FirstMonthEndAppraisal_View
                WHERE MaxDate < '{1}' """.format(rolling_values, first_of_month)
    logger.info("SQL=%s", sql)
    cursor = db_connection.cursor()
    cursor.execute(sql)
    value=cursor.fetchall()  
    cursor.close()
    return value


# -------------------------------------------------------------------------------
    
    
def get_trade_date(db_connection,date_as_string,value_to_add,ccy_calendar="default"):
    
    if (ccy_calendar != "default"):
        ccy_calendar ="'" + ccy_calendar +"'"
        
    sql =  "SELECT Operations.dbo.get_trade_date('{0}',{1},{2})".format(date_as_string,value_to_add,ccy_calendar)
    cursor = db_connection.cursor()
    logger.debug("SQL=%s", sql)
    cursor.execute(sql)
    value=cursor.fetchall()    
    cursor.close()
    return value[0][0]

# --------------------------------
def is_market_closed(db_connection,date_as_string,ccy_calendar="default"):
    
    if (ccy_calendar != "default"):
        ccy_calendar="'" + ccy_calendar +"'"
        
    sql =  "SELECT Operations.dbo.is_market_closed('{0}',{1})".format(date_as_string,ccy_calendar)
    logger.debug("SQL=%s", sql)
    cursor = db_connection.cursor()
    cursor.execute(sql)
    value=cursor.fetchall()    
    cursor.close()
    if (value[0][0] == 1):
        return True
    else:
        return False

# --------------------------------------------------------------

#Take all of the variables supplied and returns the first one with a value
#If no variables, returns None
def coalesce_variables(*vars_passed):
    """Returns the first variable with non-None value
    
    Take in any number of variables and return the first on with a value
    """
    
    for var in vars_passed:
        if var:
            return var
    
    return None

#Gets the script name of the main Python script with the .py extension removed
def get_script_name_no_ext():
    """Returns the script name without the extention or path"""
    return os.path.splitext(os.path.basename(sys.argv[0]))[0]

#Get the root directory of the application
def get_app_root_dir():
    """Returns the root directory of the application"""
    return os.path.abspath(os.path.dirname(sys.argv[0])) + '\..\\'

#Test if the file exists and is readable
def check_file_readable(filename):
    """Return success or raises exception
    Checks to see if the file given can be read
    """
    if os.path.isfile(filename) and os.access(filename, os.R_OK):
        return
    else:
        raise Exception(filename + " is not a readable file")
    
def check_file_writable(filename):
    """Return success or raises exception
    Checks to see if the file given can be written
    """
    if not os.path.isfile(filename) or os.access(filename, os.W_OK):
        return
    else:
        raise Exception(filename + " is not a writable file")
    
def get_app_log_dir():
    """Returns the log directory of the application for the current date"""
    # Mod Feb 2017 ...we may want to set the env variable LOG_DIR
    
    return os.path.join(os.getenv('LOG_DIR',os.path.join(get_app_root_dir(),"log")) , datetime.now().strftime("%Y%m%d"))

def get_app_archive_dir():
    """Returns the archive directory of the application for the current date"""
    return get_app_root_dir() + '\\archive\\' + datetime.now().strftime("%Y%m%d") + '\\'

def get_app_work_dir():
    """Returns the work directory of the application"""
    return get_app_root_dir() + '\\work\\' 

def clean_directory(directory, days_retained=14):
    """Removes all the files in directory give older than days_returned (default = 14)"""
    time_cutoff = time.time() - (days_retained * 86400)
    for filen in os.listdir(directory):
        filename = directory + filen
        if os.path.isfile(filename):
            if os.stat(filename).st_ctime < time_cutoff:
                os.remove(filename)
                
    
def json_parser(conn_name, json_file):
    with open(json_file) as json_file:
        data = json.load(json_file)
    if not data[conn_name]:
        raise Exception("Could not find section " + conn_name + " in " + json_file)
    return data[conn_name]

def find_latest_file_in_dir(target_path, file_pattern):
    path_to_lookup = target_path+file_pattern
    list_of_files = glob.glob(path_to_lookup) # * means all if need specific format then *.csv
    latest_file = max(list_of_files, key=os.path.getctime)
    return latest_file

def get_db_conn_name(default_db_conn_name=None):
    if not os.environ.get('PYODBC_SERVER'):
        raise Exception("Missing environment variable PYODBC_SERVER")
    return os.environ.get('PYODBC_SERVER') if not default_db_conn_name else default_db_conn_name

def get_log_config(default_log_config=None):
    if not os.environ.get('PY_LOG_CONFIG'):
        raise Exception("Missing environment variable PY_LOG_CONFIG")
    return os.environ.get('PY_LOG_CONFIG') if not default_log_config else default_log_config