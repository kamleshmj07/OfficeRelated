import logging

from SEG.DB.DBConn import DBConn as db_util
from datetime import datetime as dtt


logger = logging.getLogger(__name__)


def get_transported_files_to_process(db_connection, transport_name=None, source_file_pattern=None):
    ''' We want to get files that were downloaded by the transporter, but have not been
        post processed. Either transport_name or source file pattern is required.
    '''
    
    if (transport_name is None) and (source_file_pattern is None):
        logger.error("The param transporter_name or source_file_patter must be passed!")
        raise Exception ("Transport Name or Source Name not defined!")
    
    sql_append=""
    if (transport_name is not None):
        sql_append = " AND transport_name='" + transport_name + "'"
    if (source_file_pattern is not None):
        sql_append += " AND source_file_pattern_searched='" + source_file_pattern.replace("'","''")  + "'"
        
    sql = """
                
    SELECT * from Operations..Seg_Files_Transport_Audit
            WHERE post_processed=0
            {0} 
            order by source_modtime """.format(sql_append)


    return db_util().return_ordered_resultset(db_connection, sql)

# ----------------------------------------------------------------------

def acknowledge_file_processed(db_connection, source_filename, 
                               destination_path,  
                               comments="Processed at "  + dtt.now().strftime("%Y-%m-%d %H:%M:%S")):
                                
    
    
    cur = db_connection.cursor()
    sql = """

            UPDATE Operations..Seg_Files_Transport_Audit
        SET post_processed=1, comments='{0}'
        WHERE post_processed=0 AND destination_path='{1}'
        AND source_filename='{2}'
        
        """.format(comments, destination_path.replace("'","''"), source_filename.replace("'","''"))
    logger.debug("Audit File SQL:%s", sql)
    cur.execute(sql)
    cur.commit()
    cur.close()
    
# -------------------------------------------------------------------------------
    