import pgpy
import subprocess
import time
import os
import tempfile
import logging
import sys
'''


October 15, 2018 :
    1.) Omar's comments below. I think he took from the pydocs of the pgp module
    2.) Omar was relying on the six package installed in Common. SIX==1.10.0.
    3.) Looking at CT-JOB1, and NY-JOb1, that's what we have. So the hardcode for sys.append to the common dir has been removed
    4.) I think this module will and should do "ASCII-armored PGP data". While the internet has mixed feelings about this,
        our module requires it. Armor it here, in case we decided to change how the encryption is done!
        
    For this test I had to create my own key using the module. I have tested it and the GNUpg executable is able
     to import and accept this key.
     To start this process we start with the command:
     
     key = pgpy.PGPKey.new(PubKeyAlgorithm.RSAEncryptOrSign, 4096) - RSA can also be changed to DSA or ECDSA.
     
     We now assign some credentials using:
     
     uid = pgpy.PGPUID.new('Abraham Lincoln', comment='Honest Abe', email='abraham.lincoln@whitehouse.gov')
     
     Now we put it all together, assigning the uid to the key, and specifying all of the preferences(flags) for the key.
     
     key.add_uid(uid, usage={KeyFlags.Sign, KeyFlags.EncryptCommunications, KeyFlags.EncryptStorage},
            hashes=[HashAlgorithm.SHA256, HashAlgorithm.SHA384, HashAlgorithm.SHA512, HashAlgorithm.SHA224],
            ciphers=[SymmetricKeyAlgorithm.AES256, SymmetricKeyAlgorithm.AES192, SymmetricKeyAlgorithm.AES128],
            compression=[CompressionAlgorithm.ZLIB, CompressionAlgorithm.BZ2, CompressionAlgorithm.ZIP,
             CompressionAlgorithm.Uncompressed])
             
     You can also add the parameter  key_expires=timedelta(days=365) to generate a key which expires.
     
     This generates a private key, which can be exported in two formats
     
     # binary
     keybytes = bytes(key)

     # ASCII armored
     keystr = str(key)
     
     To generate the public key you must unfortunately use Kleopatra or the GNUPG executable by importing
      the generated private key, then exporting from there. After this step you will have both a public
       and a private key.
     
'''

armoured_header = """-----BEGIN PGP MESSAGE-----\nVersion: PGPy v0.4.3\n"""
armoured_footer = """-----END PGP MESSAGE-----\n"""


# Decrypt file assumes you gpg executable on the source machine.
# It also assumes the private key is registered, and the public
# key of the encryptor is registered as well.

def decrypt_file(filename, to_filename=None, overwrite=False):
    log = logging.getLogger(__name__)
    if (to_filename is None):
        # get basename...attach to temp
        basename = os.path.basename(filename)
        to_filename = os.path.join (tempfile.gettempdir(), basename)
    log.debug("...pgp decryption to %s",  to_filename)
    if overwrite:
        log.debug('Removing file {}'.format(to_filename))
        try:
            os.remove(to_filename)
        except:
            log.error("could not file file at {}".format(to_filename))
    cmd = "gpg --output \""  + to_filename +  "\" --decrypt \"" + filename +"\""


    log.debug("Executing : %s", cmd )

    timeout = 60
    proc = subprocess.Popen(cmd, 
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    # proc.wait()
    # this is a 60 second time out
    while proc.poll() is None and timeout > 0:
        time.sleep(1)
        timeout -= 1
    # Let's be safe here and flush stuff out
    log.debug("out of poll")
  
    
    if (timeout == 0):
        log.fatal("Hmm...GPG Call timed out after 30 seconds! Exit" )
        """
            The below does not work as proc.stdout is not receiving
            until the parent process is dead. So if we kill the child process
            via proc.kill or terminate, we only see a subset of the message.
            
            If I kill the parent, I see it all but without killing the child
            
            with that said...don't print any message. It can be misleading
        
            I don't know if this is a Windows behavior only, or Eclipse/Windows, or what
        # proc.kill()
        proc.stdout.flush()
        for line in iter(proc.stdout.readline, ''):
            log.fatal("%s", line)
        """
        sys.exit(-1)


    log.debug("The return code is %d", proc.returncode)
    proc.stdout.flush()
    poutput = proc.stdout.read()
    log.debug("---------------------------------------")
    log.debug("Decryption Output Received: %s", poutput)
    if (proc.returncode != 0):
        log.fatal("--------------------------------------")
        log.fatal("WHOA! Unable to decrypt file %s. We will exit.",
                  filename)
        log.fatal("%s", poutput)
        log.fatal("--------------------------------------")
        sys.exit(-2)
    log.debug("--------------------------------------")
    return to_filename
    
# ----------------------------------------------------
def encrypt_string(string, public_key_path):
    pub_key, _ = pgpy.PGPKey.from_file(public_key_path)
    text_message = pgpy.PGPMessage.new(string)
    stuff = pub_key.encrypt(text_message)
    # print str(stuff)
    return str(stuff).replace(armoured_header,"").replace(armoured_footer,"")

# -----------------------------------------------------------------
def decrypt_string(encrypted_string, private_key_path):
    private_key, _ = pgpy.PGPKey.from_file(private_key_path)
    encrypted_string = armoured_header + encrypted_string + armoured_footer
    # print encrypted_string
    emsg = pgpy.PGPMessage.from_blob(encrypted_string)
    return str(private_key.decrypt(emsg).message)



