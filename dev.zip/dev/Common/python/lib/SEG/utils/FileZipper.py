#!/usr/bin/env python
# encoding: utf-8
'''
SEG.utils.FileZipper -- shortdesc

SEG.utils.FileZipper is a description

It defines classes_and_methods

@author:     segappdev

@copyright:  2016 SEG. All rights reserved.

@license:    thou shalt not use this for evil

@contact:    segappdev
'''

import sys
import os
import argparse
import logging
from SEG.utils.SEG_TransportLogic import SEG_TransportLogic
from SEG.DB.DBConn import DBConn
import zipfile
import fnmatch
import shutil
from datetime import datetime
from SEG.utils.SEGUtils import get_db_conn_name, get_log_config

def create_zipfoldername():
    """ Returns a date-stamped zip folder name str """
    date = (datetime.now()).strftime("%m%d%Y")
    return "zippedfiles_" + date + ".zip"


def zip_files(filenames_list, foldername=None):
    """ Zips multiple attachment into a zip folder. """
    log = logging.getLogger(__name__)
    if foldername is None:
        foldername = create_zipfoldername()
    elif foldername.split(".")[-1] != "zip":
        foldername += ".zip"
    z = zipfile.ZipFile(foldername, 'w')
    for f in filenames_list:
        log.info("...adding %s to zip file", f)
        z.write(f, f.split(os.sep)[-1])
    z.close()
    return foldername

# ripped off from stackoverflow.

def zipdir(path, ziph=None, pattern='*', foldername=None):
    # ziph is zipfile handle
    log = logging.getLogger(__name__)
    if foldername is None:
        foldername = create_zipfoldername()
    if ziph is None:
        ziph = zipfile.ZipFile(foldername, 'w', zipfile.ZIP_DEFLATED)
    files_added=[]
    for root, dirs, files in os.walk(path):
        log.debug("Root=%s",root)
        log.debug("processing %s",dirs)
        for filename in fnmatch.filter(files, pattern):
            if foldername != filename:
                log.info("...adding %s to zip file", filename)

                ziph.write(os.path.join(root, filename), os.path.join(root.replace(path,""),filename))
                files_added.append(os.path.join(root, filename))
            
    return files_added, foldername
            

def main(argv=None):
    '''   Usage:
                    --root-dir C:/temp/zip_me_dir 
                    --pattern "*" (optional)
                    --back-up-dir C:/temp/YYYYMMDD (optional)
                    --zip-file-name C:/tmp/BBH.SEG.YYYMMDD-HHMMSS.zip
                    --log-config-file <optional>
                    
        if back-up-dir exists, backup all files zipped here, including the directory structure
        if pattern exists, use it
        
    '''
    
    arg_parser = argparse.ArgumentParser()
    
    arg_parser.add_argument("--pattern", default="*",
                            help="File Pattern we are looking for. Default to everything")
    
    arg_parser.add_argument("--back-up-dir", 
                            help="Include a location if you want to back up the files/dir structure you have zipped.")

    arg_parser.add_argument("--section_name",help="database connection name from json file")
    '''
    keep around if we need it
    arg_parser.add_argument("--ignore_audit", action='store_false',
                            help="Dude, ignore audits and grab all data")
    '''
    
    arg_parser.add_argument("--root-dir", required=True,
                            help="Root Directory we start off with to zip files.")
    
    arg_parser.add_argument("--zip-file-name", required=True,
                            help="The name of the ZIP File. Can add %YYYY%MM%DD%HOUR%MIN%SEC for any timestamp thing.")

    options = arg_parser.parse_args()
    transportObj = SEG_TransportLogic(DBConn().get_connection(conn_name=options.section_name,
                                     conn_info_file=None))
    zip_filename = transportObj.replace_seg_symbols(string_value=options.zip_file_name)
    
    
    logging.config.fileConfig(get_log_config(),
                              defaults={'filename_append':
                                        os.path.basename(zip_filename),
                                        'run_id': get_db_conn_name(options.section_name)})
    log = logging.getLogger(__name__)
    root_dir = transportObj.replace_seg_symbols(string_value = options.root_dir)
    log.info("Directory to search: %s", root_dir)
    log.info("Search and zipping : %s", options.pattern)
    log.info("Creating Zip File %s", zip_filename)
    bdir = None
    
    if (options.back_up_dir is not None):
        bdir = transportObj.replace_seg_symbols(string_value=options.back_up_dir)
        if (os.path.exists(bdir) == False):
            log.info("Making destination directory:%s",bdir)
            os.makedirs(bdir)
     
    if (options.pattern == "*"):
        log.info("We want to zip an entire structure! use shutil")
        shutil.make_archive(zip_filename.replace(".zip",""), 'zip', root_dir)
        if (bdir is not None):
            log.info("Moving entire directory!")
            shutil.move(root_dir,bdir)
    else:   
        zipf = zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED)
        files_zipped = zipdir(root_dir, zipf,options.pattern)
        log.info("Zipped up %d files", len(files_zipped))
        zipf.close()
        if (bdir is not None):
            log.info("...we have been asked for to move files")
            for fname in files_zipped:
                log.debug("Moving file %s", fname)
                shutil.move(fname,bdir) # Note - we're not keep the directory structure here. Simply 
                                        # moving the file to indicate it was zipped and backed up!
                #os.remove(fname)
    log.info("...complete. Zip file created")
                
# ----------------------------------------------------------------------

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("ERROR while running FileZipper: " + str(e))
        sys.exit(-1)