from SEG.DB.DBConn import DBConn
import sys
import os
import argparse
import itertools
import SEG.utils.PGpy as Pg
from SEG.utils.SEGUtils import get_db_conn_name, get_log_config


def create_sql_string(public_key):
    if (public_key is None):
        print("The Public Key was not set. It is required for this Option!!\n")
        sys.exit(-1)
    first_rotation = 0
    value_list = [input("What is the Vendor Key? "), input("Connection type? "),
                  input("Server Address? "), input("Username? "), input("Password? "),
                                                           eval(input("Active? (1 or 0) ")), input("Comments? "),
                                                           input("Port? [null] ")]
    values_statement = ''
    for item in value_list:
        if first_rotation == 0:
            values_statement += "'%s'" % item
        elif item == 'NULL' and first_rotation == 4:
            values_statement += ', %s' % item
        elif item == 'NULL' and first_rotation != 4:
            values_statement += ", %s" % item
        elif first_rotation == 7:   #port
            if (item == ''):
                item = "NULL"
            values_statement += ", %s" % item
            
        elif first_rotation == 4 and item != 'NULL':
            values_statement += ", '%s'" %  Pg.encrypt_string(item, public_key)
        elif first_rotation == 5:
            values_statement += ', SYSDATETIME()'
            values_statement += ", %s" % item
        else:
            values_statement += ", '%s'" % item
        first_rotation += 1
    sql = """
        INSERT INTO [Operations].[dbo].[Vendor_Credentials]
     (vendor_key, connection_type, server_address, username, password, db_update_time, is_active, comments, port)
    VALUES(%s)
        """ % values_statement
    print(sql)
    return sql


def insert_credentials(db_connection, public_key):
    if (public_key is None):
        print("The Public Key was not set. It is required for this Option!!\n")
        sys.exit(-1)
    cursor = db_connection.cursor()
    cursor.execute(create_sql_string(public_key))
    cursor.commit()


def find_vendor_key(db_connection, private_key):
    if (private_key is None):
        print("The Private Key was not set. It is required for this Option!!\n")
        sys.exit(-1)
    while 1:
        vendor_key_input = input("What is the vendor Key? ")
        sql = """
        Select * from operations.dbo.Vendor_Credentials WHERE vendor_key LIKE '%%%s%%'
        """ % vendor_key_input
        results = DBConn().return_ordered_resultset(connection=db_connection, sql=sql)
        if len(results) < 1:
            print("====================No results for Vendor_Key %s Please try again.======================== "
                  % vendor_key_input)
        elif len(results) == 1:
            print("==============================One result for Vendor_Key = %s==============================="
                  % vendor_key_input)
            for key, value in results[len(results)-1].items():
                if key == 'password':
                    if str(value) == 'None':
                        print((key), (' = '), (value))
                    else:
                        print((key), (' = '), (decrypt_one(value, private_key)))
                elif key == 'vendor_key':
                    vendor_key_input = value
                else:
                    print((key), (' = '), (value))
            break
        elif len(results) >= 1:
            dictionary = {}
            print("==================================%s Results for Vendor_key = %s=========================== "
                  % (len(results), vendor_key_input))
            for options in range(len(results)):
                print("=======================================Option %s=======================================" % (
                        options + 1))
                for key, value in results[options].items():
                    if key == 'password':
                        if str(value) == 'None':
                            print((key), (' = '), (value))
                        else:
                            print((key), (' = '), (decrypt_one(value, private_key=private_key)))
                    else:
                        print((key), (' = '), (value))
                    if key == 'vendor_key':
                        dictionary.update({value: (options+1)})
            choice = eval(input("Which Option would you like to choose? 0 to restart "))
            if choice == 0:
                continue
            else:
                vendor_key_input = list(dictionary.keys())[list(dictionary.values()).index(choice)]
                break
    return vendor_key_input, results


def search(db_connection, private_key):
    if (private_key is None):
        print("The Private Key was not set. It is required for this Option!!\n")
        sys.exit(-1)
    while 1:
        vendor_key_input = input("What is the vendor Key? ")
        sql = """
        Select * from operations.dbo.Vendor_Credentials WHERE vendor_key LIKE '%%%s%%'
        """ % vendor_key_input
        results = DBConn().return_ordered_resultset(connection=db_connection, sql=sql)
        if len(results) < 1:
            print("====================No results for Vendor_Key %s Please try again.======================== "
                  % vendor_key_input)
        elif len(results) == 1:
            print("==============================One result for Vendor_Key = %s==============================="
                  % vendor_key_input)
            for key, value in results[len(results)-1].items():
                if key == 'password':
                    if str(value) == 'None':
                        print((key), (' = '), (value))
                    else:
                        print((key), (' = '), (decrypt_one(value, private_key)))
                elif key == 'vendor_key':
                    vendor_key_input = value
                else:
                    print((key), (' = '), (value))
            break
        elif len(results) >= 1:
            dictionary = {}
            print("==================================%s Results for Vendor_key = %s=========================== "
                  % (len(results), vendor_key_input))
            for options in range(len(results)):
                print("=======================================Option %s=======================================" % (
                        options + 1))
                for key, value in results[options].items():
                    if key == 'password':
                        if str(value) == 'None':
                            print((key), (' = '), (value))
                        else:
                            print((key), (' = '), (decrypt_one(value, private_key=private_key)))
                    else:
                        print((key), (' = '), (value))
                    if key == 'vendor_key':
                        dictionary.update({value: (options+1)})
            choice = eval(input("1 to continue, 0 to end "))
            if choice == 0:
                break


def update_vendor_credentials(db_connection, vendor_key_search, results, private_key, public_key):
    if (  (private_key is None) or (public_key is None)):
        print("The Private or Public (or both) Key was not set. It is required for this Option!!\n")
        sys.exit(-1)
    key_list = []
    key_value_original = []
    key_value_new = []
    updated_key_list = []
    print("=======================================Input=======================================")
    for key, value in results[len(results) - 1].items():
        if key == 'vendor_key':
            continue
        key_list.append(str(key))
        key_value_original.append(str(value))
    for key, original, in zip(key_list, key_value_original):
        if key == 'db_update_time':
            continue
        elif key == 'vendor_key':
            continue
        elif key == 'is_active':
            input_string = input("%s? (Current = %s)(1 or 0) " % (key, original))
        elif key == 'password':
            input_string = input("%s? (Current = %s) " % (key, decrypt_one(original, private_key)))
        else:
            input_string = input("%s? (Current = %s) " % (key, original))
        if input_string == '':
            continue
        else:
            key_value_new.append(input_string)
            updated_key_list.append(key)
    input_array = list(zip(updated_key_list, key_value_new))
    sql_inner_string = ''
    counter = 0
    for item in input_array:
        if counter == 0:
            if item[0] == 'password':
                sql_inner_string += "%s = '%s'" % (item[0], Pg.encrypt_string(item[1], public_key))
            elif item[0] == 'is_active':
                sql_inner_string += "%s = %s" % (item[0], item[1])
            else:
                sql_inner_string += "%s = '%s'" % (item[0], item[1])
        else:
            if item[0] == 'password':
                sql_inner_string += " , %s = '%s'" % (item[0], Pg.encrypt_string(item[1], public_key))
            elif item[0] == 'is_active':
                sql_inner_string += " , %s = %s" % (item[0], item[1])
            elif item[1] == 'NULL':
                sql_inner_string += " , %s = %s" % (item[0], item[1])
            else:
                sql_inner_string += " , %s = '%s'" % (item[0], item[1])
        counter += 1
    sqlupdate = """
    UPDATE [Operations].[dbo].[Vendor_Credentials]
SET %s
 WHERE vendor_key = '%s'
    """ % (sql_inner_string, vendor_key_search)
    cursor = db_connection.cursor()
    cursor.execute(sqlupdate)
    cursor.commit()


def find_all_passwords(connection):
    sql = """SELECT [vendor_key] ,[password] FROM [Operations].[dbo].[Vendor_Credentials]"""
    pass_cred = DBConn().return_ordered_resultset(connection=connection, sql=sql)
    return pass_cred


def encrypt_one(string, public_key):
    if (public_key is None):
        print("The Public Key was not set. It is required for this Option!!\n")
        sys.exit(-1)
    encrypted_block = Pg.encrypt_string(string, public_key_path=public_key)
    stripped_string = str(encrypted_block)
    return stripped_string


def decrypt_one(encrypted_string, private_key):
    if (private_key is None):
        print("The Private Key was not set. It is required for this Option!!\n")
        sys.exit(-1)
    body = encrypted_string
    decrypted_block = Pg.decrypt_string(body, private_key_path=private_key)
    return decrypted_block


def encrypt_passwords(db_connection, pass_dict, public_key):
    if (public_key is None):
        print("The Public Key was not set. It is required for this Option!!\n")
        sys.exit(-1)
    for item in pass_dict:
        if str(item["password"]) == 'None':
            continue
        else:
            encrypted_block = Pg.encrypt_string(item["password"], public_key_path=public_key)
            stripped_string = str(encrypted_block)
            item["password"] = stripped_string
            item["vendor_key"] = item["vendor_key"].encode('utf-8')
            sql_update = """
                UPDATE [Operations].[dbo].[Vendor_Credentials]
            SET password = '%s'
             WHERE vendor_key = '%s'""" % (item["password"], item["vendor_key"])
            cursor = db_connection.cursor()
            cursor.execute(sql_update)
            cursor.commit()


def decrypt_passwords(db_connection, pass_dict, private_key):
    if (private_key is None):
        print("The Private Key was not set. It is required for this Option!!\n")
        sys.exit(-1)
    for item in pass_dict:
        if str(item["password"]) == 'None':
            continue
        else:
            body = item["password"]
            decrypted_password = Pg.decrypt_string(body,
                                                   private_key_path=private_key)
            item["password"] = decrypted_password
            item["vendor_key"] = item["vendor_key"].encode('utf-8')
            sql_update = """
                           UPDATE [Operations].[dbo].[Vendor_Credentials]
                       SET password = '%s'
                        WHERE vendor_key = '%s'""" % (item["password"], item["vendor_key"])
            cursor = db_connection.cursor()
            cursor.execute(sql_update)
            cursor.commit()


def main():
    """THIS CODE ASSUMES THAT THE TABLE IS ENCRYPTED AT ALL TIMES"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--action", choices=["add-to-vendor-credentials",
                                             "search",
                                             "decrypt-pgp-message",
                                             "encrypt-pgp-message",
                                             "update-vendor-credentials",
                                             "update-vendor-passwords-to-pgp",
                                             "update-vendor-passwords-to-text"],
                                             required=True)
    
    parser.add_argument('--pubkey', action='store',
                        required=False, default=os.environ.get("PGP_PUBKEY"))
    parser.add_argument('--privkey', action='store',
                        required=False, default=os.environ.get("PGP_PRIVKEY"))
    parser.add_argument('--database', action='store')
       
    args = parser.parse_args()
    db_con = DBConn().get_connection(conn_name=args.database)
    
    if (args.action == "add-to-vendor-credentials") is True:
        """
        When adding to credentials only the public key is needed to encrypt the password upon entry
        Example - python SQLEncryptDecrypt.py --add-to-vendor-credentials --database SAMIR --pubkey PATHTOKEY
        """
        insert_credentials(db_con, args.pubkey)
        print("ADDITION SUCCESSFUL")
    elif (args.action == "update-vendor-credentials") is True:
        """
        When updating credentials both the public and private key is needed to decrypt the password to show the
        current value then re-encrypt when updating.
        Example - python SQLEncryptDecrypt.py --update-vendor-credentials --database SAMIR --pubkey PATHTOKEY 
        --privkey PATHTOKEY
        """
        vendor_key = find_vendor_key(db_con, private_key=args.privkey)
        update_vendor_credentials(db_connection=db_con, vendor_key_search=vendor_key[0], results=vendor_key[1],
                                  private_key=args.privkey, public_key=args.pubkey)
        print("UPDATE SUCCESSFUL")
    elif (args.action == "update-vendor-passwords-to-pgp") :
        """
        when encrypting the whole table only the public key is needed
        Example - python SQLEncryptDecrypt.py --update-vendor-passwords-to-pgp --database SAMIR --pubkey PATHTOKEY
        """
        gateway = eval(input("PLEASE ENCRYPT TO YOUR OWN RISK - THE PASSWORDS MAY ALREADY BE ENCRYPTED"
                        " Press 1 to continue, or 0 to cancel "))
        if gateway == 0:
            print('Terminating')
            sys.exit()
        passwords = find_all_passwords(db_con)
        if (args.pubkey is None):
            print("Dude - Public Key is Not Set. For Decryption to work, Public key needs to be set! \n")
            print("We will exit!  \n")
            sys.exit(-1)
        encrypt_passwords(db_con, pass_dict=passwords, public_key=args.pubkey)
        print("ENCRYPTION SUCCESSFUL")
    elif ( args.action == "update-vendor-passwords-to-text") :
        """
        when decrypting the whole table only the private key is needed
        Example - python SQLEncryptDecrypt.py --update-vendor-passwords-to-text --database SAMIR --privkey PATHTOKEY
        """
        gateway = eval(input("PLEASE DECRYPT TO YOUR OWN RISK - THE PASSWORDS MAY ALREADY BE DECRYPTED "
                            "Press 1 to continue, or 0 to cancel  "))
        if gateway == 0:
            print('Terminating')
            sys.exit()
        passwords = find_all_passwords(db_con)
        decrypt_passwords(db_con, passwords, private_key=args.privkey)
        print("DECRYPTION SUCCESSFUL")
    elif (args.action ==  "search") :
        """
        When searching the database the private key is needed to decrypt the passwords
        Example - python SQLEncryptDecrypt.py --search --database SAMIR --privkey PATHTOKEY
        """
        search(db_con, args.privkey)
        print("Complete")
    elif (args.action =="encrypt-pgp-message"):
        vendor_key_input = input("What message would you like to ENCRYPT? ")
        x =  Pg.encrypt_string(string=vendor_key_input, public_key_path=args.pubkey)
        print("---Encrypted message---\n")
        print("%s" % x)
        print("---Complete---\n")
    elif (args.action == "decrypt-pgp-message"):
        print ("What message would you like to DECRYPT (hit Control-Z to end. Note - newlines will be stripped)? \n")
        vkey = sys.stdin.readlines()
        print("...decrypting.")
        vendor_key_input = ''.join(vkey)
        #vendor_key_input = vendor_key_input.replace('\n','').replace('\r','')
        x =  Pg.decrypt_string(encrypted_string=vendor_key_input, private_key_path=args.privkey)
        print("---Decrypted message---")
        print("%s" % x)
        print("---Complete---\n")
        

#-----------------------------------------------------------

if __name__ == "__main__":
    main()
