import logging
import pysftp
import ftplib
import os
import fnmatch  # needed due to limitations on pysftp/paramiko
from datetime import datetime as dtt
import time
import socket # 2018 thing


log = logging.getLogger(__name__)
logging.getLogger("paramiko").setLevel(logging.WARNING)


class FTP():

    def __init__(self, server, username, password, method_type, port=None, debug=False):
        self.server = server
        self.username = username
        self.password = password
        self.type = method_type
        self.port = port
        self.connection = None
        socket.setdefaulttimeout(20) # 20 second time out?
        if (self.type == 'SFTP'):
            self.__do_sftp_connection(debug)
        elif (self.type == 'FTP'):
            self.__do_ftp_connection(debug)
        elif (self.type == 'COPY'):
            pass
        elif (self.type == 'FTPS'):
            self.__do_ftps_connection(debug)
        else:
            raise ValueError(self.type + " is an Unknown Type for our module!")

    # Private. Try to to do internally
    def __do_sftp_connection(self, debug=False):
        if (self.connection is None):
            if debug:
                logging.getLogger("paramiko").setLevel(logging.DEBUG)
                
            if (self.port is None):
                self.connection = pysftp.Connection(host=self.server,
                                                    username=self.username,
                                                    password=self.password)
            else:
                self.connection = pysftp.Connection(host=self.server,
                                                    username=self.username,
                                                    password=self.password,
                                                    port=self.port)

        else:
            log.warning("Why are you calling me? If we have an active SFTP Connection")

    # Private. Try to do it internally
    def __do_ftps_connection(self, debug=False):
        if (self.connection is None):
            """
            self.connection = ftplib.FTP_TLS(
                self.server, self.username, self.password, self.port)
            """
            self.connection = ftplib.FTP_TLS() 
            if (debug):
                self.connection.set_debuglevel(2)
            self.connection.connect(host=self.server, port=self.port) 
            log.debug("...connected to FTPS server. Using Login Credentials.")
            self.connection.login(user=self.username, passwd=self.password) 
            log.debug("User/Password authorized. Ensuring Encryption.")
            self.connection.prot_p()
            log.info("...connected to %s ALA FTPS", self.server)
        else:
            log.warning("Why are you calling me? If we have an active FTPS Connection")

    # Private. Try to do it internally
    def __do_ftp_connection(self, debug=False):
        if (self.connection is None):
            
         
            if (self.port is None):
                self.connection = ftplib.FTP(self.server)
            else:
                self.connection = ftplib.FTP(self.server, self.port)
            if (debug):
                self.connection.set_debuglevel(2)
            
            self.connection.login(self.username, self.password)
            log.info("...connected to %s", self.server)
        else:
            log.warning("Why are you calling me? If we have an active FTP Connection")

    # Public - get the file.
    def get_file(self, server_location, local_location):
        '''
        We cant be everything for everybody.
        local_location could be a directory+filename, or maybe not
        don't want to add too much logic

        basedir = os.path.dirname(local_location)
        if (not os.path.exists(basedir)):
            log.info("%s does not exists locally. Create!", basedir)
            os.makedirs(basedir)
            log.info("...Directory created !")
        '''

        if self.type == 'SFTP':
            sftp = self.connection
            # Jan 2016 - we are going to assume for SFTP, unix style paths. replace "\" with "/"
            # While most SFTP servers are lenient on re-interpreting the paths,
            # Bloomberg is not :(
            server_location = server_location.replace('\\', '/')
            sftp.get(server_location, local_location)
            if sftp.exists(local_location):
                log.info("Extracted file=%s" % local_location)

        elif self.type in('FTP', 'FTPS'):
            # is the local location a directory?
            if (os.path.isdir(local_location)):
                log.info("Local Location is a directory. Concat File")
                local_location = os.path.join(local_location, os.path.basename(
                    server_location))  # basename is risky...but lets roll
                # print "LOCAL LOCATION:", local_location, " AND SERVER: :" , server_location
            # print "Dirname--" + os.path.dirname(server_location)
            # self.connection.cwd(os.path.dirname(server_location))
            f = open(local_location, 'wb')
            self.connection.retrbinary(
                'RETR %s' % server_location, f.write)
            f.close()
        return os.path.getsize(local_location)
    # Public - put the file

    def put_file(self, local_location, server_location=None, do_sizecheck_failure=True):
        ''''
        As with get file, the remote location should be indicative
        of the full path. So if you're renaming stuff...it better be passed in that way

        Return size uploaded.

        Jan 5, 2016 - We have cases where the remote vendor does not allow a size check as the command is not implemented!
        if we ignore the size check, we will return a -1 in case of failure.
        ...for now, only do this on the FTP/FTPS option

        April 2017 - ok...ignore size check for SFTP options.
        
        '''
        if self.type == 'SFTP':
            sftp = self.connection
            attributes = None
            confirm = do_sizecheck_failure
            if (server_location is None):
                attributes = sftp.put(local_location, confirm=confirm)
            else:
                # Jan 2016 - we are going to assume for SFTP, unix style paths. replace "\" with "/"
                # While most SFTP servers are lenient on re-interpreting the
                # paths, Bloomberg is not :(
                server_location = server_location.replace('\\', '/')
                attributes = sftp.put(
                    localpath=local_location, remotepath=server_location, 
                    confirm=confirm)
                if (confirm and sftp.exists(server_location)):
                    logging.info("Uploaded file=%s" % local_location)
                                                      
            if confirm:                                    
                return attributes.st_size
            else:
                return -1
        elif (self.type in 'FTP', 'FTPS'):
            # is the local location a directory?
            attributes = []
            mysize = -1
            if (server_location is None):
                log.info("Uploading to remote dir. get filename and concat")
                f = open(local_location, "rb")
                self.connection.storbinary('STOR %s' % os.path.basename(
                    local_location), f)
                # self.connection.retrlines("LIST " + os.path.basename(local_location), attributes.append)
                f.close()
                try:
                    mysize = self.connection.size(
                        os.path.basename(local_location))
                except Exception as e:
                    log.error(
                        "We received an error when retrieving size! %s", str(e))
                    if (do_sizecheck_failure):
                        raise e
            else:
                f = open(local_location, "rb")
                self.connection.storbinary(
                    'STOR %s' % server_location, f)
                # self.connection.retrlines("LIST %s" % server_location, attributes.append)
                f.close()
                try:
                    mysize = self.connection.size(server_location)
                except Exception as e:
                    log.error(
                        "We received an error when retrieving size! %s", str(e))
                    if (do_sizecheck_failure):
                        raise e
            # Testing
            """
            10/12/2015 - Use the size param. If it works, great, if not..eh
            Note - the reason for this change is the FTP server for fascet; they do not give all the
            attributes on a stat

            print "Mysize = ", mysize
            values = attributes[0].split()
            if (len(values) == 9):
                return int(values[4].strip())
            else:
                log.warn("Something is not right. File attribute :%s",str(values))
                return -1
            """
            return mysize

    # ---------------------added Dec 1 2015 for keep alive test --------------

    def keep_alive(self):
        ''' Keep Alive logic. Server side may close a connection. Do PWD here.
        if there's an exception....reconnect
        '''
        if (self.type == 'COPY'):
            return

        try:
            wd = None
            if (self.type == 'SFTP'):
                wd = self.connection.pwd
            else:
                wd = self.connection.pwd()
            log.debug("Working directory is %s", wd)
        except Exception as e:
            log.warning("Error on type %s when doing pwd -  :%s",
                     self.type, str(e))
            log.warning("Attempt to reconnect!")
            self.connection = None
            if (self.type == 'SFTP'):
                self.__do_sftp_connection()
            elif (self.type == 'FTP'):
                self.__do_ftp_connection()
            elif (self.type == 'FTPS'):
                self.__do_ftps_connection()

    # ----------------------added Nov 13 2015 --------------------------------
    def delete_file(self, filename, remote_or_local):
        log.info("We have been asked to delete %s on the %s host",
                 filename, remote_or_local)

        if (remote_or_local in ("Outgoing", "Copy")):
            os.remove(filename)
        elif (remote_or_local == "Incoming"):
            if self.type == 'SFTP':
                # Jan 2016 - we are going to assume for SFTP, unix style paths. replace "\" with "/"
                # While most SFTP servers are lenient on re-interpreting the
                # paths, Bloomberg is not :(
                filename = filename.replace('\\', '/')
                self.connection.remove(filename)
            elif self.type in('FTP', 'FTPS'):
                self.connection.delete(filename)
            else:
                log.fatal("something is screwey. we should not be here")
                raise Exception(
                    " Encountered diff method type " + self.type + "on delete!")
        else:
            log.fatal("eh? what is %s. Remember case sensitivity!",
                      remote_or_local)
            raise Exception(
                " Encountered value %s for remote or local", remote_or_local)

    # ------------------------------------------
    # Public - get the timestamps and size.
    def get_timestamps_and_size(self, file_pattern, server_directory=None):
        log.debug("Checking for file_pattern %s ", file_pattern)
        files_to_return = {}
        if (self.type == 'SFTP'):
            remote = "."
            if (server_directory is not None):
                remote = server_directory
            files = []
            try:
                files = self.connection.listdir(remotepath=remote)
            except IOError as e:
                # Jan 5 2016 - I do this with mixed reservations, but as long as we are aware of things
                # and testing - we should be ok. An IOError can occur if the remote path does not exist.
                # For the most part, a remote path should be fixed, but there's always a possibility
                # a directory is based on date or month, and it may not be there yet. With that
                # stated, log the error and return an empty w
                log.error("SFTP - Whoa. IOError. %s", str(e))
                log.info(
                    "...as this could be the remote dir is not there YET, we will return an empty dict")
                return files_to_return
            except Exception as e:
                log.error("Dude - some other error besides IOErrror: %s", str(e))
                raise e

            # does the file match our pattern?
            for x in files:
                if fnmatch.fnmatch(x, file_pattern):
                    log.debug("%s matches file pattern %s", x, file_pattern)
                    # Jan 2016 - we are going to assume for SFTP, unix style paths. replace "\" with "/"
                    # While most SFTP servers are lenient on re-interpreting
                    # the paths, Bloomberg is not :(
                    remote = remote.replace('\\', '/')
                    fname = remote + "/" + x
                    attributes = self.connection.stat(remotepath=fname)
                    timestamp = str(dtt.strptime(time.ctime(
                        attributes.st_mtime), "%a %b %d %H:%M:%S %Y"))
                    struct = {}
                    struct['timestamp'] = timestamp
                    struct['byte_size'] = attributes.st_size
                    if (remote != "."):
                        files_to_return[fname] = struct
                    else:
                        files_to_return[x] = struct
        elif (self.type in ('FTP', 'FTPS')):
            listing = []
            pwd = None
            if (server_directory is not None):
                pwd = self.connection.pwd()
                self.connection.cwd(server_directory)
            try:
                self.connection.retrlines(
                    "LIST " + file_pattern, listing.append)
            except ftplib.error_perm as e:
                log.error(
                    "FTP - We received an error while attempting to LIST patterns!")
                log.error("%s", str(e))
                log.info(
                    "Assuming 550. for now, return empty. Assuming file is missing")
                return files_to_return
            except Exception as e:
                log.error(
                    "Dude - some other error besides error_perm: %s", str(e))
                raise e

            for element in listing:
                bytes_src = -1
                arrayItems = element.split()
                log.debug("We have %d items", len(arrayItems))
                if len(arrayItems) == 9:    # possibility we get non-file listing
                    curfile = arrayItems[8].strip()
                    bytes_src = int(arrayItems[4].strip())
                elif len(arrayItems) == 4:
                    curfile = arrayItems[3].strip()
                    bytes_src = int(arrayItems[2].strip())
                else:
                    log.warning(
                        "Raiserror  - this FTP server does not show a standard listing!")
                    log.warning("%s", element)
                    raise Exception(
                        "FTP Server does not have a Standard Listing!")

                timestamp = self.connection.sendcmd('MDTM ' + curfile)
                log.debug("Timestamp from command: %s", timestamp)
                timestamp = timestamp.split()[1]
                timestamp = timestamp[0:4] + "-" + timestamp[4:6] + "-" + timestamp[
                    6:8] + " " + timestamp[8:10] + ":" + timestamp[10:12] + ":" + timestamp[12:14]
                struct = {}
                struct['timestamp'] = timestamp
                struct['byte_size'] = bytes_src
                if (server_directory is not None):
                    curfile = server_directory + "/" + curfile
                files_to_return[curfile] = struct

            if (pwd is not None):
                self.connection.cwd(pwd)

        log.debug("We have %d items that matched !", len(files_to_return))
        return files_to_return


if __name__ == "__main__":

    ftp_obj = FTP('mfd.ftp.seic.com', 'IMS_SELECT_EQUITY',
                  'XTBOLluI4YUfvE', 'SFTP')
    ftp_obj.get_file(
        '/outgoing/SEG Security Prices 8.13.15.csv', './Prices.csv')
    '''
    ftp_obj = FTP('54.86.78.12','APHFTP','zSMK7g','FTPS',990)
    ftp_obj.get_file('*bak','C:\temp')
    '''
