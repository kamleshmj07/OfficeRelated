import SEG.utils.PGpy as pgp
import os
import argparse
import logging.config
import SEG.utils.SEGUtils as utils
import datetime
from SEG.utils.SEGUtils import get_db_conn_name, get_log_config


'''Gets latest filename in specified path, Decrypts a file and moves it to a specified location in the fileshare system
To be used for jams jobs instead of encryptor because that requires user input.  You can specify your own regex
'''

def decrypt_and_move(target_path, file_pattern, new_filename, destination_path, overwrite=False):
    target_path = normalize_path(target_path)
    destination_path = normalize_path(destination_path)
    latest_file = utils.find_latest_file_in_dir(target_path, file_pattern)
    output_file = os.path.join(destination_path, new_filename)
    print('Decrypt and move is saved as {}'.format(overwrite))
    decrypted_file = pgp.decrypt_file(latest_file, output_file, overwrite=overwrite)
    print(decrypted_file)


def normalize_path(path):
    '''ADDS trailing slash if the provided path is missing it'''
    return os.path.join(path, '')


if __name__ == '__main__':
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument("--log_config_file",
                            help="Your log config file")
    arg_parser.add_argument("--target_path", help="Directory your file is in")

    arg_parser.add_argument("--file_pattern", help="String of file name to do matching logic on",
                            )

    arg_parser.add_argument("--new_filename",
                            help="Directory you want to write decrypted file to")


    arg_parser.add_argument("--destination_path",
                            help="Directory you want to write decrypted file to")

    arg_parser.add_argument('--overwrite',  action='store_true', help="Overwrite file if it exists in the target directory")

    options = arg_parser.parse_args()
    logging.config.fileConfig(get_log_config(options.log_config_file),
                              defaults=({'filename_append': 'decrypt_and_move',
                                         'run_id': datetime.datetime.now().strftime('%Y-%m-%d')}))
    log = logging.getLogger(__name__)

    log.info("Starting log for Decrypt and move")

    filename = decrypt_and_move(target_path=options.target_path, file_pattern=options.file_pattern, new_filename=options.new_filename, destination_path=options.destination_path,
                                overwrite=options.overwrite)
