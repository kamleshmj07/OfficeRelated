import logging
import os
from SEG.utils.SEGUtils import get_script_name_no_ext,get_app_log_dir

class SEGLoggingHandler(logging.FileHandler):
    """Handling class for the logging file for the logging module"""
    def __init__(self,logfile_append,mode='a'):
        log_dir = get_app_log_dir()
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
            
        log_name = get_script_name_no_ext() + '_' + logfile_append + '.log'
        super(SEGLoggingHandler,self).__init__(os.path.join(log_dir , log_name))
        # super(SEGLoggingHandler,self).__init__(log_dir + log_name)
