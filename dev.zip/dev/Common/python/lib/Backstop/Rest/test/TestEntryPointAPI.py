'''
Created on Nov 25, 2016

Unit test for the People API.

We're basically testing the REST Calls, and the expected JSON Structure from Backstop.

If the calls or json structure is not what is expected...FAIL!

@author: spatel
'''


import unittest
from Backstop.Rest.EntryPoint import EntryPoint
import mock
import logging
from jsonschema import validate
# from schema import Schema, And, Use, Optional
#from voluptuous import Schema

logging.basicConfig(format='%(asctime)s|%(module)s|%(levelname)s|%(lineno)d|%(message)s')
logger = logging.getLogger()
logger.level = logging.INFO

class testPeopleAPI(unittest.TestCase):

    db_con = None
    bs_peeps = None
    
    def setUp(self):
        # Do we need mock? Eh...keep it for now.
        self.db_con = mock.Mock()
        self.db_con.cursor = mock.Mock()
        self.bs_peeps = EntryPoint()
        
        
    def tearDown(self):
        # Nothing really.
        pass
        
    #-----------------------------------------------------------------------------------
    def testGetPeople(self):

        json_scheme  =  {"type":"array",
                         "items":{
                        "title": "Backstop Person",
                         "type":"object",
                         "properties":
                            {
                             'entityType': {"type" : "string"},
                            'name':{"type" : "string"},
                            'restUrl': {"type" : "string"},
                            'id': {"type" : "number"},
                            'type': {"type" : "string"}  
                            },
                         "required": ["name", "restUrl"]
                             }}
        peep_struct = self.bs_peeps.get_all_people()
        org_struct = self.bs_peeps.get_all_organizations()
        
        x = False
        y = False
        try:
            x = validate(peep_struct,json_scheme)
            y =  validate(org_struct, json_scheme)
        except Exception as e:
            logger.fatal("Error Validating BS People struct : %s",  str(e) )

        self.assertTrue((x is None), " Does Backstop People Struct match w Schema?")
        self.assertTrue((y is None), " Does Backstop Org Struct match w Schema?")
       
    #  ---------------------------------------------------------------
    
    def testGetUsers(self):
        '''
        Validate:
        {u'username': u'atwiss', u'lastName': u'Twiss', u'emailAddress': u'atwiss@selectequity.com', u'id': 2583387, u'firstName': u'Alison'}
        '''
        json_scheme  =  {"type":"array",
                         "items":{
                        "title": "Backstop User",
                         "type":"object",
                         "properties":
                            {
                             'username': {"type" : "string"},
                            'lastName':{"type" : "string"},
                            'emailAddress': {"type" : "string"},
                            'id': {"type" : "number"},
                            'firstName': {"type" : "string"}  
                            },
                         "required": ["username","lastName","emailAddress"]
                             }}
        
        user_struct = self.bs_peeps.get_backstop_users()
       
        x = False
        
        try:
            x  = validate(user_struct,json_scheme)
        except Exception as e:
            logger.fatal("Error Validating user struct : %s",  str(e) )
            
        
        self.assertTrue((x is None), " Does Backstop User Struct match w Schema?")
    # -----------------------------------------------------------------------
    
 
if __name__ == "__main__":
    unittest.main()