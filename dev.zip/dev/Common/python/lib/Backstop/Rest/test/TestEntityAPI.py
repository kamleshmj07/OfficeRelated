'''
Created on Dec 14, 2016

Unit test for the Entity API.

We're basically testing the REST Calls, and the expected JSON Structure from Backstop.

If the calls or json structure is not what is expected...FAIL!

@author: spatel
'''

import unittest
from Backstop.Rest.Entity import Organization, Person
import logging

logging.basicConfig(format='%(asctime)s|%(module)s|%(levelname)s|%(lineno)d|%(message)s')
logger = logging.getLogger()
logger.level = logging.INFO


class testEntityAPI(unittest.TestCase):

    def setUp(self):
        # Do we need mock? Eh...keep it for now.
        self.org_url = "https://selectequity.backstopsolutions.com/backstop/rest/parties/organizations/301542293"
        self.person_url = "https://selectequity.backstopsolutions.com/backstop/rest/parties/people/344272533"

    def tearDown(self):
        # Nothing really.
        pass

    # -----------------------------------------------------------------------------------
    def testOrgStructure(self):
        expected_keys = {'relationships', 'website', 'permissionTag', 'nonPrimaryLocations', 'name',
                         'lastContactDate', 'employees', 'entityType', 'otherId', 'id', 'matchingDomain',
                         'restUrl', 'primaryContact', 'representative', 'legalName', 'primaryLocation', 'type',
                         'email', 'categories', 'description'}
        org = Organization(self.org_url)
        actual_keys = set(org.json_org.keys())
        self.assertEqual(expected_keys, actual_keys, msg="The structure of the api call was not what was expected."
                                                         "The api had " + ', '.join(actual_keys - expected_keys) +
                                                         " That are not included in our expected structure.  Please investigate")

    #  ---------------------------------------------------------------

    def testPeopleStructure(self):
        expected_keys = {'permissionTag', 'suffix', 'entityType', 'prefix', 'primaryPhone', 'gender', 'id',
                         'description', 'relationships', 'nonPrimaryLocations', 'title', 'middleName',
                         'companyName', 'pronunciation', 'type', 'email', 'website', 'mobilePhone',
                         'lastContactDate', 'company', 'restUrl', 'representative', 'primaryLocation',
                         'categories', 'otherId', 'name', 'firstName', 'nickName', 'descriptiveName', 'lastName'}
        person = Person(self.person_url)
        actual_keys = set(person.json_person.keys())
        self.assertEqual(expected_keys, actual_keys, msg="The structure of the api call was not what was expected."
                                                         "The api had " + ', '.join(actual_keys - expected_keys) +
                                                         " That are not included in our expected structure.  Please investigate")

    # -----------------------------------------------------------------------


if __name__ == "__main__":
    unittest.main()
