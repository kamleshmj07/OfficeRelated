import logging
import requests


from Backstop.Rest import BSTOP_ID, BSTOP_PWD
import SEG.utils.PGpy as Pg
import os

class EntryPoint(object):
    
    base_url =  "https://selectequity.backstopsolutions.com/backstop/rest/"
    
    urls={}
    urls['people']='parties/people'
    urls['categories']='parties/categories'
    urls['userlist']='users'
    urls['organizations'] = 'parties/organizations'
    
    def __init__(self):
        self.nbr_of_calls = 0
    
    def __make_the_call(self,key):
        self.nbr_of_calls += 1
        log = logging.getLogger(__name__)
        url = self.base_url + self.urls[key]
        log.debug("calling %s", url)
        pwd = Pg.decrypt_string(encrypted_string=BSTOP_PWD, 
                                private_key_path=os.environ.get("PGP_PRIVKEY"))
        call = requests.get(url,auth=(BSTOP_ID, pwd ))
        if (call.status_code != 200):
            log.warn("Status code %d", call.status_code)
            log.warn("...return error")
            raise ValueError (' Failed calling ' + url)
        return call.json()
    
    def get_all_organizations(self):
        return self.__make_the_call('organizations')
    
    def get_all_people(self):
        return self.__make_the_call('people')

    def get_backstop_users(self):
        return self.__make_the_call("userlist")
    
    def get_backstop_categories(self):
        return self.__make_the_call("categories")

    def get_nbr_of_rest_calls_made(self):
        return self.nbr_of_calls
    
    
if __name__ == "__main__":
    x = EntryPoint()
    js = x.get_all_people()
    print(js)
    
        