'''
Created on Dec 14, 2016

@author: spatel
'''

import logging
import requests
import SEG.utils.PGpy as Pg
import os

from Backstop.Rest import BSTOP_ID, BSTOP_PWD


class Organization(object):
    
    json_org = None
    
    def __init__(self, bs_url):
        log = logging.getLogger(__name__)
        pwd = Pg.decrypt_string(encrypted_string=BSTOP_PWD, 
                                private_key_path=os.environ.get("PGP_PRIVKEY"))
        call = requests.get(bs_url,auth=(BSTOP_ID, pwd))
        if (call.status_code != 200):
            log.warn("Status code %d", call.status_code)
            log.warn("...return error")
            raise ValueError (' Failed calling ' + bs_url)
        self.json_org = call.json()
    
    def get_entity_type(self):
        return self.json_org["entityType"]
    
    def get_bs_id(self):
        return self.json_org["id"]
    
    def get_employees(self):
        return self.json_org["employees"]
        
    def get_categories(self):
        return self.json_org["categories"]
    
    def get_description(self):
        return self.json_org["description"] or ""
    
    def get_primary_address(self):
        return self.json_org["primaryLocation"]["address"] or ""
    
    def get_primary_city(self):
        return self.json_org["primaryLocation"]["city"] or ""
    
    def get_primary_state(self):
        return self.json_org["primaryLocation"]["state"] or ""
    
    def get_primary_zipcode(self):
        return self.json_org["primaryLocation"]["postalCode"] or ""
    
    def get_primary_countryname(self):
        return self.json_org["primaryLocation"]["countryName"] or ""
    
    def get_primary_phone(self):
        return self.json_org["primaryLocation"]["phone"] or ""
        
    def get_org_website(self):
        return self.json_org["website"] or ""


class Person(object):
    json_person = None
    
    def __init__(self, bs_url):
        log = logging.getLogger(__name__)
        pwd = Pg.decrypt_string(encrypted_string=BSTOP_PWD, 
                                private_key_path=os.environ.get("PGP_PRIVKEY"))
        call = requests.get(bs_url,auth=(BSTOP_ID, pwd))
        if (call.status_code != 200):
            log.warn("Status code %d", call.status_code)
            log.warn("...return error")
            raise ValueError (' Failed calling ' + bs_url)
        self.json_person = call.json()
        
        
    def get_entity_type(self):
        return self.json_person["entityType"]
        
    def get_bs_id(self):
        return self.json_person["id"]
    
    def get_categories(self):
        return self.json_person["categories"]
    
    def get_description(self):
        return self.json_org["description"] or ""
    
    def get_primary_phone(self):
        return self.json_person["primaryPhone"] or ""
    
    def get_primary_address(self):
        return self.json_person["primaryLocation"]["address"] or ""
    
    def get_primary_city(self):
        return self.json_person["primaryLocation"]["city"] or ""
    
    def get_primary_state(self):
        return self.json_person["primaryLocation"]["state"] or ""
    
    def get_primary_zipcode(self):
        return self.json_person["primaryLocation"]["postalCode"] or ""
    
    def get_primary_countryname(self):
        return self.json_person["primaryLocation"]["countryName"] or ""
        
    def get_email_addresses(self):
        # should I comma separate?
        return self.json_person["email"] or []
    
    def get_title(self):
        return self.json_person["title"] or ""
    
        
        