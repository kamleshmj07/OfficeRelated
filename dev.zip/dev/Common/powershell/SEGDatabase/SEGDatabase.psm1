function Get-SEGDatabaseConnection {
    param (
        [string]$Hostname,
        [string]$Database,
        [string]$username,
        [string]$password
    )
    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = "Data Source=$Hostname;Initial Catalog=$Database;User ID=$username;Password=$password"

    $connection
}

function Get-SEGDatabaseData {
    param (
        [System.Data.SqlClient.SqlConnection]$connection,
        [string]$query 
    )

    $command = $connection.CreateCommand()
    $command.CommandText = $query
    $adapter = New-Object System.Data.SqlClient.SqlDataAdapter $command
    $dataset = New-Object System.Data.DataSet
    $adapter.Fill($dataset)
    $dataset.Tables[0]
}
