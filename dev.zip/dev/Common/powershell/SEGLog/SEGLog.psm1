Function LogWrite 
{
    Param ([string]$logString, [string]$logFile)
    Out-String -inputObject $logString -stream
    Add-Content $logFile $logString
}

