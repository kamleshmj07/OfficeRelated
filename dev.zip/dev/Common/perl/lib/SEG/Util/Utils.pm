#
# $Id: $
# $Source: $
#
package SEG::Util::Utils;

use strict;


#
# Trims the leading and trailing white space in the variable reference passed
# in.
#
sub trim {
	my $s_ref = shift;

	$$s_ref =~ s/^\s+//g;
	$$s_ref =~ s/\s+$//g;
}

1;
