#
# $Id: $
# $Source: $
#
package SEG::Util::Properties;

use strict;
use Config::Properties;


#
# Reads a properties file and returns a reference to the
# Config::Properties object.
#
sub read_properties_file {
	my $filename = shift;

	my $prop_fh = new FileHandle($filename, 'r')
		|| die "Could not open properties filename '$filename' for reading: $!";

	my $properties = Config::Properties->new();
	$properties->load($prop_fh);

	return $properties;
}

1;
