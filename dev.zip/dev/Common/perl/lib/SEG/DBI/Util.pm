#
# $Id: $
# $Source: $
#

package SEG::DBI::Util;

use strict;

use Log::Log4perl qw(get_logger);
use DBI;

# SEG libs
use SEG::Util::Properties;


#
# Simple wrapper for DBI::connect method which pulls database connection
# parameters from a properties file
# Requires Log4Perl logger to have been already initialized in the client program.
# Returns database handle on success.
#
sub connect {
	my $properties = shift;

	my $log = get_logger();

	my $hostname = $properties->getProperty('db.hostname');
	my $mssql_driver = $properties->getProperty('db.driver');
	my $database_name = $properties->getProperty('db.database_name');
	my $username = $properties->getProperty('db.username');
	my $password = $properties->getProperty('db.password');

	my $dbh = DBI->connect("dbi:ODBC:"
		. "DRIVER=$mssql_driver;"
		. "Server=$hostname;"
		. "LogonUser=user;"
		. "LogonAuth=password;"
		. "Trusted_Connection=No;"
		. "MARS_Connection=Yes;",
		$username,
		$password) or $log->logconfess("Could not connect to database '$hostname': $DBI::errstr");

	$dbh->{'RaiseError'} = 1;
	$dbh->{'AutoCommit'} = 0;

	$dbh->do("use $database_name");

	$log->info("connected to mssql db; host=$hostname, database=$database_name, username=$username");

	return $dbh;
}

1;
