#
# $Id: $
# $Source: $
#
package SEG::Tamale::RestAPI::DepositResearch;

use strict;
use FileHandle;
use Config::Properties;
use XML::Simple;
use HTTP::Request;


#
# Creates and returns LWP::UserAgent object. Also enables HTTP Keep alives for
# faster request servicing.
#
sub create_lwp_user_agent_obj {
	my $properties = shift; # Config::Properies properties object

	use LWP;

	my $hostname = $properties->getProperty("tamale.hostname");
	my $port = $properties->getProperty("tamale.port");
	my $username = $properties->getProperty("tamale.username");
	my $password = $properties->getProperty("tamale.password");
	my $tamale_authentication_realm = 'Jython';

	my $ua = LWP::UserAgent->new;
	$ua->credentials(
		"$hostname:$port",
		$tamale_authentication_realm,
		$username => $password
	);

	use LWP::ConnCache;

	# enable use of HTTP keep alive
	$ua->conn_cache(LWP::ConnCache->new);

	return $ua;
}


#
# DepositDownloads the research for an entity from Tamale using the REST API and
#
sub deposit_research {
	my $properties = shift; # Config::Properies properties object
	my $ua = shift; # LWP::UserAgent
	my $entities = shift;
	my $subject= shift;
	my $body= shift;
	my $attachment_filename = shift;
    my $note_type = shift;

	# create a useragent for this session if one wasn't explicitly given
	$ua = create_lwp_user_agent_obj($properties) unless $ua;


	use URI::Escape;

	my $hostname = $properties->getProperty("tamale.hostname");
	my $port = $properties->getProperty("tamale.port");
	my $username = $properties->getProperty("tamale.username");
	my $password = $properties->getProperty("tamale.password");

    my $webprefix = $properties->getProperty("tamale.webprefix");
    if(not defined $webprefix) { 
        $webprefix = 'http';
    }

	my %tamale_url_params = (
		entities => uri_escape($entities),
		subject => uri_escape($subject),
        entrytype => uri_escape($note_type)
	);

	my $tamale_url_script = "restapi/2.0/entry/";


	my $url = "$webprefix://$username:$password\@$hostname:$port/${tamale_url_script}?";
	$url .= join('&', map { $_ . '=' . $tamale_url_params{$_} } keys %tamale_url_params);

    #Get lines break that post can handle
    $body =~ s/\n/\n<br>/g; 
  
	my $response = $ua->post($url, , Content_Type => 'form-data',
                                   Content => [ body => $body,
                                                attachment => [$attachment_filename] ] );
                           

	die ("Error: POST $url: " . $response->status_line)
		unless $response->is_success;

	return $response->content();
}

1;
