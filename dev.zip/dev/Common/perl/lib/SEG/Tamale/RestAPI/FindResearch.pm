#
# $Id: $
# $Source: $
#
package SEG::Tamale::RestAPI::FindResearch;

use strict;
use FileHandle;
use Config::Properties;
use XML::Simple;
use Data::Dump qw(dump);


#
# Creates and returns LWP::UserAgent object. Also enables HTTP Keep alives for
# faster request servicing.
#
sub create_lwp_user_agent_obj {
	my $properties = shift; # Config::Properies properties object

	use LWP;

	my $hostname = $properties->getProperty("tamale.hostname");
	my $port = $properties->getProperty("tamale.port");
	my $username = $properties->getProperty("tamale.username");
	my $password = $properties->getProperty("tamale.password");
	my $tamale_authentication_realm = 'Jython';

	my $ua = LWP::UserAgent->new;
	$ua->credentials(
		"$hostname:$port",
		$tamale_authentication_realm,
		$username => $password
	);

	use LWP::ConnCache;

	# enable use of HTTP keep alive
	$ua->conn_cache(LWP::ConnCache->new);

	return $ua;
}


#
# Parses the <Research> xml data and returns Research in an
# array of hashes created by XML::Simple.
#
sub get_research_from_xml {
	my $xml_src = shift; # open file handle to the XML file OR xml string

	my $xs = XML::Simple->new(ForceArray => [qw(Research)]);
	my $xml_hash = $xs->XMLin($xml_src, SuppressEmpty => "");

    return [] if($xml_hash eq "");

	my $research = $xml_hash->{Entry} || [];

    #WIth only one element you get a hash ref instead of an array ref
    if(ref($research) ne "ARRAY") {
        my @Research_temp = ($research);
        $research = \@Research_temp; 
    }

	return $research;
}

#
# Downloads the Research for an entity from Tamale using the REST API and
# returns the xml content as a string.
#
sub download_research_xml {
	my $properties = shift; # Config::Properies properties object
	my $ua = shift; # LWP::UserAgent
	my $entity_id = shift;
    my $entry_type = shift;
	my $column = shift;


	# http://seg-ct-tamaletest2.seg.local:8080/refresh/Jython?service=FindResearch&username=localIT&entity=WMT&outputFormat=xml&relTypes=all
	use URI::Escape;

	my $hostname = $properties->getProperty("tamale.hostname");
	my $port = $properties->getProperty("tamale.port");
	my $username = $properties->getProperty("tamale.username");
    my $webprefix = $properties->getProperty("tamale.webprefix");
    if(not defined $webprefix) { 
        $webprefix = 'http';
    }

	my $tamale_service = 'FindResearch';
	my %tamale_url_params = (
		username => $username,
		entities => uri_escape($entity_id),
        entryTypes => uri_escape($entry_type),
		columns => uri_escape($column),
		outputFormat => 'xml',
	);

	my $tamale_url_script = "web/RestAPI/v1/$tamale_service";

	my $url = "$webprefix://$hostname:$port/${tamale_url_script}?";
	$url .= join('&', map { $_ . '=' . $tamale_url_params{$_} } keys %tamale_url_params);

	# create a useragent for this session if one wasn't explicitly given
	$ua = create_lwp_user_agent_obj($properties) unless $ua;

    print "$url\n";

	my $response = $ua->get($url);
	die ("Error: GET $url: " . $response->status_line)
		unless $response->is_success;

	return $response->content();
}

#
# Downloads the research from Tamale using the REST API and writes the xml
# content to a file.
#
sub download_research_xml_to_file {
	my $properties = shift; # Config::Properies properties object
	my $research_filename = shift; # file where the output will be written to
	my $ua = shift; # LWP::UserAgent
	my $entity_id = shift;
	my $rel_types = shift;

	my $fh = new FileHandle($research_filename, 'w')
		|| die "Could not open filename '$research_filename' for writing: $!";

	print $fh download_reseach_xml($properties, $ua, $entity_id, $rel_types);

	undef $fh;

	return 1;
}



1;
