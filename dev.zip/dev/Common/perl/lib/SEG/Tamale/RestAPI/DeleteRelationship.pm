#
# $Id: $
# $Source: $
#
package SEG::Tamale::RestAPI::DeleteRelationship;

use strict;
use FileHandle;
use Config::Properties;
use XML::Simple;
use HTTP::Request;


#
# Creates and returns LWP::UserAgent object. Also enables HTTP Keep alives for
# faster request servicing.
#
sub create_lwp_user_agent_obj {
	my $properties = shift; # Config::Properies properties object

	use LWP;

	my $hostname = $properties->getProperty("tamale.hostname");
	my $port = $properties->getProperty("tamale.port");
	my $username = $properties->getProperty("tamale.username");
	my $password = $properties->getProperty("tamale.password");
	my $tamale_authentication_realm = 'Jython';

	my $ua = LWP::UserAgent->new;
	$ua->credentials(
		"$hostname:$port",
		$tamale_authentication_realm,
		$username => $password
	);

	use LWP::ConnCache;

	# enable use of HTTP keep alive
	$ua->conn_cache(LWP::ConnCache->new);

	return $ua;
}


#
# DeleteDownloads the relationships for an entity from Tamale using the REST API and
# returns the xml content as a string.
#
sub delete_relationship {
	my $properties = shift; # Config::Properies properties object
	my $ua = shift; # LWP::UserAgent
	my $rel_id = shift;

	# create a useragent for this session if one wasn't explicitly given
	$ua = create_lwp_user_agent_obj($properties) unless $ua;


	use URI::Escape;

	my $hostname = $properties->getProperty("tamale.hostname");
	my $port = $properties->getProperty("tamale.port");
	my $username = $properties->getProperty("tamale.username");
	my $password = $properties->getProperty("tamale.password");

    my $webprefix = $properties->getProperty("tamale.webprefix");
    if(not defined $webprefix) { 
        $webprefix = 'http';
    }

	my $tamale_url_script = "restapi/2.0/relationship/$rel_id";

	my $url = "$webprefix://$username:$password\@$hostname:$port/${tamale_url_script}";

    my $request = HTTP::Request->new('DELETE' => $url);
	my $response = $ua->request($request);
	die ("Error: DELETE $url: " . $response->status_line)
		unless $response->is_success;

	return $response->content();
}

1;
