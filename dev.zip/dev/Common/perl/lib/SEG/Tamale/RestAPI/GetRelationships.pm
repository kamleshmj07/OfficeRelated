#
# $Id: $
# $Source: $
#
package SEG::Tamale::RestAPI::GetRelationships;

use strict;
use FileHandle;
use Config::Properties;
use XML::Simple;
use Data::Dump qw(dump);


#
# Creates and returns LWP::UserAgent object. Also enables HTTP Keep alives for
# faster request servicing.
#
sub create_lwp_user_agent_obj {
	my $properties = shift; # Config::Properies properties object

	use LWP;

	my $hostname = $properties->getProperty("tamale.hostname");
	my $port = $properties->getProperty("tamale.port");
	my $username = $properties->getProperty("tamale.username");
	my $password = $properties->getProperty("tamale.password");
	my $tamale_authentication_realm = 'Jython';

	my $ua = LWP::UserAgent->new;
	$ua->credentials(
		"$hostname:$port",
		$tamale_authentication_realm,
		$username => $password
	);

	use LWP::ConnCache;

	# enable use of HTTP keep alive
	$ua->conn_cache(LWP::ConnCache->new);

	return $ua;
}


#
# Downloads the relationships for an entity from Tamale using the REST API and
# returns the xml content as a string.
#
# TODO this method needs to be replaced by the more generic _download_relationships_xml
sub download_relationships_xml {
	my $properties = shift; # Config::Properies properties object
	my $ua = shift; # LWP::UserAgent
	my $entity_id = shift;


	# http://seg-ct-tamaletest2.seg.local:8080/refresh/Jython?service=GetRelationships&username=localIT&entity=WMT&outputFormat=xml&relTypes=all
	use URI::Escape;

	my $hostname = $properties->getProperty("tamale.hostname");
	my $port = $properties->getProperty("tamale.port");
	my $username = $properties->getProperty("tamale.username");

    my $webprefix = $properties->getProperty("tamale.webprefix");
    if(not defined $webprefix) { 
        $webprefix = 'http';
    }

	my $tamale_service = 'GetRelationships';
	my %tamale_url_params = (
		username => $username,
		entity => uri_escape($entity_id),
		relTypes => 'Lead+Analyst;Secondary+Analyst',
		outputformat => 'xml',
	);

	my $tamale_url_script = "web/RestAPI/v1/$tamale_service";


	my $url = "$webprefix://$hostname:$port/${tamale_url_script}?";
	$url .= join('&', map { $_ . '=' . $tamale_url_params{$_} } keys %tamale_url_params);

	my $response = $ua->get($url);
	die ("Error: GET $url: " . $response->status_line)
		unless $response->is_success;

	return $response->content();
}


#
# Parses the <Relationships> xml data and returns Relationships in an
# array of hashes created by XML::Simple.
#
sub get_relationships_from_xml {
	my $xml_src = shift; # open file handle to the XML file OR xml string

	my $xs = XML::Simple->new(ForceArray => [qw(relationship)]);
	my $xml_hash = $xs->XMLin($xml_src, ContentKey => 'id');

	my $rels_raw = $xml_hash->{relationship} || {};

    #The new version (v2) of the RestAPI changed the format of the xml so we need this code
    my $relationships = [];
    foreach my $id (keys %$rels_raw) {
        my $relationship;
        $relationship->{"id"} = $id;
        my @DataArray = @{$rels_raw->{$id}->{"link"}};
        foreach my $DataHash (@DataArray) {
            $relationship->{$DataHash->{rel}} = $DataHash->{phid};
            $relationship->{$DataHash->{rel} . "-id"} = (split(/\//,$DataHash->{href}))[4];
            if(defined $DataHash->{entity}) {
                $relationship->{$DataHash->{rel} . "-short-name"} = $DataHash->{entity}->{"short-name"};
            }
        }
        push(@$relationships, $relationship);
    }

	return $relationships;
}

#
# Downloads the relationships for an entity from Tamale using the REST API and
# returns the xml content as a string.
#
sub _download_relationships_xml {
	my $properties = shift; # Config::Properies properties object
	my $ua = shift; # LWP::UserAgent
	my $advfilter = shift;


	# http://seg-ct-tamaletest2.seg.local:8080/refresh/Jython?service=GetRelationships&username=localIT&entity=WMT&outputFormat=xml&relTypes=all
	use URI::Escape;

	my $hostname = $properties->getProperty("tamale.hostname");
	my $port = $properties->getProperty("tamale.port");
	my $username = $properties->getProperty("tamale.username");
	my $password = $properties->getProperty("tamale.password");
    my $webprefix = $properties->getProperty("tamale.webprefix");
    if(not defined $webprefix) { 
        $webprefix = 'http';
    }

	my %tamale_url_params = (
		advfilter => uri_escape($advfilter),
		outputformat => 'xml',
        expand => 'child-entity;parent-entity'
	);

	my $tamale_url_script = "restapi/2.0/relationship/";

	my $url = "$webprefix://$username:$password\@$hostname:$port/${tamale_url_script}?";
	$url .= join('&', map { $_ . '=' . $tamale_url_params{$_} } keys %tamale_url_params);



	# create a useragent for this session if one wasn't explicitly given
	$ua = create_lwp_user_agent_obj($properties) unless $ua;

	my $response = $ua->get($url);
	die ("Error: GET $url: " . $response->status_line)
		unless $response->is_success;

	return $response->content();
}

1;
