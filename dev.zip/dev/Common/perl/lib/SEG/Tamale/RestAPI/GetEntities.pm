#
# $Id: $
# $Source: $
#
package SEG::Tamale::RestAPI::GetEntities;

use strict;
use FileHandle;
use Config::Properties;
use XML::Simple;
use Data::Dump qw(dump);

#
# Parses the <Entities> xml data and returns only Corporate entities in an
# array of hashes created by XML::Simple.
#
sub get_corporate_entities_from_xml {
	my $xml_src = shift; # open file handle to the XML file OR xml string

	my $xs = XML::Simple->new();
	my $xml_hash = $xs->XMLin($xml_src);

	my $entities = $xml_hash->{'entity'};

    #The id needs to be an element of the hash
    $entities->{$_}->{id} = $_ foreach (keys %$entities);

	my @corporate_entities = grep { defined $_->{'corporate-details'} } values %$entities;

	return \@corporate_entities;
}

#
# Parses the <Entities> xml data and returns only Corporate entities in an
# array of hashes created by XML::Simple.
#
sub get_entities_from_xml {
	my $xml_src = shift; # open file handle to the XML file OR xml string

	my $xs = XML::Simple->new();
	my $xml_hash = $xs->XMLin($xml_src);

	my $entities = $xml_hash->{entity};
    #The id needs to be an element of the hash
    $entities->{$_}->{id} = $_ foreach (keys %$entities);

    my @entities_array = values %$entities;

	return \@entities_array;
}

#
# Downloads the entities from Tamale using the REST API and returns the xml
# content as a string.
#
sub download_entities_xml {
	my $properties = shift; # Config::Properies properties object
    my $types = shift;
 
    $types = '' if(not defined $types);

	use LWP;
    use LWP::Protocol::https;
    use HTTP::Request::Common;

	my $hostname = $properties->getProperty("tamale.hostname");
	my $port = $properties->getProperty("tamale.port");
	my $username = $properties->getProperty("tamale.username");
	my $password = $properties->getProperty("tamale.password");
	my $tamale_authentication_realm = 'Tamale RMS';

    my $webprefix = $properties->getProperty("tamale.webprefix");
    if(not defined $webprefix) { 
        $webprefix = 'http';
    }

	my $ua = LWP::UserAgent->new(keep_alive=>1);
	# http://seg-ct-tamaletest2.seg.local:8080/refresh/Jython?service=GetEntities&username=localIT&columns=all&outputFormat=xml

	my %tamale_url_params = (
        filterby => 'entity-type',
		filterstring => $types,
		outputformat => 'xml',
	);

	my $tamale_url_script = "restapi/2.0/entity/";

	my $url = "$webprefix://$username:$password\@$hostname:$port/${tamale_url_script}?";
	$url .= join('&', map { $_ . '=' . $tamale_url_params{$_} } keys %tamale_url_params);

	my $response = $ua->get($url);
	die ("Error: GET $url: " . $response->status_line)
		unless $response->is_success;

	return $response->content();
}

1;
