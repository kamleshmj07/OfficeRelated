#
# $Id: $
# $Source: $
#
package SEG::Tamale::RestAPI::Util;

use strict;

use List::MoreUtils qw(any);


#
# globals
#
our @TAMALE_PORTFOLIOS = (
	# axys portfolios
	'Cooper Square Long Portfolio',
	'Cooper Square Short Portfolio',
	'Great Jones Portfolio',
	'Lafayette Portfolio',
	'SEG Firmwide Portfolio',
	'SEG Partners Long Portfolio',
	'SEG Partners Short Portfolio',
	'SMID Portfolio',

	# tamale specific portfolios
	'SEG Coverage Portfolio',
);


#
# Returns true if the portfolio name is valid, false otherwise.
#
sub validate_tamale_portfolio {
	my $portfolio_name = shift;

	return any { $portfolio_name eq $_ } @TAMALE_PORTFOLIOS;
}


1;
