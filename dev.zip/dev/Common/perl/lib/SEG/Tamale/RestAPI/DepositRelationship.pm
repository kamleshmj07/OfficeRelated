#
# $Id: $
# $Source: $
#
package SEG::Tamale::RestAPI::DepositRelationship;

use strict;
use FileHandle;
use Config::Properties;
use XML::Simple;


#
# Creates and returns LWP::UserAgent object. Also enables HTTP Keep alives for
# faster request servicing.
#
sub create_lwp_user_agent_obj {
	my $properties = shift; # Config::Properies properties object

	use LWP;

	my $hostname = $properties->getProperty("tamale.hostname");
	my $port = $properties->getProperty("tamale.port");
	my $username = $properties->getProperty("tamale.username");
	my $password = $properties->getProperty("tamale.password");
	my $tamale_authentication_realm = 'Jython';

	my $ua = LWP::UserAgent->new;
	$ua->credentials(
		"$hostname:$port",
		$tamale_authentication_realm,
		$username => $password
	);

	use LWP::ConnCache;

	# enable use of HTTP keep alive
	$ua->conn_cache(LWP::ConnCache->new);

	return $ua;
}


#
# DepositDownloads the relationships for an entity from Tamale using the REST API and
# returns the xml content as a string.
#
sub deposit_relationship {
	my $properties = shift; # Config::Properies properties object
	my $ua = shift; # LWP::UserAgent
	my $parent_id = shift;
	my $child_id = shift;
	my $relType_id = shift;

	# create a useragent for this session if one wasn't explicitly given
	$ua = create_lwp_user_agent_obj($properties) unless $ua;


	use URI::Escape;

	my $hostname = $properties->getProperty("tamale.hostname");
	my $port = $properties->getProperty("tamale.port");
	my $username = $properties->getProperty("tamale.username");
	my $password = $properties->getProperty("tamale.password");

    my $webprefix = $properties->getProperty("tamale.webprefix");
    if(not defined $webprefix) { 
        $webprefix = 'http';
    }

	my $tamale_service = 'DepositRelationship';
	my %tamale_url_params = (
		'parent-entity' => uri_escape($parent_id),
		'child-entity' => uri_escape($child_id),
		'rel-type' => uri_escape($relType_id),
	);

	my $tamale_url_script = "restapi/2.0/relationship/";


	my $url = "$webprefix://$username:$password\@$hostname:$port/${tamale_url_script}?";
	$url .= join('&', map { $_ . '=' . $tamale_url_params{$_} } keys %tamale_url_params);

	my $response = $ua->post($url);
	die ("Error: POST $url: " . $response->status_line)
		unless $response->is_success;

	return $response->content();
}

1;
