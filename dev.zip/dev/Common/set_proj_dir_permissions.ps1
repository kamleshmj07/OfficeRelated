#
# Script for setting proper project directory permissions
# Permissions are modeled after a template project directory structure
#

$BASEDIRPREFIX="\\fsdev\f1"
$RUNMODE="prod37"
$DEPLOYBASEDIR="$BASEDIRPREFIX\$RUNMODE"

# template directory which has desired target file system permission settings
$TEMPLATEPROJDIR="$DEPLOYBASEDIR\ProjectDirTemplate"

$PROJNAME="Common" # project main directory
$PROJROOTDIR="$DEPLOYBASEDIR\$PROJNAME"

function createDirIfNotExists{
    param(
        [string]$dir
    )

    $path = "$PROJROOTDIR\$dir";
    if (!(test-path $path)) {
        New-Item -ItemType Directory -Force -Path $path
    }
}

function setAclForDir {
    param (
        [string]$target_dir,
        [string]$templ_dir
    )
    if (! $templ_dir) {
        $templ_dir = $target_dir
    }

    $template_acl = Get-Acl $TEMPLATEPROJDIR\$templ_dir
    Set-Acl -path $PROJROOTDIR\$target_dir -AclObject $template_acl
}

#
# target directory -> template directory mapping for setting ACLs
#
$project_dirs = @{
    "python\lib\SEG\log"="log";
};

#
# setup dirs and set windows dir ACLs
#
foreach ($curr_dir in $project_dirs.Keys) {
    $template_dir = $project_dirs[$curr_dir]
    createDirIfNotExists $curr_dir
    setAclForDir $curr_dir $template_dir
    Get-Acl "$PROJROOTDIR\$curr_dir" | Format-List
}
